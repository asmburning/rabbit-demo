package com.hellobike.rent.order.sync.resp;

import com.alibaba.fastjson.JSONObject;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 天猫主、子订单信息
 *
 * @author zhuangjx
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TmallOidQueryResp {
    private Long tid;//天猫主订单id
    private String receiverName;//收件人
    private String receiverAddress;//收件地址
    private String receiverMobile;//收件手机号
    private String receiverCity;//城市
    private String receiverDistrict;//城市下辖
    private Integer totalNum;//主订单下子订单数
    private BigDecimal deliveryPrice;//配送费用(单笔 post_fee/totalNum)
    private LocalDateTime payTime;//天猫订单支付时间
    private JSONObject extendJsonb;//天猫主订单扩展字段
    private SubOrderInfo subOrder;//oid对应订单信息

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class SubOrderInfo {
        private Long oid;//子订单id
        private BigDecimal price;//商品价格
        private BigDecimal systemCouponPrice;//优惠金额(discount_fee/totalNum)
        private Integer subNum;//子订单商品数
        private BigDecimal totalPrice;//总费用 total_fee/num
        private LocalDateTime createTime;
        private LocalDateTime updateTime;
        private BigDecimal payment;//支付金额 费用 payment/num
    }
}
