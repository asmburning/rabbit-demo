package com.hellobike.rent.order.sync.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author liuxinyi
 * @date 2019/9/2
 */
@AllArgsConstructor
@Getter
public enum EnumTmallGoodsType {
    POWER_SELL("POWER_SELL","直租-售车"),
    POWER_RENT("POWER_RENT","直租-租车"),
    UNKNOWN("UNKNOWN","未知"),
    ;

    private String type;
    private String desc;
}
