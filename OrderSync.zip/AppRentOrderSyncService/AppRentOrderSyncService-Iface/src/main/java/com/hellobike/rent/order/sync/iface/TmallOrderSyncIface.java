package com.hellobike.rent.order.sync.iface;

/**
 * @author David
 * @date 2019/8/30
 */
public interface TmallOrderSyncIface {

    /**
     *参考文档 https://open.taobao.com/api.htm?spm=a219a.7386797.0.0.4afc669am8ysGP&source=search&docId=10690&docType=2
     * @param tid
     * @param oid 多个子订单 逗号分开
     * @param deliveryNo
     * @param isSplit 0 不拆单，1表示拆单
     * @return
     * @throws Exception
     */
    boolean OnlineSend(long tid, String oid, String deliveryNo, long isSplit ) throws Exception;
}
