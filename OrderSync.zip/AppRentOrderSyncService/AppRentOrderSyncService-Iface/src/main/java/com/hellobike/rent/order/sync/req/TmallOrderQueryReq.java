package com.hellobike.rent.order.sync.req;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by chenfuchao on 2019-09-30 11:00
 *
 * @Author chenfuchao
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TmallOrderQueryReq {
    /**
     * 天猫主订单ID
     */
    private Long tid;
}
