package com.hellobike.rent.order.sync.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author liuxinyi
 * @date 2019/9/5
 */
@AllArgsConstructor
@Getter
public enum  EnumTmallEventType {

    TMALL2HELLO("TMALL2HELLO","天猫到哈啰"),
    HELLO2TMALL("HELLO2TMALL","哈啰到天猫"),
            ;

    private String eventType;
    private String desc;
}
