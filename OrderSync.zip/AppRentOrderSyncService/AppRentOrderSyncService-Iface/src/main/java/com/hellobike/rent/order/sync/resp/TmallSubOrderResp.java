package com.hellobike.rent.order.sync.resp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 天猫子订单信息
 *
 * @author gaohu08299
 * @create $ ID: TmallSubOrderResp, 2019-09-29 16:00 gaohu08299 Exp $
 * @since 1.0.0
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TmallSubOrderResp {

    /**
     * 子订单id
     */
    private Long oid;

    /**
     * 父订单id
     */
    private Long tid;

    /**
     * 商品图片路径
     */
    private String picPath;

    /**
     * 天猫商品id
     */
    private String outerSkuId;

    /**
     * 商品标题
     */
    private String title;


}
