package com.hellobike.rent.order.sync.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;


@AllArgsConstructor
@Getter
public enum EnumFacilityType {

    BRANCH("1","网点"),
    TRANSFER_CENTER("2","中转中心/分拨中心"),
    COLLECTION_POINT("3","代收点");


    private String type;
    private String desc;
}
