package com.hellobike.rent.order.sync.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;


@AllArgsConstructor
@Getter
public enum EnumCainiaoDeliveryAction {

    TMS_ACCEPT("TMS_ACCEPT","快递员已收件"),
    TMS_STATION_IN("TMS_STATION_IN","到站点"),
    TMS_STATION_OUT("TMS_STATION_OUT","已出站"),
    TMS_ERROR("TMS_ERROR", "配送异常"),
    TMS_DELIVERING("TMS_DELIVERING", "配送中"),
    TMS_SIGN("TMS_SIGN", "签收"),
    TMS_FAILED("TMS_FAILED","签收失败");

    private String action;
    private String desc;
}
