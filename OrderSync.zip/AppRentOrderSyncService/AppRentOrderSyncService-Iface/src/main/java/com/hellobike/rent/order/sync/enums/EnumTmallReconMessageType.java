package com.hellobike.rent.order.sync.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.HashSet;
import java.util.Set;

/**
 * @author liuxinyi
 * @date 2019/9/2
 */
@AllArgsConstructor
@Getter
public enum EnumTmallReconMessageType {
    TID_PAY_UPDATE("TID_PAY_UPDATE", "TID_PAY_UPDATE"),
    TID_FINISH_UPDATE("TID_FINISH_UPDATE", "TID_FINISH_UPDATE"),
    TID_SELL_DELIVERY("TID_SELL_DELIVERY", "TID_SELL_DELIVERY"),
    OID_SELL_PAY("OID_SELL_PAY", "OID_SELL_PAY"),
    OID_RENT_PAY("OID_RENT_PAY", "OID_RENT_PAY"),
    OID_REFUND_CLOSED("OID_REFUND_CLOSED", "OID_REFUND_CLOSED"),
    OID_REFUND_CLOSED_UPDATE("OID_REFUND_CLOSED_UPDATE", "OID_REFUND_CLOSED_UPDATE"),
    OID_REFUND_SUCCESS("REFUND_SUCCESS", "REFUND_SUCCESS"),
    OID_REFUND_SUCCESS_UPDATE("OID_REFUND_SUCCESS_UPDATE", "OID_REFUND_SUCCESS_UPDATE"),
    OID_FINISH("OID_FINISH", "OID_FINISH"),
    OID_UNKNOWN("OID_UNKNOWN", "OID_UNKNOWN"),
    ;

    private String reconType;
    private String desc;

    public static final Set<String> TID_SET = new HashSet<>();
    public static final Set<String> OID_SET = new HashSet<>();

    static {
        TID_SET.add(TID_SELL_DELIVERY.getReconType());

        OID_SET.add(OID_RENT_PAY.getReconType());
        OID_SET.add(OID_SELL_PAY.getReconType());
        OID_SET.add(OID_REFUND_SUCCESS.getReconType());
        OID_SET.add(OID_FINISH.getReconType());
    }

}
