package com.hellobike.rent.order.sync.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author created by zhangqiang05740
 * @date Created in 2019/9/4 2:50 PM
 * @description: 商品sku信息
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SkuInfo {

    /**
     * 车型id
     */
    private String modelId;

    /**
     * 车型名称
     */
    private String modelName;

    /**
     * 规格id
     */
    private String specId;

    /**
     * 规格名称
     */
    private String specName;

    private Integer switchPower;
}
