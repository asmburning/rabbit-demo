package com.hellobike.rent.order.sync.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author liuxinyi
 * @date 2019/9/2
 */
@AllArgsConstructor
@Getter
public enum EnumTmallOrderRefundStatus {
    WAIT_SELLER_AGREE("WAIT_SELLER_AGREE", "买家已经申请退款，等待卖家同意"),
    WAIT_BUYER_RETURN_GOODS("WAIT_BUYER_RETURN_GOODS", "卖家已经同意退款，等待买家退货"),
    WAIT_SELLER_CONFIRM_GOODS("WAIT_SELLER_CONFIRM_GOODS", "买家已经退货，等待卖家确认收货"),
    SELLER_REFUSE_BUYER("SELLER_REFUSE_BUYER", "卖家拒绝退款"),
    CLOSED("CLOSED", "退款关闭"),
    SUCCESS("SUCCESS", "退款成功"),
    ;
    private String refundStatus;
    private String desc;
}
