package com.hellobike.rent.order.sync.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

/**
 * @author liuxinyi
 * @date 2019/9/5
 */
@AllArgsConstructor
@Getter
public enum EnumTmallMessageEvent {

    /**
     * 防止空指针异常，返回默认值
     */
    TO_BE_DONE("TO_BE_DONE", "TO_BE_DONE"),

    WAIT_BUYER_PAY("WAIT_BUYER_PAY", "待支付"),
    WAIT_BUYER_PAY_CANCEL("WAIT_BUYER_PAY_CANCEL", "待支付取消"),
    WAIT_SELLER_SEND_GOODS("WAIT_SELLER_SEND_GOODS", "支付等待卖家发货"),
    TRADE_CLOSED("TRADE_CLOSED", "已支付取消"),
    TRADE_FINISHED("TRADE_FINISHED", "交易完成"),


    //退款消息
    taobao_refund_RefundCreated("taobao_refund_RefundCreated", "申请退款"),
    taobao_refund_RefundSellerAgreeAgreement("taobao_refund_RefundSellerAgreeAgreement", "卖家同意退款"),

    // 退款成功
    taobao_refund_RefundSuccess("taobao_refund_RefundSuccess", "退款成功topic"),
    taobao_refund_RefundClosed("taobao_refund_RefundClosed", "退款取消"),
    ;

    private String event;
    private String desc;


    public static EnumTmallMessageEvent parse(String event) {
        for (EnumTmallMessageEvent value : values()) {
            if (StringUtils.equals(value.getEvent(), event)) {
                return value;
            }
        }
        return TO_BE_DONE;
    }
}

