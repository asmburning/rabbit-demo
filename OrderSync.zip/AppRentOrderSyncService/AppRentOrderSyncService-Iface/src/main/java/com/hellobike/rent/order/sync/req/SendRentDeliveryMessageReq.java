package com.hellobike.rent.order.sync.req;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by zhuangjx
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SendRentDeliveryMessageReq {
    /**
     * 天猫主订单ID
     */
    private Long tid;

    /**
     * 天猫子订单ID
     */
    private Long oid;
}
