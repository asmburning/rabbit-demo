package com.hellobike.rent.order.sync.iface;

import com.hellobike.rent.order.sync.req.CainiaoTmsTraceReq;

public interface TmsTracePushToCainiaoService {

    boolean TmsTracePush(CainiaoTmsTraceReq req) throws Exception;

}
