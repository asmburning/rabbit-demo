package com.hellobike.rent.order.sync.resp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by chenfuchao on 2019-09-30 10:57
 *
 * @Author chenfuchao
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TmallMainOrderResp {
    /**
     * 天猫主订单ID
     */
    private Long tid;

    /**
     * 城市code（哈啰）
     */
    private String cityCode;
}
