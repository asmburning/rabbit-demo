package com.hellobike.rent.order.sync.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author liuxinyi
 * @date 2019/9/2
 */
@AllArgsConstructor
@Getter
public enum EnumTmallShippingType {
    FREE("free", "卖家包邮"),
    POST("post", "平邮"),
    EXPRESS("express", "快递"),
    EMS("ems", "EMS"),
    VIRTUAL("virtual", "虚拟发货"),
    TOMORROW("25", "次日必达"),
    RESERVE("26", "预约配送"),
    ;

    private String shippingType;
    private String desc;
}
