package com.hellobike.rent.order.sync.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author liuxinyi
 * @date 2019/9/2
 */
@AllArgsConstructor
@Getter
public enum EnumTmallRtOmniSendType {
    PICK_UP("pickUp", "自提订单，对应自提"),
    TMALL("tmall", "电商发货,对应配送"),
    STORE_SEND("storeSend", "门店发货（配送、骑手）"),
    ;

    private String sendType;
    private String desc;
}
