package com.hellobike.rent.order.sync.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author liuxinyi
 * @date 2019/9/2
 */
@AllArgsConstructor
@Getter
public enum EnumTmallOrderType {
    FIXED("fixed","一口价"),
    AUCTION("auction","拍卖"),
    GUARANTEE_TRADE("guarantee_trade","一口价、拍卖"),
    AUTO_DELIVERY("auto_delivery","自动发货"),
    INDEPENDENT_SIMPLE_TRADE("independent_simple_trade","旺店入门版交易"),
    INDEPENDENT_SHOP_TRADE("independent_shop_trade","旺店标准版交易"),
    EC("ec","直冲"),
    COD("cod","货到付款"),
    FENXIAO("fenxiao","分销"),
    GAME_EQUIPMENT("game_equipment","游戏装备"),
    SHOPEX_TRADE("shopex_trade","ShopEX交易"),
    NETCN_TRADE("netcn_trade","万网交易"),
    EXTERNAL_TRADE("external_trade","统一外部交易"),
    O2O_OFFLINETRADE("o2o_offlinetrade","O2O交易"),
    STEP("step","万人团"),
    NOPAID("nopaid","无付款订单"),
    PRE_AUTH_TYPE("pre_auth_type","预授权0元购机交易"),
    ;

    private String type;
    private String desc;
}
