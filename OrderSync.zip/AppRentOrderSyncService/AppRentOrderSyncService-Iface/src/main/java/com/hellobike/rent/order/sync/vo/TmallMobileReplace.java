package com.hellobike.rent.order.sync.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author liuxinyi
 * @date 2019/9/6
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TmallMobileReplace {
    private String regex;
    private String mobile;
}
