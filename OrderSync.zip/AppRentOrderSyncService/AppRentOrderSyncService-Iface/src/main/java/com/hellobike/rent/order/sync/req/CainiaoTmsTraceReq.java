package com.hellobike.rent.order.sync.req;

import com.hellobike.rent.order.sync.enums.EnumCainiaoDeliveryAction;
import com.hellobike.rent.order.sync.enums.EnumFacilityType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 网点信息
 * https://docs.alipay.com/wuliuxiangqing/interface/eczzw9
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CainiaoTmsTraceReq {
    /**
     * 物流单号 我们生成的
     */
    private String mailNos;
    /**
     * 菜鸟生成的LP开头的物流单号
     */
    private String txLogisticId;
    /**
     * 节点类型
     */
    private EnumCainiaoDeliveryAction action;
    /**
     * 网点类型
     */
    private EnumFacilityType enumFacilityType;
    /**
     * 网点名称
     */
    private String facilityName;
    /**
     * 网点编号
     */
    private String facilityNo;
    /**
     * 联系人
     */
    private String contacter;
    /**
     * 快递员手机号
     */
    private String contactPhone;
    /**
     * 描述
     */
    private String desc;
    /**
     * 当前城市
     */
    private String city;
    /**
     * 配送异常 签收异常必须传
     */
    private String remark;
    /**
     * 出站点必须传
     */
    private String nextCity;

}


