package com.hellobike.rent.order.sync.iface;

import com.hellobike.rent.common.iface.resp.ServiceResp;
import com.hellobike.rent.order.sync.req.TmallOrderQueryReq;
import com.hellobike.rent.order.sync.resp.TmallMainOrderResp;
import com.hellobike.rent.order.sync.resp.TmallOidQueryResp;
import com.hellobike.rent.order.sync.resp.TmallSubOrderResp;

/**
 * 天猫子订单
 *
 * @author gaohu08299
 * @create $ ID: TmallOrderQueryIface, 2019-09-29 17:36 gaohueric Exp $
 * @since 1.0.0
 */
public interface TmallOrderQueryIface {

    /**
     * 根据订单号查询天猫子订单
     *
     * @param oid
     * @return
     */
    ServiceResp<TmallSubOrderResp> queryTmallSubOrderInfo(Long oid);

    ServiceResp<TmallMainOrderResp> queryTmallMainOrder(TmallOrderQueryReq req);

    /**
     * 根据天猫子订单oid查询主、子订单信息
     */
    ServiceResp<TmallOidQueryResp> queryTmallMainSubInfoByOid(Long oid);

}
