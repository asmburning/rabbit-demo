package com.hellobike.rent.order.sync.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * @author liuxinyi
 * @date 2019/9/2
 */
@AllArgsConstructor
@Getter
public enum EnumTmallTradeFrom {
    WAP("WAP", "手机"),
    HITAO("HITAO", "嗨淘"),
    TOP("TOP", "TOP平台"),
    TAOBAO("TAOBAO", "普通淘宝"),
    JHS("JHS", "聚划算"),
    ;

    private String tradeFrom;
    private String desc;
}
