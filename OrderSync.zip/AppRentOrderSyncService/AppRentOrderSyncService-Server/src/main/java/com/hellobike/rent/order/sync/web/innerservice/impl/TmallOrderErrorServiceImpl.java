package com.hellobike.rent.order.sync.web.innerservice.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.core.toolkit.IdWorker;
import com.ctrip.framework.apollo.Config;
import com.ctrip.framework.apollo.spring.annotation.ApolloConfig;
import com.hellobike.rent.order.sync.enums.EnumTmallReconMessageType;
import com.hellobike.rent.order.sync.web.innerservice.TmallMainOrderService;
import com.hellobike.rent.order.sync.web.innerservice.TmallOrderErrorService;
import com.hellobike.rent.order.sync.web.mapper.TmallOrderErrorMapper;
import com.hellobike.rent.order.sync.web.message.TmallMessageForwardComponent;
import com.hellobike.rent.order.sync.web.model.TmallOrderErrorEntity;
import com.hellobike.rent.order.sync.web.reconciliation.ReconciliationMessageComponent;
import com.hellobike.rent.order.sync.web.reconciliation.TmallReconciliationComponent;
import com.hellobike.rent.order.sync.web.util.ThreadPools;
import com.hellobike.rent.order.sync.web.util.YunLogger;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author liuxinyi
 * @date 2019/9/26
 */
@Service
@Slf4j
public class TmallOrderErrorServiceImpl implements TmallOrderErrorService {

    @Autowired
    private TmallOrderErrorMapper orderErrorMapper;
    @Autowired
    private YunLogger yunLogger;
    @Autowired
    private TmallReconciliationComponent reconciliationComponent;
    @Autowired
    private ReconciliationMessageComponent reconciliationMessageComponent;
    @Autowired
    private TmallMessageForwardComponent messageForwardComponent;
    @Autowired
    private TmallMainOrderService mainOrderService;
    @ApolloConfig
    private Config config;

    private void doLogError(Long tid, Long oid, String reconMessageType,
                            String errorMessage, String goodsName) {
        TmallOrderErrorEntity dbEntity = orderErrorMapper.selectOne(new QueryWrapper<>(
                TmallOrderErrorEntity.builder()
                        .tid(tid)
                        .oid(oid)
                        .errorType(reconMessageType)
                        .build()));
        if (null == dbEntity) {
            TmallOrderErrorEntity insert = TmallOrderErrorEntity.builder()
                    .guid(IdWorker.getIdStr())
                    .tid(tid)
                    .oid(oid)
                    .errorType(reconMessageType)
                    .errorMessage(errorMessage)
                    .goodsName(goodsName)
                    .errorHandled(0)
                    .tryTime(0)
                    .createTime(LocalDateTime.now())
                    .updateTime(LocalDateTime.now())
                    .updateTime(LocalDateTime.now())
                    .build();
            orderErrorMapper.insert(insert);
        } else {
            TmallOrderErrorEntity update = TmallOrderErrorEntity.builder()
                    .guid(dbEntity.getGuid())
                    .tryTime(dbEntity.getTryTime() + 1)
                    .updateTime(LocalDateTime.now()).build();
            orderErrorMapper.updateById(update);
        }
    }

    @Override
    public void logError(Long tid, Long oid, EnumTmallReconMessageType reconMessageType, String errorMessage) {
        doLogError(tid, oid, reconMessageType.getReconType(), errorMessage, null);
    }

    @Override
    public void logError(Long tid, Long oid, String bosDeliveryOrder, String errorMessage) {
        doLogError(tid, oid, bosDeliveryOrder, errorMessage, null);
    }

    private List<TmallOrderErrorEntity> queryNotHandledListByErrorType(String errorType) {
        Integer retryHours = config.getIntProperty("rentTmall.errorRetry.hours", 24);
        List<TmallOrderErrorEntity> tmallOrderErrorEntityIPage = orderErrorMapper.selectList(
                new QueryWrapper<TmallOrderErrorEntity>()
                        .eq("error_handled", 0)
                        .eq("error_type", errorType)
                        .gt("create_time", LocalDateTime.now().minusHours(retryHours)));
        return tmallOrderErrorEntityIPage;
    }

    @Override
    public int updateErrorHandled(Long tid, Long oid, EnumTmallReconMessageType errorType) {
        TmallOrderErrorEntity update = TmallOrderErrorEntity.builder()
                .errorHandled(1)
                .updateTime(LocalDateTime.now())
                .build();
        return orderErrorMapper.update(update, new UpdateWrapper<TmallOrderErrorEntity>()
                .eq("tid", tid)
                .eq("t_oid", oid)
                .eq("error_type", errorType.getReconType()));
    }

    private List<TmallOrderErrorEntity> queryNotHandledErrorList(String errorType) {
        return orderErrorMapper.selectList(new QueryWrapper<TmallOrderErrorEntity>()
                .eq("error_type", errorType)
                .eq("error_handled", 0)
                .le("try_time", 10)
                .gt("create_time", LocalDateTime.now().minusDays(2))
        );
    }

    @Override
    public void dealTidPayUpdateError() {
        log.info("dealTidPayUpdateErrorBegin");
        List<TmallOrderErrorEntity> errorEntityList = queryNotHandledErrorList(
                EnumTmallReconMessageType.TID_PAY_UPDATE.getReconType());
        if (CollectionUtils.isEmpty(errorEntityList)) {
            return;
        }
        for (TmallOrderErrorEntity orderErrorEntity : errorEntityList) {
            ThreadPools.submitPayTask(
                    () -> reconciliationMessageComponent.reconciliationTidPayMessage(orderErrorEntity.getTid())
            );
        }

    }

    @Override
    public void dealTidFinishUpdateError() {
        log.info("dealTidFinishUpdateErrorBegin");
        List<TmallOrderErrorEntity> errorEntityList = queryNotHandledErrorList(
                EnumTmallReconMessageType.TID_FINISH_UPDATE.getReconType());
        if (CollectionUtils.isEmpty(errorEntityList)) {
            return;
        }
        for (TmallOrderErrorEntity orderErrorEntity : errorEntityList) {
            ThreadPools.submitFinishTask(
                    () -> reconciliationMessageComponent.reconciliationTidFinishMessage(orderErrorEntity.getTid())
            );
        }
    }

    @Override
    public void dealOidRefundSuccessUpdateError() {
        log.info("dealOidRefundSuccessUpdateErrorBegin");
        List<TmallOrderErrorEntity> errorEntityList = queryNotHandledErrorList(
                EnumTmallReconMessageType.OID_REFUND_SUCCESS_UPDATE.getReconType());
        if (CollectionUtils.isEmpty(errorEntityList)) {
            return;
        }
        for (TmallOrderErrorEntity orderErrorEntity : errorEntityList) {
            ThreadPools.submitDealRefundSuccessTask(
                    () -> reconciliationMessageComponent.reconOidRefundSuccessMessage(
                            orderErrorEntity.getTid(), orderErrorEntity.getOid())
            );
        }
    }


}
