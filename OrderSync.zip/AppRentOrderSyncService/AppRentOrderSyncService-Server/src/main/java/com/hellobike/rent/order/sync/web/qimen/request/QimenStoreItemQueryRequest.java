package com.hellobike.rent.order.sync.web.qimen.request;


import com.hellobike.rent.order.sync.web.qimen.response.QimenResponse;
import com.hellobike.rent.order.sync.web.qimen.response.QimenStoreItemQueryResponse;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public  class QimenStoreItemQueryRequest<T extends QimenResponse> extends QimenRequest {

    private Long storeId;

    private Long page;

    public  String getApiMethodName(){
        return "taobao.qimen.storeitem.query";
    }

    public  Class<QimenStoreItemQueryResponse> getResponseClass(){
        return QimenStoreItemQueryResponse.class;
    }
}
