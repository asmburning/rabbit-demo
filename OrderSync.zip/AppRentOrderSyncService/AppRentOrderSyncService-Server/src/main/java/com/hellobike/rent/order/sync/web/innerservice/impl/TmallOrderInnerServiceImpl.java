package com.hellobike.rent.order.sync.web.innerservice.impl;


import com.alibaba.fastjson.JSON;
import com.hellobike.rent.common.iface.resp.ServiceResp;
import com.hellobike.rent.order.sync.web.config.TmallConfig;
import com.hellobike.rent.order.sync.web.innerservice.TmallOrderInnerService;
import com.hellobike.rent.order.sync.web.util.AsyncHttpUtils;
import com.taobao.api.ApiException;
import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;
import com.taobao.api.domain.Refund;
import com.taobao.api.domain.Trade;
import com.taobao.api.request.*;
import com.taobao.api.response.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service
@Slf4j
public class TmallOrderInnerServiceImpl implements TmallOrderInnerService {


    @Autowired
    TmallConfig tmallConfig;

    @Override
    public Trade getOrderFullInfoByTid(long tid) throws ApiException {
        TradeFullinfoGetRequest req = new TradeFullinfoGetRequest();
        req.setFields(getTmallOrderDetailFields());
        req.setTid(tid);
        TradeFullinfoGetResponse rsp = tmallConfig.getTaobaoClient().execute(req, tmallConfig.getSessionKey());
        if (!rsp.isSuccess()) {
            throw new ApiException(rsp.getErrorCode(), rsp.getMessage());
        }
        return rsp.getTrade();
    }

    @Override
    public Trade getOrderFullInfoByTidFromJushita(long tid) throws ApiException {
        try {
            Map<String, Object> reqMap = new HashMap<>();
            reqMap.put("tid", tid);
            Map<String, String> heads = new HashMap<>();
            heads.put("rent-sign", "xxx");
            ServiceResp<String> serviceResp = AsyncHttpUtils.postJson(tmallConfig.getJushitaHost(), heads, JSON.toJSONString(reqMap));
            if (serviceResp.isSuccess()) {
                String responseJson = serviceResp.getData();
                return JSON.parseObject(responseJson, Trade.class);
            }
            throw new ApiException("requestJushitaError:" + serviceResp.getMsg());
        } catch (Exception e) {
            throw new ApiException("requestJushitaError:", e);
        }

    }

    @Override
    public void consumeOrderByCode(long tid, String code) throws ApiException {
//        OmniorderStorecollectConsumeRequest req = new OmniorderStorecollectConsumeRequest();
//        req.setCode(code);
//        req.setMainOrderId(1323456841234L);
//        req.setOperator(tid);
//        OmniorderStorecollectConsumeResponse rsp = taobaoClient.execute(req, sessionKey);
//        System.out.println(rsp.getBody());

    }

    @Override
    public List<Trade> getAllOrderByCreateTime(Date start, Date end, String status) throws ApiException {
        TradesSoldGetRequest req = new TradesSoldGetRequest();
        req.setFields("tid,status");
        req.setStartCreated(start);
        req.setEndCreated(end);
        if (!status.equals("ALL")) {
            req.setStatus(status);
        }
        TradesSoldGetResponse rsp = tmallConfig.getTaobaoClient().execute(req, tmallConfig.getSessionKey());
        if (!rsp.isSuccess()) {
            throw new ApiException(rsp.getErrorCode(), rsp.getMessage());
        }
        return rsp.getTrades();
    }

    @Override
    public List<Trade> getAllOrderByUpdateTime(Date start, Date end, String status) throws ApiException {
        TradesSoldIncrementGetRequest req = new TradesSoldIncrementGetRequest();
        req.setFields("tid,type,status,payment,orders,rx_audit_status");
        req.setStartModified(start);
        req.setEndModified(end);
        if (!status.equals("ALL")) {
            req.setStatus(status);
        }
        TradesSoldIncrementGetResponse rsp = tmallConfig.getTaobaoClient().execute(req, tmallConfig.getSessionKey());
        if (!rsp.isSuccess()) {
            throw new ApiException(rsp.getErrorCode(), rsp.getSubMsg());
        }
        return rsp.getTrades();
    }

    @Override
    public Refund getRefundOrderByRefundId(long refundId) throws ApiException {
        RefundGetRequest req = new RefundGetRequest();
        req.setFields("refund_id, alipay_no, tid, oid, buyer_nick, seller_nick, total_fee, status, created,modified,refund_fee,good_status,has_good_return,payment,reason, desc, num_iid, title, price, num, good_return_time, company_name, sid, address, shipping_type, refund_remind_timeout, refund_phase, refund_version, operation_contraint, attribute, outer_id, sku");
        req.setRefundId(refundId);
        RefundGetResponse rsp = tmallConfig.getTaobaoClient().execute(req, tmallConfig.getSessionKey());
        if (!rsp.isSuccess()) {
            throw new ApiException(rsp.getErrorCode(), rsp.getSubMsg());
        }
        return rsp.getRefund();
    }

    @Override
    public List<Refund> getRefunds(Date start, Date end) throws ApiException {
        RefundsReceiveGetRequest req = new RefundsReceiveGetRequest();
        req.setFields("refund_id,tid,oid,title,buyer_nick,seller_nick,total_fee,status,created,modified,refund_fee,refund_phase");
        req.setStartModified(start);
        req.setEndModified(end);
        RefundsReceiveGetResponse rsp = tmallConfig.getTaobaoClient().execute(req, tmallConfig.getSessionKey());
        if (!rsp.isSuccess()) {
            throw new ApiException(rsp.getErrorCode(), rsp.getSubMsg());
        }
        return rsp.getRefunds();
    }

    public static void main(String[] args) throws ApiException {
//        TradesSoldGetRequest req = new TradesSoldGetRequest();
//        req.setFields("tid,type,status");
//        req.setStartCreated(StringUtils.parseDateTime("2019-09-01 00:00:00"));
//        req.setEndCreated(new Date());
//        req.setStatus("WAIT_SELLER_SEND_GOODS");
        RefundGetRequest req = new RefundGetRequest();
        req.setFields("refund_id, alipay_no, tid, oid, buyer_nick, seller_nick, total_fee, status, created, refund_fee, good_status, has_good_return, payment, reason, desc, num_iid, title, price, num, good_return_time, company_name, sid, address, shipping_type, refund_remind_timeout, refund_phase, refund_version, operation_contraint, attribute, outer_id, sku");
        req.setRefundId(34033902888300134L);
        TaobaoClient taobaoClient = new DefaultTaobaoClient("http://gw.api.taobao.com/router/rest", "27810288", "aa1a9f83e158ae548b53542d2d9bdd9c");
        RefundGetResponse rsp = taobaoClient.execute(req, "6100107283976651bfe4689a559cb97359714e0a18f116b2206456792674");
        System.out.println(rsp.getBody());


    }

    private String getTmallOrderDetailFields() {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("tid").append(",")
                .append("seller_nick").append(",")
                .append("pic_path").append(",")
                .append("payment").append(",")
                .append("seller_rate").append(",")
                .append("post_fee").append(",")
                .append("receiver_name").append(",")
                .append("receiver_state").append(",")
                .append("receiver_address").append(",")
                .append("receiver_zip").append(",")
                .append("receiver_mobile").append(",")
                .append("receiver_phone").append(",")
                .append("consign_time").append(",")
                .append("received_payment").append(",")
                .append("promotion_details").append(",")
                .append("est_con_time").append(",")
                .append("receiver_country").append(",")
                .append("receiver_town").append(",")
                .append("order_tax_fee").append(",")
                .append("paid_coupon_fee").append(",")
                .append("shop_pick").append(",")
                .append("biz_code").append(",")
                .append("new_presell").append(",")
                .append("you_xiang").append(",")
                .append("pay_channel").append(",")
                .append("num").append(",")
                .append("num_iid").append(",")
                .append("status").append(",")
                .append("title").append(",")
                .append("type").append(",")
                .append("price").append(",")
                .append("discount_fee").append(",")
                .append("has_post_fee").append(",")
                .append("total_fee").append(",")
                .append("created").append(",")
                .append("pay_time").append(",")
                .append("modified").append(",")
                .append("end_time").append(",")
                .append("buyer_message").append(",")
                .append("buyer_memo").append(",")
                .append("buyer_flag").append(",")
                .append("seller_memo").append(",")
                .append("seller_flag").append(",")
                .append("buyer_nick").append(",")
                .append("trade_attr").append(",")
                .append("credit_card_fee").append(",")

                .append("step_trade_status").append(",")
                .append("step_paid_fee").append(",")
                .append("mark_desc").append(",")
                .append("shipping_type").append(",")
                .append("buyer_cod_fee").append(",")
                .append("adjust_fee").append(",")
                .append("trade_from").append(",")
                .append("service_orders").append(",")
                .append("buyer_rate").append(",")
                .append("receiver_city").append(",")
                .append("receiver_district").append(",")
                .append("service_tags").append(",")

                .append("o2o").append(",")
                .append("o2o_guide_id").append(",")
                .append("o2o_shop_id").append(",")
                .append("o2o_guide_name").append(",")
                .append("o2o_shop_name").append(",")
                .append("o2o_delivery").append(",")

                .append("orders").append(",")
                .append("trade_ext").append(",")
                .append("eticket_service_addr").append(",")
                .append("coupon_fee").append(",")
                .append("omnichannel_param").append(",")
                .append("assembly").append(",")
                .append("top_hold").append(",")
                .append("toptype").append(",")
                .append("service_type").append(",")

                .append("o2o_service_mobile").append(",")
                .append("o2o_service_name").append(",")
                .append("o2o_service_state").append(",")
                .append("o2o_service_city").append(",")
                .append("o2o_service_district").append(",")
                .append("o2o_service_town").append(",")

                .append("o2o_service_address").append(",")

                .append("o2o_step_trade_detail_new").append(",")
                .append("logistics_infos").append(",")
                .append("nr_shop_id").append(",")
                .append("nr_shop_name").append(",")
                .append("buyer_open_uid").append(",")


                .append("cutoff_minutes").append(",")

                .append("delivery_time").append(",")
                .append("collect_time").append(",")
                .append("dispatch_time").append(",")
                .append("sign_time").append(",")
                .append("rt_omni_send_type").append(",")

                .append("rt_omni_send_type").append(",")
                .append("rt_omni_store_id").append(",")
                .append("rt_omni_outer_store_id").append(",")

                .append("buyer_open_uid").append(",")
                .append("et_type").append(",")
                .append("et_shop_id").append(",")

                .append("obs");
        return stringBuffer.toString();
    }


}
