package com.hellobike.rent.order.sync.web.helper;

import com.hellobike.rent.base.data.iface.SpecIface;
import com.hellobike.rent.base.data.resp.model.SpecBasicInfoResp;
import com.hellobike.rent.common.iface.resp.ServiceResp;
import com.hellobike.soa.rpc.RpcClientHelper;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author created by zhangqiang05740
 * @date Created in 2019/9/5 6:04 PM
 * @description:
 **/
@Component
public class BikeHelper {

    /**
     * 根据规格获取车型规格信息
     * @param specId       规格id
     * @return             车型规格信息
     */
    public SpecBasicInfoResp getSpecBasicInfo(String specId){
        ServiceResp<SpecBasicInfoResp> serviceResp = RpcClientHelper.getClient(SpecIface.class).querySpecBasicInfobySpecId(specId);
        if (null != serviceResp && serviceResp.isSuccess()){
            return serviceResp.getData();
        }
        return null;
    }

    /**
     * 批量获取车型规格信息
     * @param specIds   规格id列表
     * @return          规格信息
     */
    public List<SpecBasicInfoResp> getSpecBasicInfos(List<String> specIds){
        ServiceResp<List<SpecBasicInfoResp>> serviceResp = RpcClientHelper.getClient(SpecIface.class).querySpecBasicInfos(specIds);
        if (null != serviceResp && serviceResp.isSuccess()){
            return serviceResp.getData();
        }
        return null;
    }

}
