package com.hellobike.rent.order.sync.web.helper;

import com.hellobike.rent.base.data.iface.CityConfigureIface;
import com.hellobike.rent.base.data.resp.CityConfigureResp;
import com.hellobike.rent.common.iface.resp.ServiceResp;
import com.hellobike.soa.rpc.RpcClientHelper;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author created by zhangqiang05740
 * @date Created in 2019/9/5 3:11 PM
 * @description: 城市配置查询helper
 **/
@Component
public class CityConfigureHelper {

    /**
     * 获取城市配置
     * @return   城市list
     */
    public List<CityConfigureResp> queryAllCityConfigure(){
        ServiceResp<List<CityConfigureResp>> serviceResp = RpcClientHelper.getClient(CityConfigureIface.class).queryAllCityConfigure();
        if (serviceResp != null && serviceResp.isSuccess()){
            return serviceResp.getData();
        }
        return null;
    }
}
