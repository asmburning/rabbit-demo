package com.hellobike.rent.order.sync.web.job;

import com.hellobike.base.flexjob.common.participant.ParticipantParams;
import com.hellobike.base.flexjob.participant.starter.spring.JobHandle;
import com.hellobike.rent.order.sync.web.innerservice.TmallOrderErrorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author liuxinyi
 * @date 2019/9/25
 */
@Service
@JobHandle
public class TmallErrorRetryJob {
    @Autowired
    private TmallOrderErrorService errorService;

    /**
     * 天猫订单支付重构--》聚石塔更新失败重试
     */
    public void retryTidPayUpdateError(ParticipantParams participantParams) {
        // 无需物流交互的
        errorService.dealTidPayUpdateError();
    }

    /**
     * 天猫订单完成--》聚石塔更新失败重试
     */
    public void retryTidFinishUpdateError(ParticipantParams participantParams) {
        // 无需物流交互的
        errorService.dealTidFinishUpdateError();
    }

    /**
     * 天猫订单退款--》聚石塔更新失败重试
     */
    public void retryOidRefundSuccessUpdateError(ParticipantParams participantParams) {
        // 无需物流交互的
        errorService.dealOidRefundSuccessUpdateError();
    }

}
