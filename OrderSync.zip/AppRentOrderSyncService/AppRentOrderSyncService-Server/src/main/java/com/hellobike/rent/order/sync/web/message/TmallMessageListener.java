package com.hellobike.rent.order.sync.web.message;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ctrip.framework.apollo.Config;
import com.ctrip.framework.apollo.spring.annotation.ApolloConfig;
import com.hellobike.rent.order.sync.web.config.TmallConfig;
import com.hellobike.rent.order.sync.web.innerservice.TmallOrderAnalysisService;
import com.hellobike.rent.order.sync.web.innerservice.TmallOrderEventService;
import com.taobao.api.internal.tmc.Message;
import com.taobao.api.internal.tmc.TmcClient;
import com.taobao.api.internal.toplink.LinkException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.HashSet;
import java.util.Set;

@Component
@Slf4j
public class TmallMessageListener {

    private static Set<String> topics = new HashSet<String>() {{
        add("taobao_trade_TradeCreate");//下单未支付---{"buyer_nick":"王亚念","payment":"39.00","status":"TRADE_NO_CREATE_PAY","iid":602144343504,"oid":605344675785185825,"tid":605344675785185825,"type":"guarantee_trade","post_fee":"0.00","seller_nick":"哈啰车服电动车旗舰店"}
        add("taobao_trade_TradeBuyerPay");
        add("taobao_trade_TradeChanged");//taobao_trade_TradeChanged---{"buyer_nick":"王亚念","payment":"39.00","status":"WAIT_SELLER_SEND_GOODS","iid":602144343504,"oid":605344675785185825,"tid":605344675785185825,"type":"guarantee_trade","seller_nick":"哈啰车服电动车旗舰店"}
        add("taobao_trade_TradeSuccess");//交易完成
        add("taobao_trade_TradeClose");//交易关闭

        add("taobao_refund_RefundCreated");//申请退款
//        add("taobao_refund_RefundSellerRefuseAgreement");//卖家拒绝退款
        add("taobao_refund_RefundSellerAgreeAgreement");//卖家同意退款
        add("taobao_refund_RefundSuccess");//退款成功
//        add("taobao_refund_RefundClosed");//退款失败关闭

    }};

    @Autowired
    TmallOrderEventService tmallOrderEventService;

    @ApolloConfig
    private Config config;

    @Autowired
    private TmallConfig tmallConfig;

    @Value("${tmall.message.listen}")
    private Boolean listenMessage;

    @Autowired
    private TmallOrderAnalysisService analysisService;

    public void onMessage() throws LinkException {
        TmcClient client = new TmcClient(tmallConfig.getAppKey(), tmallConfig.getSecret(), "default");
        client.setMessageHandler((message, status) -> {
            try {
                log.info("TmallMessageListenReceiveMessage topic:{} message:{},status:{}",
                        message.getTopic(), JSON.toJSONString(message), JSON.toJSONString(status));
                TmallMessage eventMessage = convertEventMessage(message);
                tmallOrderEventService.receiveTmallEvent(eventMessage);
                // apollo 同步开关
                Boolean booleanProperty = config.getBooleanProperty("rent.tmall.sync", false);
                if (!booleanProperty) {
                    status.fail();
                }
            } catch (Exception e) {
                log.error("TmallMessageListenReceiveMessageError message:{}", message, e);
                status.fail();// 消息处理失败回滚，服务端需要重发
            }
        });
        // 是否监听天猫消息
        if (listenMessage) {
            client.connect(tmallConfig.getTaobaoWsUrl());
        }
    }

    public TmallMessage convertEventMessage(Message message) {
        JSONObject contentJsonObj = JSON.parseObject(message.getContent());
        TmallMessage eventMessage = TmallMessage.builder()
                .id(message.getId())
                .userNick(message.getUserNick())
                .tmallTopic(message.getTopic())
                .content(message.getContent())
                .tid(contentJsonObj.getLong("tid"))
                .oid(contentJsonObj.getLong("oid"))
                .status(contentJsonObj.getString("status"))
                .build();
        analysisService.analysisEventType(eventMessage);
        return eventMessage;
    }

}
