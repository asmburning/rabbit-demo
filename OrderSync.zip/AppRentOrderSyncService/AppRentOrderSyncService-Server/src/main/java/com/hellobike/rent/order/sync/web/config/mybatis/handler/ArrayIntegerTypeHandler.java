package com.hellobike.rent.order.sync.web.config.mybatis.handler;

import org.apache.ibatis.type.MappedTypes;

import java.sql.Array;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * @author wt
 * @since 1.0.0
 */
@MappedTypes(Integer[].class)
public class ArrayIntegerTypeHandler extends AbstractArrayTypeHandler<Integer> {

    @Override
    protected Array createArray(Connection conn, Integer[] integers) throws SQLException {
        return conn.createArrayOf("integer", integers);
    }
}
