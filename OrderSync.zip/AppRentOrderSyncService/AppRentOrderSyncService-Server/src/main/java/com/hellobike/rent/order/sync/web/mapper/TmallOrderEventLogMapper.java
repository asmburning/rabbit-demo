package com.hellobike.rent.order.sync.web.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hellobike.rent.order.sync.web.model.TmallOrderEventLogEntity;

/**
 * @author liuxinyi
 * @date 2019/9/3
 */
public interface TmallOrderEventLogMapper extends BaseMapper<TmallOrderEventLogEntity> {
}
