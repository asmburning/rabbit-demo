package com.hellobike.rent.order.sync.web.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hellobike.rent.order.sync.web.model.TmallMainOrderEntity;

/**
 * @author liuxinyi
 * @date 2019/8/30
 */
public interface TmallMainOrderMapper extends BaseMapper<TmallMainOrderEntity> {
}
