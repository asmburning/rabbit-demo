package com.hellobike.rent.order.sync.web.reconciliation;

import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.hellobike.base.redis.core.client.RedisClientManagement;
import com.hellobike.base.redis.core.model.key.Key;
import com.hellobike.rent.order.sync.enums.EnumTmallGoodsType;
import com.hellobike.rent.order.sync.enums.EnumTmallOrderStatus;
import com.hellobike.rent.order.sync.enums.EnumTmallReconMessageType;
import com.hellobike.rent.order.sync.web.cache.NewRedisKey;
import com.hellobike.rent.order.sync.web.innerservice.*;
import com.hellobike.rent.order.sync.web.mapper.TmallMainOrderMapper;
import com.hellobike.rent.order.sync.web.mapper.TmallReconciliationMapper;
import com.hellobike.rent.order.sync.web.mapper.TmallSubOrderMapper;
import com.hellobike.rent.order.sync.web.model.TmallMainOrderEntity;
import com.hellobike.rent.order.sync.web.model.TmallSubOrderEntity;
import com.hellobike.rent.order.sync.web.util.ExceptionUtils;
import com.hellobike.rent.order.sync.web.util.XDateUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

/**
 * 子订单只有一个的时候 tid=oid
 * 天猫支付消息 以tid为维度 多笔子订单也只有一条支付消息
 * 天猫取消消息 以oid为维度
 *
 * @author liuxinyi
 * @date 2019/9/26
 */
@Component
@Slf4j
public class ReconciliationMessageComponent {

    @Autowired
    private TmallMainOrderService mainOrderService;
    @Autowired
    private TmallSubOrderService subOrderService;
    @Autowired
    private TmallMainOrderMapper mainOrderMapper;
    @Autowired
    private TmallSubOrderMapper subOrderMapper;
    @Autowired
    private OrderEnvService orderEnvService;
    @Autowired
    private TmallReconciliationMapper reconciliationMapper;
    @Autowired
    private TmallOrderInnerService innerService;
    @Autowired
    private TmallReconciliationComponent reconciliationComponent;
    @Autowired
    private TmallSendMqService sendMqService;
    @Autowired
    private TmallOrderErrorService errorService;
    @Autowired
    private TmallOrderAnalysisService analysisService;

    private boolean canHandleMessage(Key key, String messageType) {
        String set = RedisClientManagement.getInstance().set(key,
                messageType, "NX", "EX", 60);
        if (StringUtils.equals("OK", set)) {
            return true;
        }
        return false;
    }

    private boolean canHandleMessage(Key key, EnumTmallReconMessageType messageType) {
        String set = RedisClientManagement.getInstance().set(key,
                messageType.getReconType(), "NX", "EX", 60);
        if (StringUtils.equals("OK", set)) {
            return true;
        }
        return false;
    }

    private boolean messageHandled(Key key) {
        String value = RedisClientManagement.getInstance().get(key);
        return StringUtils.isNotBlank(value);
    }

    private boolean markMessageHandled(Key key, String messageType) {
        String value = messageType + XDateUtils.currentDateString();
        String s = RedisClientManagement.getInstance().set(key, value, 3600 * 24 * 15);
        return StringUtils.isNotBlank(s);
    }

    private boolean markMessageHandled(Key key, EnumTmallReconMessageType messageType) {
        String value = messageType.getReconType() + XDateUtils.currentDateString();
        String s = RedisClientManagement.getInstance().set(key, value, 3600 * 24 * 15);
        return StringUtils.isNotBlank(s);
    }

    /**
     * @param tid
     */
    public void reconciliationTidPayMessage(Long tid) {
        log.info("reconciliationTidPayMessage tid:{}", tid);
        try {
            mainOrderService.updateByTid(tid);
            errorService.updateErrorHandled(tid, null, EnumTmallReconMessageType.TID_PAY_UPDATE);
        } catch (Exception e) {
            log.error("reconciliationTidPayMessageError tid:{}", tid, e);
            errorService.logError(tid, tid, EnumTmallReconMessageType.TID_PAY_UPDATE, ExceptionUtils.shortMessage(e, 4));
            return;
        }
        TmallMainOrderEntity mainOrderEntity = mainOrderService.selectByTid(tid);
        List<TmallSubOrderEntity> subOrderEntityList = subOrderService.querySkuNotNoneListByTid(tid);
        if (null == mainOrderEntity || CollectionUtils.isEmpty(subOrderEntityList)) {
            log.error("reconciliationTidPayMessageError not exist tid:{}", tid);
            return;
        }

        for (TmallSubOrderEntity subOrderEntity : subOrderEntityList) {
            if (StringUtils.equals(subOrderEntity.getGoodsType(), EnumTmallGoodsType.POWER_SELL.getType())) {
                doHandleOidMessage(mainOrderEntity, subOrderEntity, EnumTmallReconMessageType.OID_SELL_PAY);
            } else if (StringUtils.equals(subOrderEntity.getGoodsType(), EnumTmallGoodsType.POWER_RENT.getType())) {
                doHandleOidMessage(mainOrderEntity, subOrderEntity, EnumTmallReconMessageType.OID_RENT_PAY);
            }
        }
        doHandleTidMessage(mainOrderEntity, EnumTmallReconMessageType.TID_SELL_DELIVERY);

        log.info("reconciliationTidPayMessageSuccess tid:{}", tid);
    }

    public void doHandleTidMessage(TmallMainOrderEntity mainOrderEntity, EnumTmallReconMessageType reconMessageType) {
        Key key = NewRedisKey.canHandleMessage(mainOrderEntity.getTid(), reconMessageType);
        Key handledKey = NewRedisKey.messageHandledMark(mainOrderEntity.getTid(), reconMessageType);
        if (canHandleMessage(key, reconMessageType)) {
            if (messageHandled(handledKey)) {
                log.info("doHandleTidMessageAlreadyDone tid:{} messageType:{}", mainOrderEntity.getTid(), reconMessageType.getReconType());
                return;
            }
            try {
                log.info("doHandleTidMessageBegin tid:{} messageType:{}", mainOrderEntity.getTid(), reconMessageType.getReconType());
                if (reconMessageType == EnumTmallReconMessageType.TID_SELL_DELIVERY) {
                    sendMqService.sendSellDeliveryMessage(mainOrderEntity.getTid());
                    markMessageHandled(handledKey, reconMessageType);
                    log.info("doHandleTidMessageSuccess tid:{}, messageType:{}", mainOrderEntity.getTid(), reconMessageType.getReconType());
                }
            } catch (Exception e) {
                log.error("doHandleTidMessageError tid:{}  messageType:{}", mainOrderEntity.getTid(), reconMessageType.getReconType(), e);
                errorService.logError(mainOrderEntity.getTid(), mainOrderEntity.getTid(), reconMessageType, ExceptionUtils.shortMessage(e, 4));
            } finally {
                RedisClientManagement.getInstance().del(key);
            }
        }
    }

    public void doHandleOidMessage(TmallMainOrderEntity mainOrderEntity, TmallSubOrderEntity subOrderEntity, EnumTmallReconMessageType reconMessageType) {
        Key key = NewRedisKey.canHandleMessage(subOrderEntity.getTid(), subOrderEntity.getOid(), reconMessageType);
        Key handledKey = NewRedisKey.messageHandledMark(subOrderEntity.getTid(), subOrderEntity.getOid(), reconMessageType);
        // 能不能处理消息，防止并发重复处理
        if (canHandleMessage(key, reconMessageType)) {
            // 消息有没有处理成功
            if (messageHandled(handledKey)) {
                log.info("doHandleOidMessageAlreadyDone tid:{}, oid:{} MessageType:{}",
                        mainOrderEntity.getTid(), subOrderEntity.getOid(), reconMessageType);
                return;
            }
            if (analysisService.canGoodsTypeSkipWork(subOrderEntity.getGoodsType())) {
                log.info("doHandleOidMessageSkipWork tid:{}, oid:{}, MessageType:{}",
                        subOrderEntity.getTid(), subOrderEntity.getOid(), reconMessageType);
                return;
            }
            log.info("doHandleOidMessageBegin tid:{}, oid:{}, MessageType:{}",
                    mainOrderEntity.getTid(), subOrderEntity.getOid(), reconMessageType.getReconType());
            try {
                if (reconMessageType == EnumTmallReconMessageType.OID_SELL_PAY) {
                    sendMqService.sendSellInitPaidDeliveryMessage(mainOrderEntity, subOrderEntity);
                } else if (reconMessageType == EnumTmallReconMessageType.OID_RENT_PAY) {
                    sendMqService.sendRentPaidMessage(mainOrderEntity, subOrderEntity);
                } else if (reconMessageType == EnumTmallReconMessageType.OID_REFUND_SUCCESS) {
                    sendMqService.sendOrderRefundMessage(mainOrderEntity, subOrderEntity);
                } else if (reconMessageType == EnumTmallReconMessageType.OID_FINISH) {
                    sendMqService.sendOrderFinishedMessage(mainOrderEntity, subOrderEntity);
                } else if (reconMessageType == EnumTmallReconMessageType.OID_REFUND_CLOSED) {
                    sendMqService.sendOrderRefundClosedMessage(mainOrderEntity, subOrderEntity);
                }
                markMessageHandled(handledKey, reconMessageType);
                log.info("end doHandleOidMessage tid:{}, oid:{}, type:{}", mainOrderEntity.getTid(), subOrderEntity.getOid(), reconMessageType.getReconType());

            } catch (Exception e) {
                log.error("doHandleOidMessageError tid:{} oid:{} type:{}",
                        mainOrderEntity.getTid(), subOrderEntity.getOid(), reconMessageType.getReconType(), e);
                errorService.logError(mainOrderEntity.getTid(), subOrderEntity.getOid(), reconMessageType, ExceptionUtils.shortMessage(e, 4));
            } finally {
                RedisClientManagement.getInstance().del(key);
            }
        }
    }

    public void reconciliationTidFinishMessage(Long tid) {
        try {
            mainOrderService.updateByTid(tid);
            errorService.updateErrorHandled(tid, null, EnumTmallReconMessageType.TID_FINISH_UPDATE);
        } catch (Exception e) {
            log.error("reconOidRefundSuccessMessageUpdateError tid:{}", tid, e);
            errorService.logError(tid, tid,
                    EnumTmallReconMessageType.TID_FINISH_UPDATE, ExceptionUtils.shortMessage(e, 4));
            return;
        }
        TmallMainOrderEntity mainOrderEntity = mainOrderService.selectByTid(tid);
        List<TmallSubOrderEntity> subOrderEntityList = subOrderService.querySkuNotNoneListByTid(tid);
        if (null == mainOrderEntity || CollectionUtils.isEmpty(subOrderEntityList)) {
            log.info("reconciliationTidFinishMessageError not exist tid:{}", tid);
            return;
        }
        subOrderEntityList = subOrderEntityList.stream()
                .filter(subOrderEntity -> subOrderEntity.getStatus().equals(EnumTmallOrderStatus.TRADE_FINISHED.getStatus()))
                .collect(Collectors.toList());
        if (CollectionUtils.isEmpty(subOrderEntityList)) {
            log.info("reconciliationTidFinishMessageError noneFinishedSubOrder tid:{}", tid);
            return;
        }
        subOrderEntityList.forEach(subOrderEntity ->
                doReconOidDependMessage(subOrderEntity, mainOrderEntity, EnumTmallReconMessageType.OID_FINISH));
    }

    public void reconOidRefundSuccessMessage(Long tid, Long oid) {
        try {
            mainOrderService.updateByTid(tid);
            errorService.updateErrorHandled(tid, oid, EnumTmallReconMessageType.OID_REFUND_SUCCESS_UPDATE);
        } catch (Exception e) {
            log.error("reconOidRefundSuccessMessageUpdateError tid:{}, oid:{}", tid, oid, e);
            errorService.logError(tid, oid,
                    EnumTmallReconMessageType.OID_REFUND_SUCCESS_UPDATE, ExceptionUtils.shortMessage(e, 4));
            return;
        }
        TmallSubOrderEntity subOrderEntity = subOrderService.queryByOid(oid);
        if (null == subOrderEntity) {
            log.info("reconOidRefundSuccessMessageNotExistOid:{}", oid);
            return;
        }

        if (analysisService.canGoodsTypeSkipWork(subOrderEntity.getGoodsType())) {
            log.info("reconOidRefundSuccessMessageSkipWork tid:{}, oid:{}", tid, oid);
            return;
        }

        if (StringUtils.equals("SUCCESS", subOrderEntity.getRefundStatus()) ||
                StringUtils.equals("TRADE_FINISHED", subOrderEntity.getStatus())) {
            log.info("reconOidRefundSuccessMessageBegin tid:{}, oid:{} status:{}", tid, oid, subOrderEntity.getStatus());
            TmallMainOrderEntity mainOrderEntity = mainOrderService.selectByTid(subOrderEntity.getTid());
            doReconOidDependMessage(subOrderEntity, mainOrderEntity, EnumTmallReconMessageType.OID_REFUND_SUCCESS);
            return;
        } else {
            log.info("reconOidRefundSuccessMessageRefundNotSuccess tid:{}, oid:{}", tid, oid);
            return;
        }

    }

    private void doReconOidDependMessage(TmallSubOrderEntity subOrderEntity,
                                         TmallMainOrderEntity mainOrderEntity,
                                         EnumTmallReconMessageType finalState) {
        Key sellDeliveryKey = NewRedisKey.messageHandledMark(mainOrderEntity.getTid(), EnumTmallReconMessageType.TID_SELL_DELIVERY);
        if (!messageHandled(sellDeliveryKey)) {
            doHandleTidMessage(mainOrderEntity, EnumTmallReconMessageType.TID_SELL_DELIVERY);
        }
        if (subOrderEntity.getGoodsType().equals(EnumTmallGoodsType.POWER_SELL.getType())) {
            Key oidPayKey = NewRedisKey.messageHandledMark(mainOrderEntity.getTid(), subOrderEntity.getOid(), EnumTmallReconMessageType.OID_SELL_PAY);
            if (!messageHandled(oidPayKey)) {
                doHandleOidMessage(mainOrderEntity, subOrderEntity, EnumTmallReconMessageType.OID_SELL_PAY);
            }
            if (!messageHandled(oidPayKey)) {
                errorService.logError(mainOrderEntity.getTid(), subOrderEntity.getOid(), finalState,
                        "OID_SELL_PAY--not-handled");
            } else {
                doHandleOidMessage(mainOrderEntity, subOrderEntity, finalState);
            }
        } else if (subOrderEntity.getGoodsType().equals(EnumTmallGoodsType.POWER_RENT.getType())) {
            Key oidPayKey = NewRedisKey.messageHandledMark(mainOrderEntity.getTid(), subOrderEntity.getOid(), EnumTmallReconMessageType.OID_RENT_PAY);
            if (!messageHandled(oidPayKey)) {
                doHandleOidMessage(mainOrderEntity, subOrderEntity, EnumTmallReconMessageType.OID_RENT_PAY);
            }
            if (!messageHandled(oidPayKey)) {
                errorService.logError(mainOrderEntity.getTid(), subOrderEntity.getOid(), finalState,
                        "OID_RENT_PAY--not-handled");
            } else {
                doHandleOidMessage(mainOrderEntity, subOrderEntity, finalState);
            }
        } else {
            Key handledKey = NewRedisKey.messageHandledMark(subOrderEntity.getTid(), subOrderEntity.getOid(), finalState);
            markMessageHandled(handledKey, EnumTmallReconMessageType.OID_UNKNOWN);
            errorService.logError(mainOrderEntity.getTid(), subOrderEntity.getOid(), EnumTmallReconMessageType.OID_UNKNOWN,
                    "unknown goods type");
        }
    }


    /**
     * 处理配送工单消息
     * 申请、同意、 （退款、完成 分别由refund,finish处理）
     *
     * @param tid
     * @param oid
     */
    public void reconciliationBosDeliveryOrderMessageMessage(Long tid, Long oid, String messageType) {

        try {
            mainOrderService.updateByTid(tid);
        } catch (Exception e) {
            errorService.logError(tid, oid, messageType, ExceptionUtils.shortMessage(e, 4));
            return;
        }
        Key key = NewRedisKey.canHandleMessage(tid, oid, messageType);
        if (canHandleMessage(key, messageType)) {
            Key handledKey = NewRedisKey.messageHandledMark(tid, oid, messageType);
            try {
                if (messageHandled(handledKey)) {
                    log.info("reconciliationBosDeliveryOrderMessageMessage alreadyDone tid:{}, oid:{}, messageType:{}",
                            tid, oid, messageType);
                }
                TmallMainOrderEntity mainOrderEntity = mainOrderMapper.selectById(tid);
                TmallSubOrderEntity subOrderEntity = subOrderMapper.selectById(oid);
                String goodsType = analysisService.analysisGoodsType(subOrderEntity.getOuterSkuId());
                // 非售车订单不用发送配送工单消息
                if (!StringUtils.equals(goodsType, EnumTmallGoodsType.POWER_SELL.getType())) {
                    log.info("reconciliationBosDeliveryOrderMessageMessage power_rent tid:{}, oid:{}, messageType:{}",
                            tid, oid, messageType);
                    return;
                }
                sendMqService.sendBosDeliveryOrderMessage(mainOrderEntity, subOrderEntity, messageType);
                markMessageHandled(handledKey, messageType);
            } catch (Exception e) {
                log.error("reconciliationBosDeliveryOrderMessageMessageError tid:{} oid:{} messageType:{}",
                        tid, oid, messageType, e);
                errorService.logError(tid, oid, messageType, ExceptionUtils.shortMessage(e, 4));
            } finally {
                RedisClientManagement.getInstance().del(key);
            }
        }
    }

    public void reconRefundCloseMessage(Long tid, Long oid) {
        try {
            mainOrderService.updateByTid(tid);
            errorService.updateErrorHandled(tid, oid, EnumTmallReconMessageType.OID_REFUND_CLOSED_UPDATE);
        } catch (Exception e) {
            log.error("reconRefundCloseMessageUpdateError tid:{}, oid:{}", tid, oid, e);
            errorService.logError(tid, oid,
                    EnumTmallReconMessageType.OID_REFUND_CLOSED_UPDATE, ExceptionUtils.shortMessage(e, 4));
            return;
        }
        TmallSubOrderEntity subOrderEntity = subOrderService.queryByOid(oid);
        if (null == subOrderEntity) {
            log.info("reconRefundCloseMessageOidNotExist:{}", oid);
            return;
        }
        TmallMainOrderEntity mainOrderEntity = mainOrderService.selectByTid(tid);
        doHandleOidMessage(mainOrderEntity, subOrderEntity, EnumTmallReconMessageType.OID_REFUND_CLOSED);
    }
}
