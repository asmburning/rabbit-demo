package com.hellobike.rent.order.sync.web.innerservice;

import com.alibaba.fastjson.JSON;
import com.taobao.api.ApiException;
import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;
import com.taobao.api.request.LogisticsOfflineSendRequest;
import com.taobao.api.request.TmcUserPermitRequest;
import com.taobao.api.response.LogisticsOfflineSendResponse;
import com.taobao.api.response.TmcUserPermitResponse;

public class TmallMainTest {

    private static TaobaoClient taobaoClient =  new DefaultTaobaoClient("http://gw.api.taobao.com/router/rest", "27810288", "aa1a9f83e158ae548b53542d2d9bdd9c");
    private static String sessionKy = "6100107283976651bfe4689a559cb97359714e0a18f116b2206456792674";


    private static void OnlineSend(long tid, String oid, String deliveryNo, long is_split ) throws ApiException {
        LogisticsOfflineSendRequest req = new LogisticsOfflineSendRequest();
        req.setTid(tid);
        req.setSubTid(oid);
        req.setIsSplit(is_split);
        req.setOutSid(deliveryNo);
        req.setCompanyCode("DISTRIBUTOR_30145884");
        LogisticsOfflineSendResponse rsp  = taobaoClient.execute(req, sessionKy);
        System.out.println(JSON.toJSONString(rsp));
    }

    private static void permit(){
        TmcUserPermitRequest req = new TmcUserPermitRequest();
        StringBuffer sb = new StringBuffer();
        sb.append("taobao_trade_TradeCreate").append(",")
                .append("taobao_trade_TradeBuyerPay").append(",")
                .append("taobao_trade_TradeChanged").append(",")
                .append("taobao_trade_TradeSuccess").append(",")
                .append("taobao_trade_TradeClose").append(",")

                .append("taobao_refund_RefundCreated").append(",")
                .append("taobao_refund_RefundSellerRefuseAgreement").append(",")
                .append("taobao_refund_RefundSellerAgreeAgreement").append(",")
                .append("taobao_refund_RefundSuccess").append(",")
                .append("taobao_refund_RefundClosed").append(",");
        req.setTopics(sb.toString());
        TmcUserPermitResponse rsp = null;
        try {
            rsp = taobaoClient.execute(req, sessionKy);
        } catch (ApiException e) {
            e.printStackTrace();
        }
        System.out.println(rsp.getBody());
    }

    private static void getCompany(){
        permit();
    }

    public static void main(String[] args) throws ApiException {
        OnlineSend(565873773598303401L,565873773598303401L+"",String.valueOf(1182212965697179659L),1L);

    }
}
