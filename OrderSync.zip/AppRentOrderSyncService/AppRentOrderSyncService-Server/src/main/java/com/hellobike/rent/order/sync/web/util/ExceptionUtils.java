package com.hellobike.rent.order.sync.web.util;

import com.google.common.collect.Sets;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.Set;

/**
 * @author liuxinyi
 * @date 2019/9/25
 */
@Slf4j
public class ExceptionUtils {

    private static final Set<String> UPPER_SET = Sets.newHashSet(
            "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N",
            "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"
    );

    public static final String defaultPackageName = "com.hellobike.rent.order.sync";

    public static String shortMessage(Exception e, int depth) {
        return shortMessage(e, depth, defaultPackageName);
    }

    public static String shortMessage(Exception e, int depth, String packageName) {
        if (null == e) {
            return null;
        }
        if (StringUtils.isBlank(packageName)) {
            packageName = "com.hellobike.rent";
        }
        StringBuilder sb = new StringBuilder();
        sb.append(e.getClass().getCanonicalName()).append(":");
        String message = e.getMessage();
        if (StringUtils.isNotBlank(message)) {
            if (message.length() > 100) {
                message = message.substring(0, 100);
            }
            sb.append(message).append("--");
        }
        int packageCount = 0;
        StackTraceElement[] stackTrace = e.getStackTrace();

        depth = stackTrace.length > depth ? depth : stackTrace.length;

        for (int i = 0; i < stackTrace.length; i++) {
            String trace = stackTrace[i].toString();
            boolean contain = false;
            if (trace.contains(packageName)) {
                packageCount += 1;
                contain = true;
            }
            if (i <= depth || contain) {
                sb.append("--");
                appendBrief(sb, trace);
            } else if (i > depth && packageCount > 1) {
                break;
            }
        }
        String s = sb.toString();
        if (s.length() > 400) {
            return s.substring(0, 400);
        }
        return s;
    }

    private static void appendBrief(StringBuilder builder, String stackTrace) {
        if (StringUtils.isBlank(stackTrace)) {
            return;
        }
        String[] split = stackTrace.split("\\.");
        for (int i = 0; i < split.length; i++) {
            if (i < 3) {
                builder.append(split[i].substring(0, 1));
            } else {
                builder.append(split[i]);
            }
            builder.append(".");
        }

    }

    public static void main(String[] args) {
        try {
            throw new RuntimeException("hehe");
        } catch (Exception e) {
            String msg = shortMessage(e, 4);
            log.info(msg);
        }
    }
}
