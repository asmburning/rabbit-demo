package com.hellobike.rent.order.sync.web.innerservice.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ctrip.framework.apollo.Config;
import com.ctrip.framework.apollo.spring.annotation.ApolloConfig;
import com.google.common.collect.Lists;
import com.hellobike.base.redis.core.client.RedisClientManagement;
import com.hellobike.base.redis.core.model.key.Key;
import com.hellobike.rent.base.data.resp.CityConfigureResp;
import com.hellobike.rent.base.data.resp.model.SpecBasicInfoResp;
import com.hellobike.rent.common.soa2.helper.DictionaryServiceHelper;
import com.hellobike.rent.order.sync.enums.EnumTmallGoodsType;
import com.hellobike.rent.order.sync.vo.SkuInfo;
import com.hellobike.rent.order.sync.web.cache.NewRedisKey;
import com.hellobike.rent.order.sync.web.helper.BikeHelper;
import com.hellobike.rent.order.sync.web.helper.CityConfigureHelper;
import com.hellobike.rent.order.sync.web.innerservice.TmallOrderAnalysisService;
import com.hellobike.rent.order.sync.web.innerservice.TmallOrderInnerService;
import com.hellobike.rent.order.sync.web.message.TmallMessage;
import com.hellobike.rent.order.sync.web.model.TmallMainOrderEntity;
import com.hellobike.rent.order.sync.web.util.ExceptionUtils;
import com.hellobike.rent.order.sync.web.util.ThreadUtils;
import com.hellobike.rent.order.sync.web.util.YunLogger;
import com.taobao.api.domain.Trade;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;

import static com.hellobike.rent.order.sync.enums.EnumTmallMessageEvent.*;

/**
 * @author created by zhangqiang05740
 * @date Created in 2019/9/5 11:08 AM
 * @description: 天猫订单信息解析实现类
 **/
@Slf4j
@Service
public class TmallOrderAnalysisServiceImpl implements TmallOrderAnalysisService {
    @Autowired
    private CityConfigureHelper cityConfigureHelper;
    @Autowired
    private BikeHelper bikeHelper;
    @ApolloConfig
    private Config config;
    @Autowired
    private YunLogger yunLogger;
    @Autowired
    private TmallOrderInnerService innerService;
    @Value("${env}")
    public String env;

    private transient boolean cityInit = false;

    private static volatile Map<String, String> cityNameCodeMap = new ConcurrentHashMap<>(512);

    @Scheduled(initialDelay = 13 * 1000, fixedRate = 30 * 1000)
    public void refreshCityNameCodeMap() {
        log.info("refreshCityNameCodeMap");
        try {
            List<CityConfigureResp> configureList = cityConfigureHelper.queryAllCityConfigure();
            configureList.forEach(cityConfigureResp -> cityNameCodeMap.put(cityConfigureResp.getCityName(), cityConfigureResp.getCityCode()));
            cityInit = true;
        } catch (Exception e) {
            log.error("refreshCityNameCodeMapError msg:{}", ExceptionUtils.shortMessage(e, 5));
        }
    }

    public Map<String, String> getCityNameCodeMap() {
        if (!cityInit) {
            refreshCityNameCodeMap();
        }
        return cityNameCodeMap;
    }

    @Override
    public String analysisStore(TmallMainOrderEntity mainOrderEntity) {
        return mainOrderEntity.getOmnichannelParam().getString("targetStoreOuterId");
    }

    /**
     * 根据传入城市信息，解析成哈啰城市code
     *
     * @param receiverPlace 传入天猫城市信息
     * @return 城市code
     */
    private String analysisReceiver(String receiverPlace) {
        if (StringUtils.isBlank(receiverPlace)) {
            return null;
        }
        Map<String, String> cityNameCodeMap = getCityNameCodeMap();
        String cityCode = cityNameCodeMap.get(receiverPlace);
        if (StringUtils.isBlank(cityCode)) {
            //没有获取到数据，将检索字符串最后一位去掉，重新检索
            cityCode = cityNameCodeMap.get(receiverPlace.substring(0, receiverPlace.length() - 1));
        }
        if (StringUtils.isBlank(cityCode)) {
            return null;
        }
        //判断城市是否开放长租电动车业务
        boolean confirmCityActivated = DictionaryServiceHelper.confirmCityActivated(cityCode, null);
        if (confirmCityActivated) {
            return cityCode;
        }
        log.info("{}:未开通电动车业务", cityCode);
        return null;
    }

    @Override
    public String analysisCityCode(String receiverCity, String receiverDistrict) {
        if (StringUtils.isBlank(receiverCity) && StringUtils.isBlank(receiverDistrict)) {
            throw new RuntimeException("城市获取异常");
        }
        log.debug("analysisCityCode receiverCity:{} ,receiverDistrict:{}", receiverCity, receiverDistrict);
        //1、步骤一：使用receiverDistrict 城市下辖区县尝试获取定位城市
        String returnCityCode = analysisReceiver(receiverDistrict);
        if (StringUtils.isBlank(returnCityCode)) {
            //2、步骤二：使用receiverDistrict未获取到城市信息, 使用receiverCity 尝试获取
            returnCityCode = analysisReceiver(receiverCity);
        }
        if (StringUtils.isBlank(returnCityCode)) {
            throw new RuntimeException("城市code解析异常 receiverCity:" + receiverCity + ", receiverDistrict:" + receiverDistrict);
        }
        return returnCityCode;
    }

    @Override
    public SkuInfo analysisSku(String outerSkuId) {
        String goodsType = analysisGoodsType(outerSkuId);
        if (goodsType.equals(EnumTmallGoodsType.POWER_RENT.getType())) {
            //租车时编码规则：${specId}_${orderType}_${tenancy}
            String[] split = outerSkuId.split("_");
            outerSkuId = split[0];
        }
        List<SpecBasicInfoResp> specBasicInfos = bikeHelper.getSpecBasicInfos(Lists.newArrayList(outerSkuId));
        if (CollectionUtils.isEmpty(specBasicInfos)) {
            log.error("analysisSkuError outerSkuIds:{}", outerSkuId);
            throw new RuntimeException("查询商品sku信息（车型、规格）outerSkuId:" + outerSkuId);
        }
        SpecBasicInfoResp specBasicInfo = specBasicInfos.get(0);
        return SkuInfo.builder()
                .modelId(specBasicInfo.getModelId())
                .modelName(specBasicInfo.getModelName())
                .specId(specBasicInfo.getSpecId())
                .specName(specBasicInfo.getSpecName())
                .switchPower(specBasicInfo.getSwitchPower())
                .build();
    }

    @Override
    public void analysisEventType(TmallMessage eventMessage) {
        String topic = eventMessage.getTmallTopic();
        JSONObject contentObj = JSON.parseObject(eventMessage.getContent());
        if (null == contentObj) {
            contentObj = new JSONObject();
        }
        String status = contentObj.getString("status");
        if (StringUtils.equals(eventMessage.getTmallTopic(), "taobao_trade_TradeCreate")) {
            eventMessage.setTopic(WAIT_BUYER_PAY.getEvent());
            return;
        }
        if (StringUtils.equals(eventMessage.getTmallTopic(), "taobao_trade_TradeBuyerPay")) {
            eventMessage.setTopic(WAIT_SELLER_SEND_GOODS.getEvent());
            return;
        } else if (StringUtils.equals(eventMessage.getTmallTopic(), "taobao_trade_TradeChanged")) {
            if (StringUtils.equals("TRADE_CLOSED_BY_TAOBAO", status)) {
                eventMessage.setTopic(WAIT_BUYER_PAY_CANCEL.getEvent());
                return;
            }
        } else if (StringUtils.equals(eventMessage.getTmallTopic(), "taobao_refund_RefundSuccess")) {
            eventMessage.setTopic(TRADE_CLOSED.getEvent());
            return;
        } else if (StringUtils.equals(eventMessage.getTmallTopic(), "taobao_trade_TradeSuccess")) {
            eventMessage.setTopic(TRADE_FINISHED.getEvent());
            return;
        } else if (StringUtils.equals(eventMessage.getTmallTopic(), "taobao_refund_RefundSellerAgreeAgreement")) {
            eventMessage.setTopic(taobao_refund_RefundSellerAgreeAgreement.getEvent());
            return;
        } else if (StringUtils.equals(eventMessage.getTmallTopic(), "taobao_refund_RefundCreated")) {
            eventMessage.setTopic(taobao_refund_RefundCreated.getEvent());
            return;
        } else if (StringUtils.equals(eventMessage.getTmallTopic(), "taobao_refund_RefundClosed")) {
            eventMessage.setTopic(taobao_refund_RefundClosed.getEvent());
            return;
        }
        log.warn("unknownTmcMessage topic:{} ,status:{} ,eventMessage:{}",
                topic, status, eventMessage);
    }


    @Override
    public String analysisEnvByTid(Long tid) {
        Boolean pressureActive = config.getBooleanProperty("tmall.pressure.measurement", false);
        if (pressureActive) {
            log.info("pressureActive analysisEnvByTid return pro tid:{}", tid);
            // 模拟天猫api耗时
            ThreadUtils.sleep(TimeUnit.MILLISECONDS, 300);
            return "pro";
        }

        Key key = NewRedisKey.tidEnv(tid);
        String cache = RedisClientManagement.getInstance().get(key);
        if (StringUtils.isNotBlank(cache)) {
            return cache;
        }
        Trade trade = null;
        try {
            trade = innerService.getOrderFullInfoByTid(tid);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        String title = trade.getOrders().get(0).getTitle();
        String orderEnv = analysisEnvByTitle(title);
        RedisClientManagement.getInstance().set(key, orderEnv, 3600 * 24 * 30);
        return orderEnv;
    }

    @Override
    public String analysisEnvByTitle(String title) {
        String orderEnv = "pro";
        if (StringUtils.isBlank(title)) {
            orderEnv = "pro";
        } else if (title.contains("dev") || title.contains("DEV")) {
            orderEnv = "dev";
        } else if (title.contains("fat") || title.contains("FAT")) {
            orderEnv = "fat";
        } else if (title.contains("uat") || title.contains("UAT")) {
            orderEnv = "uat";
        } else if (title.contains("pro") || title.contains("PRO")) {
            orderEnv = "pro";
        }
        return orderEnv;
    }

    public boolean shouldForward(String orderEnv) {
        if (StringUtils.equalsIgnoreCase(env, orderEnv)) {
            return false;
        }
        return true;
    }

    /**
     * 解析天猫商家编码（区分天猫订单是售车还是租车）
     * 租车：${specId}_${orderType}_${tenancy}
     * 售车：specId
     *
     * @param outerSkuId 预备解析的商家编码
     * @return 租车后额
     */
    public String analysisGoodsType(String outerSkuId) {
        if (StringUtils.isBlank(outerSkuId)) {
            return EnumTmallGoodsType.UNKNOWN.getType();
        }
        String[] strings = outerSkuId.split("_");
        if (strings.length == 1) {
            return EnumTmallGoodsType.POWER_SELL.getType();
        } else if (strings.length > 1) {
            return EnumTmallGoodsType.POWER_RENT.getType();
        } else {
            return EnumTmallGoodsType.UNKNOWN.getType();
        }
    }

    @Override
    public boolean isOuterSkuIdPowerSell(String outerSkuId) {
        String goodsType = analysisGoodsType(outerSkuId);
        return StringUtils.equals(goodsType, EnumTmallGoodsType.POWER_SELL.getType());
    }

    @Override
    public boolean canGoodsTypeSkipWork(String goodsType) {
        if (StringUtils.isBlank(goodsType)) {
            return true;
        }
        if (StringUtils.equals(goodsType, EnumTmallGoodsType.POWER_SELL.getType())) {
            return false;
        }
        if (StringUtils.equals(goodsType, EnumTmallGoodsType.POWER_RENT.getType())) {
            return false;
        }
        return true;
    }
}
