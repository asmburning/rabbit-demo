package com.hellobike.rent.order.sync.web.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.ctrip.framework.apollo.Config;
import com.ctrip.framework.apollo.spring.annotation.ApolloConfig;
import com.google.common.collect.Lists;
import com.hellobike.base.redis.core.client.RedisClientManagement;
import com.hellobike.base.redis.core.model.key.Key;
import com.hellobike.rent.order.sync.enums.EnumTmallOrderStatus;
import com.hellobike.rent.order.sync.enums.EnumTmallReconMessageType;
import com.hellobike.rent.order.sync.web.anno.HelloIpAuth;
import com.hellobike.rent.order.sync.web.cache.NewRedisKey;
import com.hellobike.rent.order.sync.web.innerservice.*;
import com.hellobike.rent.order.sync.web.mapper.TmallOrderErrorMapper;
import com.hellobike.rent.order.sync.web.mapper.TmallReconciliationMapper;
import com.hellobike.rent.order.sync.web.mapper.TmallSubOrderMapper;
import com.hellobike.rent.order.sync.web.message.TmallMessageListener;
import com.hellobike.rent.order.sync.web.model.TmallMainOrderEntity;
import com.hellobike.rent.order.sync.web.model.TmallOrderErrorEntity;
import com.hellobike.rent.order.sync.web.model.TmallSubOrderEntity;
import com.hellobike.rent.order.sync.web.reconciliation.ReconciliationOrderComponent;
import com.hellobike.rent.order.sync.web.reconciliation.TmallReconciliationComponent;
import com.hellobike.rent.order.sync.web.util.ExceptionUtils;
import com.taobao.api.domain.Refund;
import com.taobao.api.domain.Trade;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author liuxinyi
 * @date 2019/9/25
 */
@RestController
@RequestMapping("/reconciliation")
@Slf4j
@HelloIpAuth
public class ReconciliationController {

    @Autowired
    private TmallOrderInnerService innerService;
    @Autowired
    private TmallReconciliationMapper reconciliationMapper;
    @Autowired
    private TmallOrderErrorMapper errorMapper;
    @Autowired
    private OrderEnvService envService;
    @Autowired
    private TmallReconciliationComponent reconciliationComponent;
    @Autowired
    private TmallOrderAnalysisService analysisService;
    @Autowired
    private TmallMainOrderService mainOrderService;
    @Autowired
    private TmallSubOrderService subOrderService;
    @Autowired
    private TmallSubOrderMapper subOrderMapper;
    @Autowired
    private TmallMessageListener tmallMessageListener;
    @ApolloConfig
    private Config config;
    @Autowired
    private ReconciliationOrderComponent orderComponent;

    @RequestMapping("/fullInfo")
    public Object fullInfo(@RequestParam long tid) throws Exception {
        Trade trade = innerService.getOrderFullInfoByTidFromJushita(tid);
        return JSON.toJSONString(trade, SerializerFeature.NotWriteDefaultValue);
    }

    @RequestMapping("/queryErrorLog")
    public Object testTime(@RequestParam String dateString) {
        LocalDate localDate = LocalDate.parse(dateString, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        LocalDateTime startOfDay = localDate.atStartOfDay();
        LocalDateTime endOfDay = startOfDay.plusDays(1).minusSeconds(1);
        List<TmallOrderErrorEntity> dayErrorList = errorMapper.selectList(new QueryWrapper<TmallOrderErrorEntity>()
                .ge("create_time", startOfDay)
                .le("create_time", endOfDay));
        return dayErrorList;
    }

    @RequestMapping("/testFullInfo")
    public Object testFullInfo(@RequestParam Long tid) throws Exception {
        log.info("testFullInfo tid:{}", tid);
        List<Long> times = new ArrayList<>();
        times.add(System.currentTimeMillis());
        Trade orderFullInfoByTid = innerService.getOrderFullInfoByTid(tid);
        log.info(orderFullInfoByTid.getReceiverAddress());
        times.add(System.currentTimeMillis());
        Trade fullInfo = innerService.getOrderFullInfoByTidFromJushita(tid);
        log.info(fullInfo.getPayment());
        times.add(System.currentTimeMillis());
        mainOrderService.updateByTid(tid);
        times.add(System.currentTimeMillis());
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i < times.size(); i++) {
            sb.append(times.get(i) - times.get(i - 1));
            sb.append("---");
        }
        return sb.toString();
    }


    @RequestMapping("/getTmallOrderInfo")
    public Object getTmallOrderInfo(
            @RequestHeader(required = false) String token,
            @RequestParam Long tid) throws Exception {
        String orderEnv = analysisService.analysisEnvByTid(tid);
        if (StringUtils.equals("pro", orderEnv)) {
            String apolloToken = config.getProperty("tmall.queryOrderInfo.token", "lxy@helloBike");
            if (!StringUtils.equals(apolloToken, token)) {
                queryMaskInfo(tid);
            }
        }
        boolean shouldForward = analysisService.shouldForward(orderEnv);
        if (shouldForward) {
            return queryMaskInfo(tid);
        }
        return doQueryInfo(tid, orderEnv);
    }

    private List<Map<String, Object>> queryMaskInfo(Long tid) {
        Trade maskFullInfo = reconciliationComponent.getMaskFullInfo(tid);
        if (null == maskFullInfo) {
            return Lists.newArrayList(new HashMap<String, Object>() {{
                put("tid", "天猫订单不存在");
            }});
        }
        return maskFullInfo.getOrders().stream().map(order -> {
            String analysisEnv = analysisService.analysisEnvByTitle(order.getTitle());
            Map<String, Object> map = new HashMap<>();
            map.put("oid", order.getOid());
            map.put("tid", maskFullInfo.getTid());
            map.put("title", order.getTitle());
            map.put("analysisEnv", analysisEnv);
            map.put("status", order.getStatus());
            map.put("refundStatus", order.getRefundStatus());
            map.put("refundId", order.getRefundId());
            map.put("outerSkuId", order.getOuterSkuId());
            map.put("goodsType", analysisService.analysisGoodsType(order.getOuterSkuId()));
            return map;
        }).collect(Collectors.toList());
    }

    private List<Map<String, Object>> tryUpdate(Long tid) {
        try {
            mainOrderService.updateByTid(tid);
        } catch (Exception e) {
            log.error("tryUpdateTidError", e);
        }
        return queryMaskInfo(tid);

    }


    private List<Map<String, Object>> doQueryInfo(Long tid, String orderEnv) {
        TmallMainOrderEntity mainOrderEntity = mainOrderService.selectByTid(tid);
        List<TmallSubOrderEntity> subOrderEntityList = subOrderService.querySkuNotNoneListByTid(tid);
        if (null == mainOrderEntity || CollectionUtils.isEmpty(subOrderEntityList)) {
            return tryUpdate(tid);
        }

        return subOrderEntityList.stream().map(subOrderEntity -> {
            Map<String, Object> map = new HashMap<String, Object>() {{
                put("orderEnv", orderEnv);
                put("tid", subOrderEntity.getTid());
                put("oid", subOrderEntity.getTid());
                put("title", subOrderEntity.getTitle());
                put("goodsType", subOrderEntity.getGoodsType());
                put("orderPayTime", mainOrderEntity.getPayTime());
            }};

            completeTidHandleState(tid, map);
            completeOidHandleState(tid, subOrderEntity.getOid(), map);

            if (mainOrderEntity != null) {
                map.put("ReceiverCity", mainOrderEntity.getReceiverCity());
                map.put("ReceiverDistrict", mainOrderEntity.getReceiverDistrict());
                map.put("mobile", mainOrderEntity.getReceiverMobile());
                map.put("status", mainOrderEntity.getStatus());
            }
            if (null != subOrderEntity) {
                map.put("outerSkuId", subOrderEntity.getOuterSkuId());
                map.put("payment", subOrderEntity.getPayment());
                map.put("num", subOrderEntity.getNum());
                map.put("subStatus", subOrderEntity.getStatus());
                map.put("refundStatus", subOrderEntity.getRefundStatus());
                map.put("DivideOrderFee", subOrderEntity.getDivideOrderFee());
                map.put("TotalFee", subOrderEntity.getTotalFee());
                String refundId = subOrderEntity.getRefundId();
                if (StringUtils.isNotBlank(refundId)) {
                    map.put("refundId", refundId);
                    try {
                        Refund refund = innerService.getRefundOrderByRefundId(Long.valueOf(refundId));
                        map.put("refundFee", refund.getRefundFee());
                        map.put("refundReason", refund.getReason());
                        map.put("refundDesc", refund.getDesc());
                        map.put("totalFee", refund.getTotalFee());
                        map.put("refundCreated", refund.getCreated());
                        map.put("refundModified", refund.getModified());
                        map.put("goodStatus", refund.getGoodStatus());
                        map.put("HasGoodReturn", refund.getHasGoodReturn());
                        map.put("RefundStatus", refund.getStatus());
                    } catch (Exception e) {
                        map.put("queryRefundErrorMessage", ExceptionUtils.shortMessage(e, 4));
                    }
                }
            }
            List<TmallOrderErrorEntity> errorEntityList = errorMapper.selectList(new QueryWrapper<TmallOrderErrorEntity>()
                    .eq("t_oid", subOrderEntity.getOid()));
            List<String> collect = errorEntityList.stream().map(tmallOrderErrorEntity ->
                    tmallOrderErrorEntity.getErrorType() + "---" + tmallOrderErrorEntity.getErrorMessage()).collect(Collectors.toList());
            map.put("errorList", collect);
            return map;
        }).collect(Collectors.toList());

    }

    private void completeTidHandleState(Long tid, Map<String, Object> map) {
        for (String reconType : EnumTmallReconMessageType.TID_SET) {
            Key handledMark = NewRedisKey.messageHandledMark(tid, reconType);
            map.put(reconType, RedisClientManagement.getInstance().get(handledMark));
        }
    }

    private void completeOidHandleState(Long tid, Long oid, Map<String, Object> map) {
        for (String reconType : EnumTmallReconMessageType.OID_SET) {
            Key handledMark = NewRedisKey.messageHandledMark(tid, oid, reconType);
            map.put(reconType, RedisClientManagement.getInstance().get(handledMark));
        }
    }

    @RequestMapping("/testFilterStepRefund")
    public Object testFilterStepRefund() {
        EnumTmallOrderStatus waitSellerSendGoods = EnumTmallOrderStatus.WAIT_SELLER_SEND_GOODS;
        String status = waitSellerSendGoods.getStatus();
        List<Trade> trades = orderComponent.queryOrderList(status);
        log.info("size:{}", trades.size());
        trades = orderComponent.filterStepRefundTrade(waitSellerSendGoods, trades);
        log.info("size:{}", trades.size());
        return trades.size();
    }

}
