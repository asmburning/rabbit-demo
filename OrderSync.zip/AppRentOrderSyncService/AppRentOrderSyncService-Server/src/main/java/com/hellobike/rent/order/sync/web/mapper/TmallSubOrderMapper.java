package com.hellobike.rent.order.sync.web.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hellobike.rent.order.sync.web.model.TmallSubOrderEntity;
import org.apache.ibatis.annotations.Param;

/**
 * @author liuxinyi
 * @date 2019/8/30
 */
public interface TmallSubOrderMapper extends BaseMapper<TmallSubOrderEntity> {

    int sumNumByTid(@Param("tid") Long tid);
}
