package com.hellobike.rent.order.sync.web.config;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * @author liuxinyi
 * @date 2019/8/30
 */
@Component
@Getter
public class CommonProperties {

    @Value("${apollo.address}")
    private String apolloAddress;

    @Value("${dbExtend.token}")
    private String jdbcToken;

    @Value("${dbExtend.server-host}")
    private String baseConfAddress;

    @Value("${env}")
    private String env;

}
