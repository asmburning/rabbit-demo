package com.hellobike.rent.order.sync.web.message;

import com.alibaba.fastjson.JSON;
import com.hellobike.rent.order.sync.iface.TmsTracePushToCainiaoService;
import com.hellobike.rent.order.sync.req.CainiaoTmsTraceReq;
import com.hellobike.rent.user.common.enums.mq.RentOrderSyncMqConstants;
import com.rabbitmq.client.Channel;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.support.AmqpHeaders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

/**
 * @author liuxinyi
 * @date 2019/9/8
 */
@Component
@Slf4j
public class OrderSyncListener {

    @Autowired
    private TmsTracePushToCainiaoService tmsTracePushToCainiaoService;

    /**
     * 监听bos配送信息
     *
     * @param message
     * @param deliveryTag
     * @param channel
     * @throws Exception
     */
    @RabbitListener(containerFactory = "rentRabbitListenerContainerFactory",
            admin = "rabbitAdmin",
            bindings = @QueueBinding(
                    //持久化队列，当队列没有消费者时，自动删除队列
                    value = @Queue(value = "Q_BOS_TMALL_DELIVERY", durable = "true", autoDelete = "false"),
                    //交换机类型，直接使用默认 direct模式
                    exchange = @Exchange(value = RentOrderSyncMqConstants.EXCHANGER_TOPIC_NAME, durable = "true", type = "topic"),
                    key = "rent.bos.tmall.delivery"))
    public void onBosDeliverySyncMessage(@Payload String message, @Header(AmqpHeaders.DELIVERY_TAG) long deliveryTag, Channel channel) throws Exception {
        log.info("onBosDeliverySyncMessage message {}", message);
        if (StringUtils.isBlank(message)) {
            log.error("messageString is null");
            return;
        }
        try {
            CainiaoTmsTraceReq cainiaoTmsTraceReq = JSON.parseObject(message, CainiaoTmsTraceReq.class);
            boolean b = tmsTracePushToCainiaoService.TmsTracePush(cainiaoTmsTraceReq);
            if (!b) {
                throw new RuntimeException("BosDeliverySyncMessageFailed response:false");
            }
        } catch (Exception e) {
            log.error("BosDeliverySyncMessageFailed message:{}, errorMsg:{}", message, e.getMessage(), e);
            throw e;
        }
    }
}
