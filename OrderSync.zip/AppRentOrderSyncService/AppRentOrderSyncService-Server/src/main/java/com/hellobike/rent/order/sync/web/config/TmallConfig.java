package com.hellobike.rent.order.sync.web.config;

import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@Getter
public class TmallConfig {

    @Value("${tmall.appKey}")
    private String appKey;
    @Value("${tmall.secret}")
    private String secret;
    @Value("${tmall.taobaoApiUrl}")
    private String taobaoApiUrl;
    @Value("${tmall.taobaoWsUrl}")
    private String taobaoWsUrl;
    @Value("${tmall.sessionKey}")
    private String sessionKey;

    @Value("${tmall.jushitaHost}")
    private String jushitaHost;


    @Bean
    public TaobaoClient getTaobaoClient() {
          return new DefaultTaobaoClient(taobaoApiUrl, appKey, secret);
    }



}
