package com.hellobike.rent.order.sync.web.innerservice.impl;

import com.hellobike.rent.order.sync.enums.EnumTmallMessageEvent;
import com.hellobike.rent.order.sync.web.innerservice.TmallOrderAnalysisService;
import com.hellobike.rent.order.sync.web.innerservice.TmallOrderEventService;
import com.hellobike.rent.order.sync.web.manager.TmallOrderEventLogManager;
import com.hellobike.rent.order.sync.web.message.TmallMessage;
import com.hellobike.rent.order.sync.web.message.TmallMessageComponent;
import com.hellobike.rent.order.sync.web.message.TmallMessageForwardComponent;
import com.hellobike.rent.order.sync.web.model.TmallOrderEventLogEntity;
import com.hellobike.rent.order.sync.web.util.ThreadPools;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author liuxinyi
 * @date 2019/9/3
 */
@Service
@Slf4j
public class TmallOrderEventServiceImpl implements TmallOrderEventService {

    @Autowired
    private TmallOrderEventLogManager eventLogManager;

    @Autowired
    private TmallMessageComponent tmallMessageComponent;

    @Autowired
    private TmallOrderAnalysisService analysisService;

    @Autowired
    private TmallMessageForwardComponent forwardComponent;


    @Override
    public void receiveTmallEvent(TmallMessage eventMessage) {
        // 兼容老版本
        if (StringUtils.isBlank(eventMessage.getTopic())) {
            analysisService.analysisEventType(eventMessage);
        }

        String orderEnv = analysisService.analysisEnvByTid(eventMessage.getTid());
        if (analysisService.shouldForward(orderEnv)) {
            forwardComponent.forwardMessage(orderEnv, eventMessage);
            log.info("forwardMessage orderEnv:{},eventMessage:{}", orderEnv, eventMessage);
            return;
        }
        // 无需转发的消息才入库
        TmallOrderEventLogEntity eventLogEntity = TmallOrderEventLogEntity.buildInsert(eventMessage);
        eventLogManager.insert(eventLogEntity);

        final EnumTmallMessageEvent topic = EnumTmallMessageEvent.parse(eventMessage.getTopic());
        // 根据关注的消息类型作出相应的处理
        if (topic == EnumTmallMessageEvent.WAIT_SELLER_SEND_GOODS) {
            ThreadPools.submitTmallMessageTask(() ->
                    tmallMessageComponent.handleTmallPayMessage(eventMessage));
        } else if (topic == EnumTmallMessageEvent.TRADE_CLOSED) {
            tmallMessageComponent.updateRefundId(eventMessage);
            ThreadPools.submitTmallMessageTask(() ->
                    tmallMessageComponent.handleTradeClosedMessage(eventMessage));
        } else if (topic == EnumTmallMessageEvent.TRADE_FINISHED) {
            ThreadPools.submitTmallMessageTask(() ->
                    tmallMessageComponent.handleTradeFinishedMessage(eventMessage));
        } else if (topic == EnumTmallMessageEvent.taobao_refund_RefundCreated) {
            tmallMessageComponent.updateRefundId(eventMessage);
            ThreadPools.submitTmallMessageTask(() ->
                    tmallMessageComponent.handleCancelDeliveryApplyMessage(eventMessage));
        } else if (topic == EnumTmallMessageEvent.taobao_refund_RefundSellerAgreeAgreement) {
            tmallMessageComponent.updateRefundId(eventMessage);
            ThreadPools.submitTmallMessageTask(() ->
                    tmallMessageComponent.handleCancelDeliveryAgreeMessage(eventMessage));
        }else if (topic == EnumTmallMessageEvent.taobao_refund_RefundClosed) {
            tmallMessageComponent.updateRefundId(eventMessage);
            ThreadPools.submitTmallMessageTask(() ->
                    tmallMessageComponent.handleRefundClosedMessage(eventMessage));
        }
    }
}
