package com.hellobike.rent.order.sync.web.innerservice;

import com.hellobike.rent.order.sync.web.model.TmallOrderEnvEntity;

import java.util.List;

/**
 * @author liuxinyi
 * @date 2019/9/29
 */
public interface OrderEnvService {

    List<TmallOrderEnvEntity> queryListByOids(List<Long> oids);

    int insertEnvEntity(Long tid, Long oid, boolean needHandle);
}
