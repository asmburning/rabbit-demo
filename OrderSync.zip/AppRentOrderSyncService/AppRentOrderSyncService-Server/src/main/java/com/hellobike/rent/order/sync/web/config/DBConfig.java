package com.hellobike.rent.order.sync.web.config;

import com.hellobike.druid.datasource.ProxyDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

/**
 * @author liuxinyi
 * @date 2019/8/30
 */
@Configuration
public class DBConfig {

    @Autowired
    private CommonProperties commonProperties;

    @Bean("dataSource")
    public DataSource newDataSource(){
        ProxyDataSource ds = new ProxyDataSource();
        // appId、jdbcToken、baseConfAddress、apolloAddress均可通过jvm参数指定
        ds.setAppId("AppRentOrderSyncService");
        ds.setJdbcToken(commonProperties.getJdbcToken());
        ds.setApolloAddress(commonProperties.getApolloAddress());
        ds.setBaseConfAddress(commonProperties.getBaseConfAddress());
        return ds;
    }
}
