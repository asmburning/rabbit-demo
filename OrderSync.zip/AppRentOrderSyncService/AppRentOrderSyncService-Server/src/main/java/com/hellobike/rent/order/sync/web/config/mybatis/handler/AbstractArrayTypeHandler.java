package com.hellobike.rent.order.sync.web.config.mybatis.handler;

import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;

import java.sql.*;

/**
 * @author wt
 * @since 1.0.0
 */
@Slf4j
public abstract class AbstractArrayTypeHandler<T extends Object> extends BaseTypeHandler<T[]> {

    @Override
    public void setNonNullParameter(PreparedStatement ps, int i, T[] parameter, JdbcType jdbcType) throws SQLException {
        Connection conn = ps.getConnection();
        Array array = createArray(conn, parameter);
        ps.setArray(i, array);
    }

    protected abstract Array createArray(Connection conn, T[] parameter) throws SQLException;

    @Override
    public T[] getNullableResult(ResultSet rs, String columnName) throws SQLException {
        return getArray(rs.getArray(columnName));
    }

    @Override
    public T[] getNullableResult(ResultSet rs, int columnIndex) throws SQLException {
        return getArray(rs.getArray(columnIndex));
    }

    @Override
    public T[] getNullableResult(CallableStatement cs, int columnIndex) throws SQLException {
        return getArray(cs.getArray(columnIndex));
    }

    private T[] getArray(Array array) {
        if (array == null) {
            return null;
        }
        try {
            return (T[]) array.getArray();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return null;
    }
}
