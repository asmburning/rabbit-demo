package com.hellobike.rent.order.sync.web.controller;

import com.alibaba.fastjson.JSON;
import com.ctrip.framework.apollo.Config;
import com.ctrip.framework.apollo.spring.annotation.ApolloConfig;
import com.hellobike.rent.order.sync.web.innerservice.TmallMainOrderService;
import com.hellobike.rent.order.sync.web.innerservice.TmallOrderEventService;
import com.hellobike.rent.order.sync.web.innerservice.TmallSubOrderService;
import com.hellobike.rent.order.sync.web.message.TmallMessage;
import com.hellobike.rent.order.sync.web.message.TmallMessageComponent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

/**
 * @author liuxinyi
 * @date 2019/8/30
 */
@RestController
@Slf4j
@RequestMapping("/tmallMessage")
public class ReceiveForwardMessageController {
    @ApolloConfig
    private Config config;
    @Autowired
    private TmallOrderEventService eventService;
    @Autowired
    private TmallMessageComponent tmallMessageComponent;
    @Autowired
    private TmallMainOrderService mainOrderService;
    @Autowired
    private TmallSubOrderService subOrderService;

    @RequestMapping("/receiveForward")
    public String receiveForward(HttpServletRequest servletRequest,
                                 @RequestBody TmallMessage tmallMessage) {
        log.info("receiveForwardMessage tmallMessage:{}", JSON.toJSONString(tmallMessage));

        Boolean ignoreMessage = config.getBooleanProperty("tmall.ignoreMessage", false);
        if (ignoreMessage) {
            log.info("ignoreMessageActive tmallMessage:{}", JSON.toJSONString(tmallMessage));
            return "OK";
        }

        eventService.receiveTmallEvent(tmallMessage);
        return "OK";
    }

    //@RequestMapping("/testRefundAgree")
    public String receiveForward() {
        // TmallMessage(userNick=哈啰车服电动车旗舰店, id=8436476189405437, topic=taobao_refund_RefundSellerAgreeAgreement,
        // tid=569823599685297202, oid=569823599685297202,
        // content={"buyer_nick":"单车上坡","refund_id":34277998993290272,"refund_fee":"0.10","oid":569823599685297202,"tid":569823599685297202,"refund_phase":"onsale","bill_type":"return_bill","seller_nick":"哈啰车服电动车旗舰店","modified":"2019-10-25 21:23:46"},
        // createTime=0, tmallTopic=taobao_refund_RefundSellerAgreeAgreement, status=null)

        TmallMessage tmallMessage = TmallMessage.builder()
                .userNick("哈啰车服电动车旗舰店")
                .topic("taobao_refund_RefundSellerAgreeAgreement")
                .tid(569823599685297202L)
                .oid(569823599685297202L)
                .tmallTopic("taobao_refund_RefundSellerAgreeAgreement")
                .content("{\"buyer_nick\":\"单车上坡\",\"refund_id\":34277998993290272,\"refund_fee\":\"0.10\",\"oid\":569823599685297202,\"tid\":569823599685297202,\"refund_phase\":\"onsale\",\"bill_type\":\"return_bill\",\"seller_nick\":\"哈啰车服电动车旗舰店\",\"modified\":\"2019-10-25 21:23:46\"}")
                .build();
        tmallMessageComponent.updateRefundId(tmallMessage);
        tmallMessageComponent.handleCancelDeliveryAgreeMessage(tmallMessage);
        return "OK";
    }


}
