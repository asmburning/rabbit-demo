package com.hellobike.rent.order.sync.web.util;

import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

@Slf4j
public class ThreadPools {


    private static ExecutorService logPool;
    private static ExecutorService dealPaidPool;
    private static ExecutorService dealRefundSuccessPool;
    private static ExecutorService dealFinishPool;
    private static ExecutorService tmallMessagePool;


    static {
        logPool = new ThreadPoolExecutor(5, 10, 15, TimeUnit.MINUTES,
                new ArrayBlockingQueue<Runnable>(1024), new NamedThreadFactory("LOGGER"));
        /**
         * 天猫消息接收处理核心线程池
         */
        tmallMessagePool = new ThreadPoolExecutor(200, 200, 15, TimeUnit.MINUTES,
                new ArrayBlockingQueue<Runnable>(10000), new NamedThreadFactory("tmallMessagePool"));

        /**
         * 天猫聚石塔更新错误重试线程池
         * 非核心
         */
        dealPaidPool = new ThreadPoolExecutor(15, 40, 15, TimeUnit.MINUTES,
                new ArrayBlockingQueue<Runnable>(5000), new NamedThreadFactory("dealPaidPool"));
        dealRefundSuccessPool = new ThreadPoolExecutor(15, 40, 15, TimeUnit.MINUTES,
                new ArrayBlockingQueue<Runnable>(5000), new NamedThreadFactory("dealRefundSuccessPool"));
        dealFinishPool = new ThreadPoolExecutor(15, 40, 15, TimeUnit.MINUTES,
                new ArrayBlockingQueue<Runnable>(5000), new NamedThreadFactory("dealFinishPool"));
    }

    public static ExecutorService getCorePool() {
        return tmallMessagePool;
    }

    public static void submitLoggerTask(Runnable task) {
        try {
            logPool.submit(task);
        } catch (Exception e) {
            log.error("submitLoggerTask error", e);
        }
    }

    public static void submitPayTask(Runnable task) {
        try {
            dealPaidPool.submit(task);
        } catch (Exception e) {
            log.error("submitDealPaidTask error", e);
        }
    }

    public static void submitDealRefundSuccessTask(Runnable task) {
        try {
            dealRefundSuccessPool.submit(task);
        } catch (Exception e) {
            log.error("submitDealRefundSuccessTask error", e);
        }
    }

    public static void submitFinishTask(Runnable task) {
        try {
            dealFinishPool.submit(task);
        } catch (Exception e) {
            log.error("submitDealFinishTask error", e);
        }
    }

    public static void submitTmallMessageTask(Runnable task) {
        try {
            tmallMessagePool.submit(task);
        } catch (Exception e) {
            log.error("submitTmallMessageTask error", e);
        }
    }

    public static ThreadPools getInstance() {
        return ThreadPoolManagerHolder.instance;
    }

    private static class ThreadPoolManagerHolder {
        public static ThreadPools instance = new ThreadPools();
    }

    private static class NamedThreadFactory implements ThreadFactory {
        private static final AtomicInteger poolNumber = new AtomicInteger(1);
        private final ThreadGroup group;
        private final AtomicInteger threadNumber = new AtomicInteger(1);
        private final String namePrefix;

        public NamedThreadFactory(String name) {
            SecurityManager s = System.getSecurityManager();
            group = (s != null) ? s.getThreadGroup() : Thread.currentThread().getThreadGroup();
            namePrefix = "pool-" + poolNumber.getAndIncrement() + "-" + name + "-thread-";
        }

        @Override
        public Thread newThread(Runnable r) {
            Thread t = new Thread(group, r, namePrefix + threadNumber.getAndIncrement(), 0);
            if (t.isDaemon()) {
                t.setDaemon(false);
            }
            if (t.getPriority() != Thread.NORM_PRIORITY) {
                t.setPriority(Thread.NORM_PRIORITY);
            }
            return t;
        }
    }
}
