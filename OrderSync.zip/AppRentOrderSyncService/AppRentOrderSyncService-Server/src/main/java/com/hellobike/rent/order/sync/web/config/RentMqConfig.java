package com.hellobike.rent.order.sync.web.config;

import com.hellobike.rent.user.common.enums.mq.RentOrderSyncMqConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

/**
 * @author liuxinyi
 * @date 2019/9/5
 */
@Configuration
@Slf4j
public class RentMqConfig {

    @Value("${rent.rabbit.host}")
    private String host;
    @Value("${rent.rabbit.port}")
    private int port;
    @Value("${rent.rabbit.username}")
    private String username;
    @Value("${rent.rabbit.pwd}")
    private String pwd;
    @Value("${rent.rabbit.virtual_host}")
    private String virtualHost;

    @Bean
    public ConnectionFactory connectionFactory() {
        CachingConnectionFactory factory = new CachingConnectionFactory();
        factory.setHost(host);
        factory.setPort(port);
        factory.setUsername(username);
        factory.setPassword(pwd);
        factory.setVirtualHost(virtualHost);
        return factory;
    }

    @Bean
    public RabbitAdmin rabbitAdmin() {
        RabbitAdmin rabbitAdmin = new RabbitAdmin(connectionFactory());
        rabbitAdmin.setAutoStartup(true);
        return rabbitAdmin;
    }

    @Bean
    public RabbitTemplate amqpTemplate() {
        return new RabbitTemplate(connectionFactory());
    }

    @Bean
    public List<Declarable> tmallOrderSyncTopic(RabbitAdmin rabbitAdmin) {
        TopicExchange topicExchange = new TopicExchange(RentOrderSyncMqConstants.EXCHANGER_TOPIC_NAME);
        List<Declarable> declarableList = new ArrayList<>();
        declarableList.add(topicExchange);
        for (RentOrderSyncMqConstants.OrderSyncBindings syncBinding : RentOrderSyncMqConstants.OrderSyncBindings.values()) {
            Queue queue = new Queue(syncBinding.getQueueName(), true, false, false);
            queue.setAdminsThatShouldDeclare(rabbitAdmin);
            declarableList.add(queue);
            declarableList.add(BindingBuilder.bind(queue).to(topicExchange).with(syncBinding.getRoutingKey()));
        }
        return declarableList;
    }

    @Bean(name = "rentRabbitListenerContainerFactory")
    public SimpleRabbitListenerContainerFactory rabbitListenerContainerFactory() {
        SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
        factory.setConnectionFactory(connectionFactory());
        //设置应答模式
        factory.setAcknowledgeMode(AcknowledgeMode.AUTO);
        factory.setConcurrentConsumers(1);
        factory.setMaxConcurrentConsumers(5);
        //每次请求发送给每个消费者的消息数量
        factory.setPrefetchCount(50);
        //是否重回队列,true:当消息消费出现异常时，没有被catch的话，会被重新丢回队列头部，重新消费 false:直接丢弃
        factory.setDefaultRequeueRejected(true);
        //配置advice
        log.info("rentRabbitListenerContainerFactory is ready");
        return factory;
    }
}
