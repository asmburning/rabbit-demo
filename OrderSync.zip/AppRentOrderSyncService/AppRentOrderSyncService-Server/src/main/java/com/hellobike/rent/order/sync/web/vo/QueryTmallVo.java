package com.hellobike.rent.order.sync.web.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * @author liuxinyi
 * @date 2019/9/29
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class QueryTmallVo {
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Shanghai")
    private Date start;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "Asia/Shanghai")
    private Date end;
    private String status;
    private Long refundId;
    private Long tid;
    private Long oid;
}
