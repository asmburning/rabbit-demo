package com.hellobike.rent.order.sync.web.util;

import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.TimeUnit;

/**
 * @author liuxinyi
 * @date 2019/9/16
 */
@Slf4j
public class ThreadUtils {

    public static void sleep(TimeUnit timeUnit, long timeout) {
        try {
            timeUnit.sleep(timeout);
        } catch (InterruptedException e) {
            log.error("sleepError", e);
        }
    }
}
