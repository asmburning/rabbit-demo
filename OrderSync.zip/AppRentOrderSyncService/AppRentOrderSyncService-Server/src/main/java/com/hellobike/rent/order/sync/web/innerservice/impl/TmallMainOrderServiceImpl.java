package com.hellobike.rent.order.sync.web.innerservice.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ctrip.framework.apollo.Config;
import com.ctrip.framework.apollo.spring.annotation.ApolloConfig;
import com.hellobike.base.redis.core.client.RedisClientManagement;
import com.hellobike.druid.dynamic.ForceMasterHelper;
import com.hellobike.rent.common.iface.resp.ServiceResp;
import com.hellobike.rent.common.util.AmapHttpUtils;
import com.hellobike.rent.common.util.dto.CoordinateDTO;
import com.hellobike.rent.order.sync.resp.TmallMainOrderResp;
import com.hellobike.rent.order.sync.web.cache.NewRedisKey;
import com.hellobike.rent.order.sync.web.innerservice.TmallMainOrderService;
import com.hellobike.rent.order.sync.web.innerservice.TmallOrderAnalysisService;
import com.hellobike.rent.order.sync.web.innerservice.TmallOrderInnerService;
import com.hellobike.rent.order.sync.web.mapper.TmallMainOrderMapper;
import com.hellobike.rent.order.sync.web.mapper.TmallSubOrderMapper;
import com.hellobike.rent.order.sync.web.model.TmallMainOrderEntity;
import com.hellobike.rent.order.sync.web.model.TmallSubOrderEntity;
import com.hellobike.rent.order.sync.web.reconciliation.TmallReconciliationComponent;
import com.hellobike.rent.order.sync.web.util.ThreadUtils;
import com.taobao.api.domain.Order;
import com.taobao.api.domain.Trade;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * @author liuxinyi
 * @date 2019/9/5
 */
@Service
@Slf4j
public class TmallMainOrderServiceImpl implements TmallMainOrderService {

    @Autowired
    private TmallMainOrderMapper tmallMainOrderMapper;

    @Autowired
    private TmallSubOrderMapper tmallSubOrderMapper;

    @Autowired
    private TmallOrderInnerService orderInnerService;

    @Autowired
    private AmqpTemplate amqpTemplate;

    @Autowired
    private TmallOrderAnalysisService analysisService;

    @ApolloConfig
    private Config config;

    @Autowired
    private TmallReconciliationComponent reconciliationComponent;

    private boolean needUpdateTid(Long tid) {
        String set = RedisClientManagement.getInstance().set(
                NewRedisKey.needUpdateTid(tid),
                String.valueOf(tid), "NX", "PX", 400);
        if (StringUtils.equals("OK", set)) {
            return true;
        }
        return false;
    }

    private Trade getFullInfoByTid(Long tid) {
        try {
            return orderInnerService.getOrderFullInfoByTidFromJushita(tid);
        } catch (Exception e) {
            log.error("getFullInfoByTidError tid:{}", tid, e);
            return null;
        }

    }

    private LocalDateTime fromDate(Date date) {
        if (null == date) {
            return null;
        }
        return LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault());
    }

    @Override
    public TmallMainOrderEntity selectByTid(Long tid) {
        return tmallMainOrderMapper.selectById(tid);
    }

    @Override
    public ServiceResp<String> updateByTid(Long tid) {
        ForceMasterHelper.forceMaster();
        // 400毫秒以内不需要重复更新
        if (!needUpdateTid(tid)) {
            ThreadUtils.sleep(TimeUnit.MILLISECONDS, 300);
            return ServiceResp.fail("重复更新");
        }
        Trade trade = getFullInfoByTid(tid);
        if (null == trade) {
            return ServiceResp.fail("查询天猫订单失败");
        }
        LocalDateTime now = LocalDateTime.now();
        TmallMainOrderEntity mainOrderEntity = new TmallMainOrderEntity();
        BeanUtils.copyProperties(trade, mainOrderEntity);

        mainOrderEntity.setCreateTime(now);
        mainOrderEntity.setUpdateTime(now);

        mainOrderEntity.setCreated(fromDate(trade.getCreated()));
        mainOrderEntity.setModified(fromDate(trade.getModified()));
        mainOrderEntity.setPayTime(fromDate(trade.getPayTime()));
        mainOrderEntity.setConsignTime(fromDate(trade.getConsignTime()));
        mainOrderEntity.setEndTime(fromDate(trade.getEndTime()));

        if (StringUtils.isNotBlank(trade.getOmnichannelParam())) {
            String omnichannelParam = trade.getOmnichannelParam();
            String[] split = omnichannelParam.split(",");
            JSONObject omni = new JSONObject();
            for (String s : split) {
                String[] kv = s.split(":");
                if (kv.length > 1) {
                    omni.put(kv[0], kv[1]);
                }
            }
            mainOrderEntity.setOmnichannelParam(omni);
        }

        //解析天猫城市code
        try {
            String helloCityCode = analysisService.analysisCityCode(trade.getReceiverCity(), trade.getReceiverDistrict());
            mainOrderEntity.setCityCode(helloCityCode);
        } catch (Exception e) {
        }


        TmallMainOrderEntity dbEntity = tmallMainOrderMapper.selectById(trade.getTid());
        if (null == dbEntity) {
            try {
                //根据地址解析经纬度
                CoordinateDTO coordinate = AmapHttpUtils.addressToCoordinate(trade.getReceiverAddress(), config.getProperty("rent.amap.key", "e8d663cb5bacf66bedbc7e3cb7015f29"));
                mainOrderEntity.setExtendJsonb(JSON.parseObject(JSON.toJSONString(coordinate)));
            } catch (Exception e) {
                log.error("addressToCoordinateException", e);
            }
            tmallMainOrderMapper.insert(mainOrderEntity);
        } else {
            tmallMainOrderMapper.updateById(mainOrderEntity);
        }

        List<Order> orders = trade.getOrders();
        for (Order order : orders) {
            TmallSubOrderEntity subOrderEntity = new TmallSubOrderEntity();
            subOrderEntity.setCreateTime(now);
            subOrderEntity.setUpdateTime(now);
            BeanUtils.copyProperties(order, subOrderEntity);

            subOrderEntity.setTid(trade.getTid());
            subOrderEntity.setCreated(fromDate(trade.getCreated()));

            subOrderEntity.setEndTime(fromDate(order.getEndTime()));

            subOrderEntity.setGoodsType(analysisService.analysisGoodsType(order.getOuterSkuId()));

            TmallSubOrderEntity dbSub = tmallSubOrderMapper.selectById(order.getOid());
            if (null == dbSub) {
                tmallSubOrderMapper.insert(subOrderEntity);
            } else {
                tmallSubOrderMapper.updateById(subOrderEntity);
            }
        }
        ForceMasterHelper.clearRouter();
        RedisClientManagement.getInstance().del(NewRedisKey.needUpdateTid(tid));
        return ServiceResp.success(null);
    }

    @Override
    public TmallMainOrderResp queryMainOrderInfo(Long tid) {
        TmallMainOrderEntity entity = tmallMainOrderMapper.selectById(tid);
        if (null == entity) {
            return null;
        }
        return TmallMainOrderResp.builder()
                .tid(tid)
                .cityCode(entity.getCityCode())
                .build();
    }

}
