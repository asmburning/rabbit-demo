package com.hellobike.rent.order.sync.web.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author created by zhangqiang05740
 * @date Created in 2019/9/5 5:23 PM
 * @description: 天猫门店映射vo
 **/
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class StoreMappingVo {

    /**
     * 天猫门店id
     */
    private String tmallStoreId;

    /**
     * 哈啰门店id
     */
    private String selfStoreId;

    /**
     * 哈啰门店名称
     */
    private String selfStoreName;
}
