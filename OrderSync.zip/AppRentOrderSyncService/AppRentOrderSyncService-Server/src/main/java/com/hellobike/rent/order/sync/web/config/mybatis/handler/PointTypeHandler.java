package com.hellobike.rent.order.sync.web.config.mybatis.handler;

import org.apache.ibatis.type.MappedTypes;
import org.postgis.Point;

/**
 * @author wt
 * @since 1.0.0
 */
@MappedTypes(Point.class)
public class PointTypeHandler extends AbstractGeometryTypeHandler<Point> {

}
