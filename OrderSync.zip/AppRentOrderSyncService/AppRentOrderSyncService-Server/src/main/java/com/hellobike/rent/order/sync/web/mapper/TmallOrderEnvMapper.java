package com.hellobike.rent.order.sync.web.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hellobike.rent.order.sync.web.model.TmallOrderEnvEntity;

/**
 * @author liuxinyi
 * @date 2019/9/25
 */
public interface TmallOrderEnvMapper extends BaseMapper<TmallOrderEnvEntity> {
}
