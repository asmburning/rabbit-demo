package com.hellobike.rent.order.sync.web.model;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;


/**
 * @author liuxinyi
 * @date 2019/9/2
 */
@TableName("t_rent_tmall_main_order")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TmallMainOrderEntity {
    @TableId
    private Long tid;
    private String sellerNick;
    private String picPath;
    private String payment;
    private Boolean sellerRate;
    private String postFee;
    private String receiverName;
    private String receiverState;
    private String receiverAddress;
    private String receiverMobile;
    private String receiverPhone;
    private LocalDateTime consignTime;
    private String receivedPayment;
    private JSONArray promotionDetails;
    private LocalDateTime estConTime;
    private String receiverCountry;
    private String receiverTown;
    private String receiverCity;
    private String receiverDistrict;
    private String paidCouponFee;
    private String shopPick;
    private Boolean newPresell;
    private Boolean youXiang;
    private String payChannel;
    private Long num;
    private Long numIid;
    private String status;
    private String title;
    private String type;
    private String price;
    private String discountFee;
    private Boolean hasPostFee;
    private String totalFee;
    private LocalDateTime created;
    private LocalDateTime payTime;
    private LocalDateTime modified;
    private LocalDateTime endTime;
    private String buyerMessage;
    private String buyerMemo;
    private Integer buyerFlag;
    private String sellerMemo;
    private Long sellerFlag;
    private String buyerNick;
    private JSONObject tradeAttr;
    private String creditCardFee;
    private String markDesc;
    private String shippingType;
    private String adjustFee;
    private String tradeFrom;
    private Boolean buyerRate;
    private String couponFee;
    private JSONObject omnichannelParam;
    private String assembly;
    private Integer teamBuyHold;
    private String serviceType;
    private String retailStoreCode;
    private String retailOutOrderId;
    private String cutoffMinutes;
    private String deliveryTime;
    private String collectTime;
    private String dispatchTime;
    private String signTime;
    private String rtOmniSendType;
    private String rtOmniStoreId;
    private String rtOmniOuterStoreId;
    private Boolean isShShip;
    private String obs;
    private Long etShopId;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;
    private String cityCode;
    private JSONObject extendJsonb;
}
