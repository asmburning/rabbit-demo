package com.hellobike.rent.order.sync.web.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @author liuxinyi
 * @date 2019/9/25
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("t_rent_tmall_order_error")
public class TmallOrderErrorEntity {
    @TableId
    private String guid;
    private Long tid;
    /**
     *
     * 数据库关键字
     */
    @TableField("t_oid")
    private Long oid;
    private String orderStatus;
    /**
     * 参见 EnumTmallGoodsType
     */
    private String goodsType;
    private String goodsName;
    /**
     * 参见 EnumTmallErrorType
     */
    private String errorType;
    private String errorMessage;
    private Integer errorHandled;
    private Integer tryTime;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;

    public boolean wasErrorHandled(){
        return Integer.valueOf(1).equals(this.errorHandled);
    }
}
