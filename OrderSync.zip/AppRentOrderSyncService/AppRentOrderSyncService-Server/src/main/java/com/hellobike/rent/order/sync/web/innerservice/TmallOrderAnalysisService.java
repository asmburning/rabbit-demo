package com.hellobike.rent.order.sync.web.innerservice;

import com.hellobike.rent.order.sync.vo.SkuInfo;
import com.hellobike.rent.order.sync.web.message.TmallMessage;
import com.hellobike.rent.order.sync.web.model.TmallMainOrderEntity;
import org.springframework.stereotype.Service;

/**
 * @author created by zhangqiang05740
 * @date Created in 2019/9/4 2:44 PM
 * @description: 天猫订单信息解析service
 **/
@Service
public interface TmallOrderAnalysisService {


    String analysisStore(TmallMainOrderEntity mainOrderEntity);

    /**
     * 天猫订单解析城市信息
     * @param receiverCity        天猫订单城市
     * @param receiverDistrict   天猫订单地区
     * @return
     */
    String analysisCityCode(String receiverCity ,String receiverDistrict);

    /**
     * 天猫订单解析商品信息（单一）
     * 标准解析规则：
     * 1、首先区分租车/售车
     * 2、然后分别解析
     * @param outerSkuId
     * @return
     */
    SkuInfo analysisSku(String outerSkuId);

    /**
     * 解析天猫消息关键节点
     * @param eventMessage
     * @return
     */
    void analysisEventType(TmallMessage eventMessage);

    String analysisEnvByTid(Long tid);

    String analysisEnvByTitle(String title);

    boolean shouldForward(String orderEnv);

    String analysisGoodsType(String outerSkuId);

    boolean isOuterSkuIdPowerSell(String outerSkuId);

    boolean canGoodsTypeSkipWork(String goodsType);
}
