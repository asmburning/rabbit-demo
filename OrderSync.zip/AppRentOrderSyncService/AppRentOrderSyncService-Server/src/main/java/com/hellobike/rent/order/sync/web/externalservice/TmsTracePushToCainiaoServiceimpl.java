package com.hellobike.rent.order.sync.web.externalservice;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.hellobike.rent.order.sync.enums.EnumCainiaoDeliveryAction;
import com.hellobike.rent.order.sync.enums.EnumFacilityType;
import com.hellobike.rent.order.sync.iface.TmsTracePushToCainiaoService;
import com.hellobike.rent.order.sync.req.CainiaoTmsTraceReq;
import com.hellobike.rent.order.sync.web.config.CainiaoConfig;
import com.hellobike.soa.starter.spring.annotation.SoaService;
import com.taobao.pac.sdk.cp.SendSysParams;
import com.taobao.pac.sdk.cp.dataobject.request.TRACEPUSH.Trace;
import com.taobao.pac.sdk.cp.dataobject.request.TRACEPUSH.TracepushRequest;
import com.taobao.pac.sdk.cp.dataobject.request.TRACEPUSH.TracesElement;
import com.taobao.pac.sdk.cp.dataobject.response.TRACEPUSH.TracepushResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Slf4j
@SoaService
public class TmsTracePushToCainiaoServiceimpl implements TmsTracePushToCainiaoService {

    @Autowired
    CainiaoConfig cainiaoConfig;

    @Override
    public boolean TmsTracePush(CainiaoTmsTraceReq req) throws Exception{
        TracepushResponse response = null;
        try {
            SendSysParams sendSysParams = new SendSysParams();
            sendSysParams.setFromCode(cainiaoConfig.getLogisticProviderId());
            TracepushRequest tracepushRequest = new TracepushRequest();
            tracepushRequest.setTracesList(buildTmsTracePush(req));
            response = cainiaoConfig.getPacClient().send(tracepushRequest, sendSysParams);
            log.info("TmsTracePush request, req:{} ,response:{}", tracepushRequest, response);
            if (response.isSuccess()) {
                return true;
            }
            log.error("TmsTracePushError response:{}", JSON.toJSONString(response));
        } catch (Exception e) {
            log.error("TmsTracePush error, req:{} ,response:{}", req, response);
            throw e;
        }
        return false;

    }


    private List<TracesElement> buildTmsTracePush(CainiaoTmsTraceReq req) {
        List<TracesElement> tracesElements = new ArrayList<>();
        TracesElement tracesElement = new TracesElement();
        tracesElement.setLogisticProviderID(cainiaoConfig.getLogisticProviderId());//物流公司资源code
        tracesElement.setMailNos(req.getMailNos());//运单号列表，以逗号分隔
        tracesElement.setTxLogisticID(req.getTxLogisticId()); //物流订单号 文档可选，实际必须传
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Trace trace = new Trace();
        trace.setTime(sdf.format(new Date()));
        trace.setDesc(req.getDesc());
        trace.setAction(req.getAction().getAction());
        trace.setCity(req.getCity());
        trace.setFacilityType(req.getEnumFacilityType().getType());//站点类型(1:网点,2:中转中心/分拨中心,3:代收点)
        trace.setFacilityNo(req.getFacilityNo());
        trace.setFacilityName(req.getFacilityName());
        trace.setCountry("China");
        trace.setTz("+8");
        if (req.getAction() == EnumCainiaoDeliveryAction.TMS_STATION_OUT) {
            trace.setNextCity(req.getNextCity());
        }
        trace.setContacter(req.getContacter());//快递员名称
        trace.setContactPhone(req.getContactPhone());
        trace.setRemark(req.getRemark());//可选
        tracesElement.setTraces(Lists.newArrayList(trace));
        tracesElements.add(tracesElement);
        return tracesElements;
    }

    public static void main(String[] args) {
        CainiaoTmsTraceReq req = CainiaoTmsTraceReq.builder().
                mailNos("1174884154170507269").txLogisticId("LP00146255648884")
                .action(EnumCainiaoDeliveryAction.TMS_FAILED).enumFacilityType(EnumFacilityType.BRANCH)
                .facilityName("长宁中心网点").facilityNo("11111121").contacter("David").contactPhone("18301987827")
                .desc("签收失败").city("上海").nextCity("长宁").build();
        System.out.println(JSON.toJSONString(req));
    }


}
