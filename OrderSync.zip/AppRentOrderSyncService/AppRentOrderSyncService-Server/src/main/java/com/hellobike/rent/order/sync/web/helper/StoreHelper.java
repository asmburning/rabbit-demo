package com.hellobike.rent.order.sync.web.helper;

import com.hellobike.rent.merchant.iface.QueryStoreIface;
import com.hellobike.rent.merchant.model.common.StoreVO;
import com.hellobike.rent.merchant.model.request.store.QueryStoreByIdReq;
import com.hellobike.rent.merchant.model.response.store.QueryStoreByIdResp;
import com.hellobike.rent.share.iface.RpcResult;
import com.hellobike.soa.rpc.RpcClientHelper;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

/**
 * @author created by zhangqiang05740
 * @date Created in 2019/9/6 4:11 PM
 * @description:
 **/
@Component
public class StoreHelper {

    /**
     * 根据门店id查询门店信息
     * @param storeId     门店id
     * @return            门店信息
     */
    public StoreVO getStoreById(String storeId){
        if (StringUtils.isBlank(storeId)) {
            throw new RuntimeException("storeId blank");
        }
        QueryStoreByIdReq req = new QueryStoreByIdReq();
        req.setId(storeId);
        RpcResult<QueryStoreByIdResp> rpcResult = RpcClientHelper.getClient(QueryStoreIface.class).getDetailById(req);
        if (null != rpcResult && rpcResult.isOk() && rpcResult.getData() !=null){
           return rpcResult.getData().getStoreVO();
        }
        return null;
    }
}
