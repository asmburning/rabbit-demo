package com.hellobike.rent.order.sync.web.util;

import com.ctrip.framework.apollo.Config;
import com.ctrip.framework.apollo.spring.annotation.ApolloConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.concurrent.ThreadPoolExecutor;

/**
 * @author liuxinyi
 * @date 2019/10/31
 */
@Component
@Slf4j
public class MonitorJob {


    @ApolloConfig
    private Config config;

    @Scheduled(initialDelay = 30 * 1000, fixedRate = 1000)
    public void monitorThreadPools() {
        Boolean monitor = config.getBooleanProperty("rent.monitorCoreThreadPools", false);
        if (!monitor) {
            return;
        }
        ThreadPoolExecutor mp = (ThreadPoolExecutor) ThreadPools.getCorePool();
        log.info("monitorCoreThreadPools PoolSize:{}  activeThread:{}  queueSize:{} , CompletedTaskCount:{} ",
                mp.getPoolSize(), mp.getActiveCount(),
                mp.getQueue().size(), mp.getCompletedTaskCount());
    }
}
