package com.hellobike.rent.order.sync.web.innerservice.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.ctrip.framework.apollo.Config;
import com.ctrip.framework.apollo.spring.annotation.ApolloConfig;
import com.google.common.collect.Lists;
import com.hellobike.rent.base.data.resp.partner.QueryPartnerByStoreIdResp;
import com.hellobike.rent.conchgirl.enums.BusinessEnum;
import com.hellobike.rent.conchgirl.enums.MessageTypeEnum;
import com.hellobike.rent.conchgirl.enums.OrderSourceEnum;
import com.hellobike.rent.conchgirl.enums.SourceTypeEnum;
import com.hellobike.rent.conchgirl.request.mq.OrderRefundMessage;
import com.hellobike.rent.merchant.model.common.StoreVO;
import com.hellobike.rent.order.condition.response.OrderInfoResp;
import com.hellobike.rent.order.sync.enums.EnumTmallGoodsType;
import com.hellobike.rent.order.sync.vo.SkuInfo;
import com.hellobike.rent.order.sync.web.helper.OrderHelper;
import com.hellobike.rent.order.sync.web.helper.PartnerHelper;
import com.hellobike.rent.order.sync.web.helper.StoreHelper;
import com.hellobike.rent.order.sync.web.innerservice.TmallOrderAnalysisService;
import com.hellobike.rent.order.sync.web.innerservice.TmallOrderInnerService;
import com.hellobike.rent.order.sync.web.innerservice.TmallSendMqService;
import com.hellobike.rent.order.sync.web.innerservice.TmallSubOrderService;
import com.hellobike.rent.order.sync.web.mapper.TmallMainOrderMapper;
import com.hellobike.rent.order.sync.web.model.TmallMainOrderEntity;
import com.hellobike.rent.order.sync.web.model.TmallSubOrderEntity;
import com.hellobike.rent.order.sync.web.reconciliation.TmallReconciliationComponent;
import com.hellobike.rent.order.sync.web.vo.AnalysisInfo;
import com.hellobike.rent.user.common.enums.mq.*;
import com.hellobike.rent.user.common.enums.order.EnumCarryType;
import com.hellobike.rent.user.common.enums.order.EnumOrderSyncOperationalStatus;
import com.hellobike.rent.user.common.enums.ordersync.EnumTmallBosDeliveryOrderMessageType;
import com.hellobike.rent.user.common.enums.ordersync.EnumTmallDeliveryEvent;
import com.hellobike.rent.user.common.enums.ordersync.EnumTmallDeliveryType;
import com.hellobike.rent.user.common.enums.ordersync.EnumTmallRefundTicketType;
import com.taobao.api.ApiException;
import com.taobao.api.domain.Refund;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static java.math.BigDecimal.ROUND_HALF_UP;

/**
 * 需要先把所有信息准备好 再发送MQ
 * 准备消息发生异常直接抛出异常
 *
 * @author liuxinyi
 * @date 2019/9/26
 */
@Service
@Slf4j
public class TmallSendMqServiceImpl implements TmallSendMqService {

    @Autowired
    private AmqpTemplate amqpTemplate;
    @Autowired
    private TmallOrderInnerService innerService;
    @ApolloConfig
    private Config config;
    @Autowired
    private TmallOrderAnalysisServiceImpl analysisService;
    @Autowired
    private StoreHelper storeHelper;
    @Autowired
    private TmallOrderAnalysisService tmallOrderAnalysisService;
    @Autowired
    private TmallSubOrderService subOrderService;
    @Autowired
    private OrderHelper orderHelper;
    @Autowired
    private PartnerHelper partnerHelper;
    @Autowired
    private TmallMainOrderMapper mainOrderMapper;
    @Autowired
    private TmallReconciliationComponent tmallReconciliationComponent;

    public boolean isDeliveryTmallOrder(TmallMainOrderEntity mainOrderEntity) {
        //自提 为1是自提，其他都是配送
        return !StringUtils.equals("1", mainOrderEntity.getShopPick());
    }

    private AnalysisInfo analysisInfo(TmallMainOrderEntity mainOrderEntity, TmallSubOrderEntity subOrderEntity) {

        EnumTmallDeliveryType deliveryType;
        Integer carryType;
        if (isDeliveryTmallOrder(mainOrderEntity)) {
            deliveryType = EnumTmallDeliveryType.DELIVERY;
            carryType = EnumCarryType.DISTRIBUTION.getCode();
        } else {
            deliveryType = EnumTmallDeliveryType.SELF_PICK;
            carryType = EnumCarryType.SELF_PICK.getCode();
        }

        String storeId = null;
        if (null != mainOrderEntity.getEtShopId()) {
            storeId = analysisService.analysisStore(mainOrderEntity);
        }
        String cityCode = null;
        StoreVO store = null;
        if (carryType.equals(EnumCarryType.SELF_PICK.getCode())) {
            store = storeHelper.getStoreById(storeId);
            cityCode = store.getCityCode();
            storeId = store.getId();
        } else if (carryType.equals(EnumCarryType.DISTRIBUTION.getCode())) {
            cityCode = tmallOrderAnalysisService.analysisCityCode(mainOrderEntity.getReceiverCity(), mainOrderEntity.getReceiverDistrict());
        }
        if (StringUtils.isBlank(cityCode)) {
            throw new RuntimeException("城市解析异常 city:" + mainOrderEntity.getReceiverCity() + " ,distinct:" + mainOrderEntity.getReceiverDistrict());
        }

        String outerSkuId = subOrderEntity.getOuterSkuId();
        SkuInfo skuInfo = analysisService.analysisSku(outerSkuId);
        return AnalysisInfo.builder()
                .cityCode(cityCode)
                .deliveryType(deliveryType)
                .carryType(carryType)
                .storeId(storeId)
                .storeVO(store)
                .skuInfo(skuInfo)
                .build();
    }

    @Override
    public void sendSellInitPaidDeliveryMessage(TmallMainOrderEntity mainOrderEntity, TmallSubOrderEntity subOrderEntity) {
        AnalysisInfo analysisInfo = analysisInfo(mainOrderEntity, subOrderEntity);

        TmallOrderNotifyMessage paidMessage = buildPayMessage(mainOrderEntity, subOrderEntity, analysisInfo);

        String paidJson = JSON.toJSONString(paidMessage);
        amqpTemplate.convertAndSend(RentOrderSyncMqConstants.EXCHANGER_TOPIC_NAME,
                RentOrderSyncMqConstants.RoutingKeys.RENT_TMALL_SYNC_PAID.getRoutingKey(),
                paidJson);
        log.info("doSendPayMessageSuccess pay:{}", paidJson);
    }

    private TmallOrderNotifyMessage buildPayMessage(TmallMainOrderEntity mainOrderEntity,
                                                    TmallSubOrderEntity subOrderEntity,
                                                    AnalysisInfo analysisInfo) {


        SkuInfo skuInfo = analysisInfo.getSkuInfo();
        int totalNum = subOrderService.sumNumByTid(mainOrderEntity.getTid());

        TmallOrderNotifyMessage tmallOrderNotifyMessage = TmallOrderNotifyMessage
                .builder()
                .tid(mainOrderEntity.getTid())
                .receiverCity(mainOrderEntity.getReceiverCity())
                .receiverName(mainOrderEntity.getReceiverName())
                .receiverAddress(mainOrderEntity.getReceiverAddress())
                .receiverDistrict(mainOrderEntity.getReceiverDistrict())
                .receiverMobile(mainOrderEntity.getReceiverMobile())
                .cityCode(analysisInfo.getCityCode())
                .carryType(analysisInfo.getCarryType())
                .outerStoreId(mainOrderEntity.getRtOmniOuterStoreId())
                .storeId(analysisInfo.getStoreId())
                .deliveryPrice(new BigDecimal(mainOrderEntity.getPostFee()).divide(BigDecimal.valueOf(totalNum), 2, ROUND_HALF_UP))
                .orderStatus(EnumOrderSyncOperationalStatus.PAID.name())
                .subT(Lists.newArrayList(TmallOrderNotifyMessage.SubOrder.builder()
                        .oid(subOrderEntity.getOid())
                        .createTime(subOrderEntity.getCreateTime())
                        .updateTime(subOrderEntity.getUpdateTime())
                        .outerSkuId(subOrderEntity.getOuterSkuId())
                        .modelId(skuInfo.getModelId())
                        .switchPower(skuInfo.getSwitchPower())
                        .specId(skuInfo.getSpecId())
                        .price(new BigDecimal(subOrderEntity.getPrice()))
                        .systemCouponPrice(subOrderEntity.getPartMjzDiscount() == null ? BigDecimal.ZERO : new BigDecimal(subOrderEntity.getPartMjzDiscount()).divide(new BigDecimal(String.valueOf(subOrderEntity.getNum())), 2, ROUND_HALF_UP))
                        .subNum(subOrderEntity.getNum().intValue())
                        .totalPrice(new BigDecimal(subOrderEntity.calculateSubPayment()).divide(new BigDecimal(String.valueOf(subOrderEntity.getNum())), 2, ROUND_HALF_UP))
                        .build()
                ))
                .payTime(mainOrderEntity.getPayTime())
                .build();
        return tmallOrderNotifyMessage;
    }


    @Override
    public void sendSellDeliveryMessage(Long tid) {
        if (null == tid) {
            return;
        }
        TmallMainOrderEntity mainOrderEntity = mainOrderMapper.selectById(tid);
        List<TmallSubOrderEntity> subOrderEntityList = subOrderService.querySkuNotNoneListByTid(tid);
        if (null == mainOrderEntity || CollectionUtils.isEmpty(subOrderEntityList)) {
            return;
        }

        List<TmallSubOrderEntity> sellSubList = subOrderEntityList.stream()
                .filter(subOrderEntity -> {
                    String goodsType = analysisService.analysisGoodsType(subOrderEntity.getOuterSkuId());
                    return StringUtils.equals(goodsType, EnumTmallGoodsType.POWER_SELL.getType());
                })
                .collect(Collectors.toList());

        if (CollectionUtils.isEmpty(sellSubList)) {
            return;
        }

        TmallDeliveryMessage deliveryMessage = buildDeliveryMessage(mainOrderEntity, sellSubList);
        // delivery
        String deliveryJson = JSON.toJSONString(deliveryMessage);
        amqpTemplate.convertAndSend(RentOrderSyncMqConstants.EXCHANGER_TOPIC_NAME,
                RentOrderSyncMqConstants.RoutingKeys.RENT_TMALL_DELIVERY.getRoutingKey(),
                deliveryJson
        );
        log.info("sendDeliveryMessageSuccess tmallDeliveryMessage:{}", deliveryJson);
    }

    private TmallDeliveryMessage buildDeliveryMessage(TmallMainOrderEntity mainOrderEntity,
                                                      List<TmallSubOrderEntity> sellSubOrderEntityList) {
        AnalysisInfo analysisInfo = analysisInfo(mainOrderEntity, sellSubOrderEntityList.get(0));
        TmallDeliveryMessage tmallDeliveryMessage =
                TmallDeliveryMessage.builder()
                        .tid(mainOrderEntity.getTid())
                        .deliveryEvent(EnumTmallDeliveryEvent.PAY_DELIVERY)
                        .deliveryType(analysisInfo.getDeliveryType())
                        .receiverName(mainOrderEntity.getReceiverName())
                        .receiverAddress(mainOrderEntity.getReceiverAddress())
                        .receiverMobile(mainOrderEntity.getReceiverMobile())
                        .receiverCity(mainOrderEntity.getReceiverCity())
                        .receiverState(mainOrderEntity.getReceiverState())
                        .receiverCityCode(analysisInfo.getCityCode())
                        .receiverDistinct(mainOrderEntity.getReceiverDistrict())
                        .storeId(analysisInfo.getStoreId())
                        //.payment(mainOrderEntity.getPayment())
                        .payTime(mainOrderEntity.getPayTime())
                        .price(mainOrderEntity.getPrice())
                        .build();
        List<TmallDeliveryMessage.TmallOrder> tmallOrderList = sellSubOrderEntityList.stream()
                .map(subOrderEntity ->
                {
                    SkuInfo skuInfo = analysisService.analysisSku(subOrderEntity.getOuterSkuId());
                    return TmallDeliveryMessage.TmallOrder.builder()
                            .oid(subOrderEntity.getOid())
                            .modelId(skuInfo.getModelId())
                            .modelName(skuInfo.getModelName())
                            .specId(skuInfo.getSpecId())
                            .specName(skuInfo.getSpecName())
                            .num(subOrderEntity.getNum())
                            .created(subOrderEntity.getCreated())
                            .payment(subOrderEntity.calculateSubPayment())
                            .price(subOrderEntity.getPrice())
                            .build();
                })
                .collect(Collectors.toList());
        tmallDeliveryMessage.setTmallOrderList(tmallOrderList);
        Optional<BigDecimal> totalPayment = tmallOrderList.stream()
                .map(tmallOrder -> new BigDecimal(tmallOrder.getPayment()))
                .reduce(BigDecimal::add);
        tmallDeliveryMessage.setPayment(totalPayment.get().toPlainString());
        return tmallDeliveryMessage;
    }


    @Override
    public void sendRentPaidMessage(TmallMainOrderEntity mainOrderEntity, TmallSubOrderEntity subOrderEntity) {
        //AnalysisInfo analysisInfo = analysisInfo(mainOrderEntity, subOrderEntity);
        TmallVerifyCodeMsgDTO rentVerifyCodeMsg = TmallVerifyCodeMsgDTO.builder()
                .type(EnumOrderSyncOperationalStatus.PAID.name())
                .orderRelations(Lists.newArrayList(
                        TmallVerifyCodeMsgDTO.OrderRelationDTO.builder()
                                .oid(subOrderEntity.getOid())
                                .tid(mainOrderEntity.getTid())
                                .mobilePhone(mainOrderEntity.getReceiverMobile())
                                .num(subOrderEntity.getNum())
                                .build()
                ))
                .build();
        String message = JSON.toJSONString(rentVerifyCodeMsg);
        amqpTemplate.convertAndSend(RentOrderSyncMqConstants.EXCHANGER_TOPIC_NAME,
                RentOrderSyncMqConstants.RoutingKeys.RENT_TMALL_RENT_CODE.getRoutingKey(),
                message);
        log.info("doSendRentPaidMessageSuccess rentPay:{}", message);
    }

    @Override
    public void sendOrderRefundMessage(TmallMainOrderEntity mainOrderEntity, TmallSubOrderEntity subOrderEntity)
            throws ApiException {
        String goodsType = analysisService.analysisGoodsType(subOrderEntity.getOuterSkuId());
        String refundId = subOrderEntity.getRefundId();
        Refund refund = innerService.getRefundOrderByRefundId(Long.parseLong(refundId));

        TmallDeliveryMessage deliveryCancelMessage = null;
        TmallRefundDTO tmallRefundDTO = null;
        String deliveryOrderMessageType = EnumTmallBosDeliveryOrderMessageType.REFUND_SUCCESS.getMessageType();
        List<OrderRefundMessage> refundMessageList = null;
        if (goodsType.equals(EnumTmallGoodsType.POWER_SELL.getType())) {
            // 需要退货 取消配送
            deliveryCancelMessage = buildDeliveryCancelMessage(mainOrderEntity, subOrderEntity);
            // 售车订单发送取消消息到支付中心
            refundMessageList = buildChargeCenterRefundSuccessMsg(mainOrderEntity, subOrderEntity, refund);
            // 退货工单消息
            tmallRefundDTO = buildBosDeliveryOrderMessage(mainOrderEntity, subOrderEntity, deliveryOrderMessageType);
        }

        // send cancel message to orderService
        TmallOrderNotifyMessage orderNotifyMessage = buildRefundSuccessOrderNotifyMessage(mainOrderEntity, subOrderEntity, refund);

        String notifyOrderJson = JSON.toJSONString(orderNotifyMessage);
        amqpTemplate.convertAndSend(RentOrderSyncMqConstants.EXCHANGER_TOPIC_NAME,
                RentOrderSyncMqConstants.RoutingKeys.RENT_TMALL_SYNC_CANCEL.getRoutingKey(),
                notifyOrderJson);
        log.info("doSendCancelOrderMessageSuccess refundCancel:{}", notifyOrderJson);

        // 配送取消消息
        if (null != deliveryCancelMessage) {
            String deliveryCancelJson = JSON.toJSONString(deliveryCancelMessage);
            amqpTemplate.convertAndSend(RentOrderSyncMqConstants.EXCHANGER_TOPIC_NAME,
                    RentOrderSyncMqConstants.RoutingKeys.RENT_TMALL_DELIVERY.getRoutingKey(),
                    deliveryCancelJson
            );
            log.info("doSendDeliveryCancelMessageSuccess tmallDeliveryMessage:{}", deliveryCancelJson);
        }
        // bosDeliveryOrder 退货工单消息
        if (null != tmallRefundDTO) {
            String deliveryOrderJson = JSON.toJSONString(tmallRefundDTO);
            amqpTemplate.convertAndSend(RentOrderSyncMqConstants.EXCHANGER_TOPIC_NAME,
                    RentOrderSyncMqConstants.RoutingKeys.RENT_TMALL_DELIVERY_ORDER.getRoutingKey(),
                    deliveryOrderJson
            );
            log.info("doSendBosDeliveryOrderMessageSuccess messageType:{}  jsonData:{}", deliveryOrderMessageType, deliveryOrderJson);
        }

        if (CollectionUtils.isNotEmpty(refundMessageList)) {
            refundMessageList.stream().forEach(refundMessage ->
                    {
                        String chargeMessage = JSONObject.toJSONString(refundMessage);
                        amqpTemplate.convertAndSend("rent_cf_tmall_refund_exchange",
                                "",
                                chargeMessage);
                        log.info("sendRefundChargeCenterMessageSuccess chargeCenter:{},", chargeMessage);
                    }
            );
        }
    }

    @NotNull
    private TmallOrderNotifyMessage buildRefundSuccessOrderNotifyMessage(TmallMainOrderEntity mainOrderEntity, TmallSubOrderEntity subOrderEntity, Refund refund) {
        TmallOrderNotifyMessage orderNotifyMessage = TmallOrderNotifyMessage.builder()
                .tid(mainOrderEntity.getTid())
                .payTime(mainOrderEntity.getPayTime())
                .build();
        orderNotifyMessage.setOrderStatus(EnumOrderSyncOperationalStatus.PAID_CANCEL.name());

        List<TmallOrderNotifyMessage.SubOrder> subOrderList = Lists.newArrayList(
                TmallOrderNotifyMessage.SubOrder.builder()
                        .oid(subOrderEntity.getOid())
                        .outerSkuId(subOrderEntity.getOuterSkuId())
                        .subNum(subOrderEntity.getNum().intValue())
                        .refundFee(refund.getRefundFee())
                        .goodsType(subOrderEntity.getGoodsType())
                        .build());
        orderNotifyMessage.setSubT(subOrderList);
        return orderNotifyMessage;
    }


    private List<OrderRefundMessage> buildChargeCenterRefundSuccessMsg(
            TmallMainOrderEntity mainOrderEntity, TmallSubOrderEntity subOrderEntity,
            Refund refund) {
        Boolean sendConfig = config.getBooleanProperty("tmall.chargeCenter.send", false);
        if (null == sendConfig || !sendConfig) {
            return null;
        }

        try {
            List<OrderInfoResp> orderInfos = orderHelper.getOrderInfo(String.valueOf(subOrderEntity.getTid()),
                    String.valueOf(subOrderEntity.getOid()));
            if (orderInfos == null || orderInfos.size() == 0) {
                log.error("sendRefundChargeCenterMessageError, no order info, subOrderEntity:{}, refund:{}", subOrderEntity, JSONObject.toJSONString(refund));
                return null;
            }
            BigDecimal refundAmount = new BigDecimal(refund.getRefundFee()).divide(new BigDecimal(orderInfos.size()), 2, ROUND_HALF_UP);
            List<OrderRefundMessage> refundMessageList = new ArrayList<>();
            for (OrderInfoResp orderInfo : orderInfos) {
                log.info("buildOrderCancelMsgStart amount:{},order:{}", refundAmount, orderInfo);
                if (orderInfo.getBikeNo() == null) {
                    //没有绑过车的订单不需要计费
                    continue;
                }
                OrderRefundMessage payMessage = new OrderRefundMessage();
                payMessage.setOrderSource(OrderSourceEnum.TMALL.getCode());
                payMessage.setMessageType(MessageTypeEnum.天猫售后退款);
                payMessage.setOrderId(orderInfo.getOrderId());
                payMessage.setTabCityCode(orderInfo.getCityCode());
                payMessage.setSourceId(orderInfo.getOrderId());
                payMessage.setSourceType(SourceTypeEnum.ORDER.getCode());
                payMessage.setBusinessId(BusinessEnum.valueOfOrderTypeAndSaleType(orderInfo.getOrderType(),
                        orderInfo.getSaleType()).getCode());
                payMessage.setOrderCreateTime(orderInfo.getCreateTime());
                payMessage.setPayTime(LocalDateTime.now());
                payMessage.setUserGuid(orderInfo.getUserGuid());
                payMessage.setUserNewId(orderInfo.getUserNewId());
                if (StringUtils.isNotBlank(orderInfo.getPartnerStoreId())) {
                    try {
                        QueryPartnerByStoreIdResp partnerInfo =
                                partnerHelper.queryPartnerByStoreId(orderInfo.getPartnerStoreId());
                        if (partnerInfo != null) {
                            payMessage.setPartnerId(partnerInfo.getGuid());
                        }
                    } catch (Exception e) {
                        log.error("buildChargeCenterOrderCancelMsgError queryPartnerByStoreId orderInfo:{}",
                                orderInfo, e);
                    }
                    payMessage.setPartnerStoreId(Long.valueOf(orderInfo.getPartnerStoreId()));
                }
                payMessage.setRefundAmount(refundAmount);
                refundMessageList.add(payMessage);
            }
            return refundMessageList;

        } catch (Exception e) {
            log.error("sendOrderCancelMsgError", e);
            return null;
        }
    }

    @NotNull
    private TmallDeliveryMessage buildDeliveryCancelMessage(TmallMainOrderEntity mainOrderEntity, TmallSubOrderEntity subOrderEntity) {
        TmallDeliveryMessage tmallDeliveryMessage =
                TmallDeliveryMessage.builder()
                        .tid(mainOrderEntity.getTid())
                        .deliveryEvent(EnumTmallDeliveryEvent.CANCEL)
                        .build();

        List<TmallDeliveryMessage.TmallOrder> collect = Lists.newArrayList(
                TmallDeliveryMessage.TmallOrder.builder()
                        .oid(subOrderEntity.getOid())
                        .num(subOrderEntity.getNum())
                        .build()
        );
        tmallDeliveryMessage.setTmallOrderList(collect);
        return tmallDeliveryMessage;
    }

    @Override
    public void sendOrderFinishedMessage(TmallMainOrderEntity mainOrderEntity, TmallSubOrderEntity subOrderEntity)
            throws ApiException {
        String messageType = EnumTmallBosDeliveryOrderMessageType.ORDER_FINISH.getMessageType();
        TmallRefundDTO tmallRefundDTO = buildBosDeliveryOrderMessage(mainOrderEntity, subOrderEntity, messageType);
        if (null != tmallRefundDTO) {
            String initJson = JSON.toJSONString(tmallRefundDTO);
            amqpTemplate.convertAndSend(RentOrderSyncMqConstants.EXCHANGER_TOPIC_NAME,
                    RentOrderSyncMqConstants.RoutingKeys.RENT_TMALL_DELIVERY_ORDER.getRoutingKey(),
                    initJson
            );
            log.info("doSendBosDeliveryOrderMessageSuccess messageType:{}  jsonData:{}", messageType, initJson);
        }
    }

    /**
     * 发送bos配送工单消息
     *
     * @param mainOrderEntity
     * @param subOrderEntity
     * @param messageType
     */
    @Override
    public void sendBosDeliveryOrderMessage(TmallMainOrderEntity mainOrderEntity, TmallSubOrderEntity subOrderEntity,
                                            String messageType) throws ApiException {
        TmallRefundDTO tmallRefundDTO = buildBosDeliveryOrderMessage(mainOrderEntity, subOrderEntity, messageType);
        if (null != tmallRefundDTO) {
            String initJson = JSON.toJSONString(tmallRefundDTO);
            amqpTemplate.convertAndSend(RentOrderSyncMqConstants.EXCHANGER_TOPIC_NAME,
                    RentOrderSyncMqConstants.RoutingKeys.RENT_TMALL_DELIVERY_ORDER.getRoutingKey(),
                    initJson
            );
            log.info("doSendBosDeliveryOrderMessageSuccess messageType:{}  jsonData:{}", messageType, initJson);
        }
    }


    private TmallRefundDTO buildBosDeliveryOrderMessage(TmallMainOrderEntity mainOrderEntity,
                                                        TmallSubOrderEntity subOrderEntity,
                                                        String messageType) throws ApiException {
        if (!analysisService.isOuterSkuIdPowerSell(subOrderEntity.getOuterSkuId())) {
            return null;
        }
        Refund refund = null;
        if (null != subOrderEntity.getRefundId()) {
            refund = innerService.getRefundOrderByRefundId(Long.valueOf(subOrderEntity.getRefundId()));
        }

        TmallRefundDTO tmallRefundDTO = TmallRefundDTO.builder()
                .tMallId(subOrderEntity.getOid())
                .tMallReturnId(subOrderEntity.getRefundId())
                .orderAmount(subOrderEntity.calculateSubPayment())
                .receiverState(mainOrderEntity.getReceiverState())
                .receiverCity(mainOrderEntity.getReceiverCity())
                .receiverDistrict(mainOrderEntity.getReceiverDistrict())
                .receiverTown(mainOrderEntity.getReceiverTown())
                .receiverAddress(mainOrderEntity.getReceiverAddress())
                .receiverName(mainOrderEntity.getReceiverName())
                .receiverMobile(mainOrderEntity.getReceiverMobile())
                .messageType(messageType).build();
        if (null != refund) {
            tmallRefundDTO.setTicketType(getTicketType(refund.getHasGoodReturn()));
            tmallRefundDTO.setApplyTime(null == refund.getCreated() ? new Date() : refund.getCreated());
            tmallRefundDTO.setRemark(refund.getReason());
            tmallRefundDTO.setReturnDesc(refund.getDesc());
            tmallRefundDTO.setRemark(refund.getReason());
            tmallRefundDTO.setSalesReturnAmount(null == refund.getRefundFee() ? subOrderEntity.calculateSubPayment() : refund.getRefundFee());
        }
        return tmallRefundDTO;
    }

    private String getTicketType(Boolean hasGoodReturn) {
        return (null == hasGoodReturn || !hasGoodReturn) ? EnumTmallRefundTicketType.NO_GOODS.getType() : EnumTmallRefundTicketType.HAS_GOODS.getType();
    }


    @Override
    public void sendOrderRefundClosedMessage(TmallMainOrderEntity mainOrderEntity, TmallSubOrderEntity subOrderEntity) {
        if (!analysisService.isOuterSkuIdPowerSell(subOrderEntity.getOuterSkuId())) {
            log.info("sendOrderRefundClosedMessageNotNeed, tid:{}, oid:{}", subOrderEntity.getTid(), subOrderEntity.getOid());
            return;
        }

        String messageType = EnumTmallBosDeliveryOrderMessageType.REFUND_CLOSE.getMessageType();
        TmallRefundDTO tmallRefundDTO = TmallRefundDTO.builder()
                .tMallId(subOrderEntity.getOid())
                .tMallReturnId(subOrderEntity.getRefundId())
                .messageType(messageType).build();

        String initJson = JSON.toJSONString(tmallRefundDTO);
        amqpTemplate.convertAndSend(RentOrderSyncMqConstants.EXCHANGER_TOPIC_NAME,
                RentOrderSyncMqConstants.RoutingKeys.RENT_TMALL_DELIVERY_ORDER.getRoutingKey(),
                initJson
        );
        log.info("doSendBosDeliveryOrderMessageSuccess messageType:{}  jsonData:{}", messageType, initJson);
    }
}
