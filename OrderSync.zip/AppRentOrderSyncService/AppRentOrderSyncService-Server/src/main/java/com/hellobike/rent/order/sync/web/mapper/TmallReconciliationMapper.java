package com.hellobike.rent.order.sync.web.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hellobike.rent.order.sync.web.model.TmallReconciliationEntity;

/**
 * @author liuxinyi
 * @date 2019/9/25
 */
public interface TmallReconciliationMapper extends BaseMapper<TmallReconciliationEntity> {
}
