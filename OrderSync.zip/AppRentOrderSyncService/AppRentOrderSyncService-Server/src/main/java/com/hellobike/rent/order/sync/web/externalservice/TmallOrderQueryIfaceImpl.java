package com.hellobike.rent.order.sync.web.externalservice;

import com.hellobike.rent.common.iface.resp.ServiceResp;
import com.hellobike.rent.order.sync.iface.TmallOrderQueryIface;
import com.hellobike.rent.order.sync.req.TmallOrderQueryReq;
import com.hellobike.rent.order.sync.resp.TmallMainOrderResp;
import com.hellobike.rent.order.sync.resp.TmallOidQueryResp;
import com.hellobike.rent.order.sync.resp.TmallSubOrderResp;
import com.hellobike.rent.order.sync.web.innerservice.TmallMainOrderService;
import com.hellobike.rent.order.sync.web.innerservice.TmallSubOrderService;
import com.hellobike.soa.starter.spring.annotation.SoaService;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @author gaohu08299
 * @create $ ID: TmallOrderQueryIfaceImpl, 2019-09-29 17:43 gaohu08299 Exp $
 * @since 1.0.0
 */
@SoaService
public class TmallOrderQueryIfaceImpl implements TmallOrderQueryIface {

    @Autowired
    private TmallSubOrderService tmallSubOrderService;

    @Autowired
    private TmallMainOrderService tmallMainOrderService;

    @Override
    public ServiceResp<TmallSubOrderResp> queryTmallSubOrderInfo(Long oid) {
        TmallSubOrderResp tmallSubOrderResp = tmallSubOrderService.querySubOrderInfo(oid);
        return ServiceResp.success(tmallSubOrderResp);
    }

    @Override
    public ServiceResp<TmallMainOrderResp> queryTmallMainOrder(TmallOrderQueryReq req) {
        TmallMainOrderResp resp = tmallMainOrderService.queryMainOrderInfo(req.getTid());
        return ServiceResp.success(resp);
    }

    @Override
    public ServiceResp<TmallOidQueryResp> queryTmallMainSubInfoByOid(Long oid) {
        TmallOidQueryResp resp = tmallSubOrderService.queryTmallMainSubInfoByOid(oid);
        return ServiceResp.success(resp);
    }

}
