package com.hellobike.rent.order.sync.web.anno;

public @interface HelloIpAuth {
}
