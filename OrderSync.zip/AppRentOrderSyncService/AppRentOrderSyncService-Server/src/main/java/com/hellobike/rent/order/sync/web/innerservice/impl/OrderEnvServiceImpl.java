package com.hellobike.rent.order.sync.web.innerservice.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.IdWorker;
import com.hellobike.rent.order.sync.web.innerservice.OrderEnvService;
import com.hellobike.rent.order.sync.web.mapper.TmallOrderEnvMapper;
import com.hellobike.rent.order.sync.web.model.TmallOrderEnvEntity;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author liuxinyi
 * @date 2019/9/29
 */
@Slf4j
@Service
public class OrderEnvServiceImpl implements OrderEnvService {

    @Autowired
    private TmallOrderEnvMapper envMapper;

    @Override
    public List<TmallOrderEnvEntity> queryListByOids(List<Long> oids) {
        return envMapper.selectList(new QueryWrapper<TmallOrderEnvEntity>()
                .in("oid", oids));
    }

    @Override
    public int insertEnvEntity(Long tid, Long oid, boolean needHandle) {
        try {
            TmallOrderEnvEntity db = envMapper.selectOne(new QueryWrapper<TmallOrderEnvEntity>()
                    .eq("tid", tid).eq("t_oid", oid));
            if (null != db) {
                return 0;
            }
            TmallOrderEnvEntity envEntity = TmallOrderEnvEntity.builder()
                    .guid(IdWorker.getIdStr())
                    .tid(tid)
                    .oid(oid)
                    .needHandle(needHandle)
                    .createTime(LocalDateTime.now())
                    .updateTime(LocalDateTime.now())
                    .build();
            return envMapper.insert(envEntity);
        } catch (DuplicateKeyException e) {
            // ignore DuplicateKeyException
            return 0;
        }
    }
}
