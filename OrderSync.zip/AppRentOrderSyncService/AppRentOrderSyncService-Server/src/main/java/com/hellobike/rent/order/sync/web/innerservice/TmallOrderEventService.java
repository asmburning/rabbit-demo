package com.hellobike.rent.order.sync.web.innerservice;

import com.hellobike.rent.order.sync.web.message.TmallMessage;

/**
 * @author liuxinyi
 * @date 2019/9/3
 */
public interface TmallOrderEventService {
    void receiveTmallEvent(TmallMessage eventMessage);
}
