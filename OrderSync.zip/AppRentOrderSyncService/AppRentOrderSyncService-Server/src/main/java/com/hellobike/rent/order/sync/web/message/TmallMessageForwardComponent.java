package com.hellobike.rent.order.sync.web.message;

import com.alibaba.fastjson.JSON;
import com.hellobike.rent.common.iface.resp.ServiceResp;
import com.hellobike.rent.order.sync.web.util.XHttpUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

/**
 * @author liuxinyi
 * @date 2019/9/27
 */
@Component
@Slf4j
public class TmallMessageForwardComponent {

    private static final Map<String, String> domainMap = new HashMap<String, String>() {
        {
            put("dev", "https://dev-xrent-for-cainiao.hellobike.com");
            put("fat", "https://fat-xrent-for-cainiao.hellobike.com");
            put("uat", "https://uat-xrent-for-cainiao.hellobike.com");
            put("pro", "https://xrent-for-cainiao.hellobike.com");
        }
    };

    public void forwardMessage(String orderEnv, TmallMessage tmallMessage) {
        String message = JSON.toJSONString(tmallMessage);
        String domain = domainMap.get(orderEnv);
        String url = domain + "/tmallMessage/receiveForward";
        ServiceResp<String> forwardResp = XHttpUtils.postJson(url,
                null, message);
        if (!forwardResp.isSuccess()) {
            log.error("forwardMessageError env:{}, message:{}, error:{}",
                    orderEnv, message, forwardResp.getMsg());
        }
    }
}
