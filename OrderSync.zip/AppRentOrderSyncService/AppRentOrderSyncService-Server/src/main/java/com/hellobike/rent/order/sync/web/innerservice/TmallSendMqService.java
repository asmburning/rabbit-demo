package com.hellobike.rent.order.sync.web.innerservice;

import com.hellobike.rent.order.sync.web.model.TmallMainOrderEntity;
import com.hellobike.rent.order.sync.web.model.TmallSubOrderEntity;
import com.taobao.api.ApiException;

/**
 * 发生任何错误 直接抛出异常
 *
 * @author liuxinyi
 * @date 2019/9/26
 */
public interface TmallSendMqService {

    /**
     * 售车订单 发送init paid
     *
     * @param mainOrderEntity
     * @param subOrderEntity
     */
    void sendSellInitPaidDeliveryMessage(TmallMainOrderEntity mainOrderEntity, TmallSubOrderEntity subOrderEntity);

    /**
     * 售车订单发送配送消息
     *
     * @param tid
     */
    void sendSellDeliveryMessage(Long tid);

    /**
     * 租车订单发送消息到 userService
     *
     * @param mainOrderEntity
     * @param subOrderEntity
     */
    void sendRentPaidMessage(TmallMainOrderEntity mainOrderEntity, TmallSubOrderEntity subOrderEntity);

    /**
     * 如果有退货处理，则同时发送配送取消消息
     *
     * @param mainOrderEntity
     * @param subOrderEntity
     */
    void sendOrderRefundMessage(TmallMainOrderEntity mainOrderEntity, TmallSubOrderEntity subOrderEntity) throws ApiException;

    /**
     * 订单完成消息， 目前只给配送工单系统发一个消息
     * 后续可能会发送消息到orderService等
     *
     * @param mainOrderEntity
     * @param subOrderEntity
     */
    void sendOrderFinishedMessage(TmallMainOrderEntity mainOrderEntity, TmallSubOrderEntity subOrderEntity)
            throws ApiException;

    /**
     * 发送bos配送工单消息
     * 申请退货消息
     * 同意退货消息
     * 退货成功消息
     * 交易成功消息
     */
    void sendBosDeliveryOrderMessage(TmallMainOrderEntity mainOrderEntity, TmallSubOrderEntity subOrderEntity,
                                     String messageType) throws ApiException;

    /**
     * 发送退款取消消息
     * @param mainOrderEntity
     * @param subOrderEntity
     */
    void sendOrderRefundClosedMessage(TmallMainOrderEntity mainOrderEntity, TmallSubOrderEntity subOrderEntity);
}
