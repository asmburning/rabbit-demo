package com.hellobike.rent.order.sync.web.helper;

import com.hellobike.rent.base.data.iface.PartnerQueryIface;
import com.hellobike.rent.base.data.req.partner.QueryPartnerByStoreIdReq;
import com.hellobike.rent.base.data.resp.partner.QueryPartnerByStoreIdResp;
import com.hellobike.rent.common.iface.resp.ServiceResp;
import com.hellobike.soa.rpc.RpcClientHelper;
import org.springframework.stereotype.Component;

/**
 * @Description 合伙人信息查询helper
 */
@Component
public class PartnerHelper {

    public QueryPartnerByStoreIdResp queryPartnerByStoreId(String partnerStoreId){
        ServiceResp<QueryPartnerByStoreIdResp> resp = RpcClientHelper.getClient(PartnerQueryIface.class).queryPartnerByStoreId(QueryPartnerByStoreIdReq
                .builder()
                .partnerStoreId(partnerStoreId)
                .build());
        if (resp != null && resp.isSuccess()){
            return resp.getData();
        }
        return null;
    }
}
