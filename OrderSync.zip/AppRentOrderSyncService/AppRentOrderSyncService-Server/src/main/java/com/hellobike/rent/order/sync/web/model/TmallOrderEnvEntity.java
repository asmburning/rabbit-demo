package com.hellobike.rent.order.sync.web.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @author liuxinyi
 * @date 2019/9/27
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("t_rent_tmall_order_env")
public class TmallOrderEnvEntity {
    @TableId
    private String guid;
    private Long tid;
    @TableField("t_oid")
    private Long oid;
    @TableField("should_handle")
    private Boolean needHandle;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;
}
