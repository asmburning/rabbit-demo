package com.hellobike.rent.order.sync.web.qimen.response;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public abstract class QimenResponse implements Serializable {
    private String flag;
    private String code;
    private String message;
    private String body;
}
