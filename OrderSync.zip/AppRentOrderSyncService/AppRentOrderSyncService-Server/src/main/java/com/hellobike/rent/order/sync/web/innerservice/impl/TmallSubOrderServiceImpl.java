package com.hellobike.rent.order.sync.web.innerservice.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.hellobike.base.redis.core.client.RedisClientManagement;
import com.hellobike.base.redis.core.model.key.Key;
import com.hellobike.rent.order.sync.resp.TmallOidQueryResp;
import com.hellobike.rent.order.sync.resp.TmallSubOrderResp;
import com.hellobike.rent.order.sync.web.cache.NewRedisKey;
import com.hellobike.rent.order.sync.web.innerservice.TmallSubOrderService;
import com.hellobike.rent.order.sync.web.mapper.TmallMainOrderMapper;
import com.hellobike.rent.order.sync.web.mapper.TmallSubOrderMapper;
import com.hellobike.rent.order.sync.web.model.TmallMainOrderEntity;
import com.hellobike.rent.order.sync.web.model.TmallSubOrderEntity;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

import static java.math.BigDecimal.ROUND_HALF_UP;

/**
 * @author gaohu08299
 * @author liuxinyi
 * @create $ ID: TmallSubOrderServiceImpl, 2019-09-29 17:45 gaohu08299 Exp $
 * @date 2019/9/30
 * @since 1.0.0
 */
@Slf4j
@Service
public class TmallSubOrderServiceImpl implements TmallSubOrderService {

    @Autowired
    private TmallMainOrderMapper tmallMainOrderMapper;

    @Autowired
    private TmallSubOrderMapper tmallSubOrderMapper;

    @Override
    public TmallSubOrderResp querySubOrderInfo(Long oid) {
        TmallSubOrderEntity entity = tmallSubOrderMapper.selectOne(new QueryWrapper<TmallSubOrderEntity>().eq("oid", oid));
        TmallSubOrderResp resp = TmallSubOrderResp.builder()
                .oid(entity.getOid())
                .tid(entity.getTid())
                .picPath(entity.getPicPath())
                .title(entity.getTitle())
                .outerSkuId(entity.getOuterSkuId()).build();
        return resp;
    }


    @Override
    public int sumNumByTid(Long tid) {
        Key key = NewRedisKey.sumNumByTid(tid);
        String s = RedisClientManagement.getInstance().get(key);
        if (StringUtils.isNotBlank(s)) {
            return Integer.parseInt(s);
        }
        int sumNumByTid = tmallSubOrderMapper.sumNumByTid(tid);
        RedisClientManagement.getInstance().set(key, String.valueOf(sumNumByTid), 3600 * 24 * 7);
        return sumNumByTid;
    }

    @Override
    public TmallOidQueryResp queryTmallMainSubInfoByOid(Long oid) {
        TmallSubOrderEntity subOrderEntity = tmallSubOrderMapper.selectById(oid);
        if (subOrderEntity == null || subOrderEntity.getTid() == null) {
            return null;
        }
        TmallMainOrderEntity mainOrderEntity = tmallMainOrderMapper.selectById(subOrderEntity.getTid());
        if (mainOrderEntity == null) {
            return null;
        }

        int totalNum = sumNumByTid(mainOrderEntity.getTid());
        TmallOidQueryResp resp = TmallOidQueryResp.builder()
                .tid(mainOrderEntity.getTid())
                .receiverCity(mainOrderEntity.getReceiverCity())
                .receiverName(mainOrderEntity.getReceiverName())
                .receiverAddress(mainOrderEntity.getReceiverAddress())
                .receiverDistrict(mainOrderEntity.getReceiverDistrict())
                .receiverMobile(mainOrderEntity.getReceiverMobile())
                .deliveryPrice(new BigDecimal(mainOrderEntity.getPostFee()).divide(BigDecimal.valueOf(totalNum), 2, ROUND_HALF_UP))
                .subOrder(TmallOidQueryResp.SubOrderInfo.builder()
                        .oid(subOrderEntity.getOid())
                        .createTime(subOrderEntity.getCreateTime())
                        .updateTime(subOrderEntity.getUpdateTime())
                        .price(new BigDecimal(subOrderEntity.getPrice()))
                        .systemCouponPrice(subOrderEntity.getPartMjzDiscount() == null ? BigDecimal.ZERO : new BigDecimal(subOrderEntity.getPartMjzDiscount()).divide(new BigDecimal(String.valueOf(subOrderEntity.getNum())), 2, ROUND_HALF_UP))
                        .subNum(subOrderEntity.getNum().intValue())
                        .totalPrice(new BigDecimal(subOrderEntity.getTotalFee()).divide(new BigDecimal(String.valueOf(subOrderEntity.getNum())), 2, ROUND_HALF_UP))
                        .payment(new BigDecimal(subOrderEntity.calculateSubPayment()).divide(new BigDecimal(String.valueOf(subOrderEntity.getNum())), 2, ROUND_HALF_UP))
                        .build())
                .payTime(mainOrderEntity.getPayTime())
                .extendJsonb(mainOrderEntity.getExtendJsonb())
                .build();
        return resp;
    }

    @Override
    public List<TmallSubOrderEntity> querySkuNotNoneListByTid(Long tid) {
        return tmallSubOrderMapper.selectList(new QueryWrapper<TmallSubOrderEntity>()
                .eq("tid", tid)
                .isNotNull("outer_sku_id"));
    }

    @Override
    public TmallSubOrderEntity queryByOid(Long oid) {
        return tmallSubOrderMapper.selectById(oid);
    }

    @Override
    public void updateOidRefundId(Long oid, String refundId) {
        if (null == oid || null == refundId) {
            return;
        }
        tmallSubOrderMapper.updateById(
                TmallSubOrderEntity
                        .builder()
                        .oid(oid)
                        .refundId(refundId)
                        .build());
    }
}
