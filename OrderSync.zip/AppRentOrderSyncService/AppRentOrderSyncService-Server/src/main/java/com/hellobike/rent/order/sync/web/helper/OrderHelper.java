package com.hellobike.rent.order.sync.web.helper;

import com.hellobike.rent.common.iface.resp.ServiceResp;
import com.hellobike.rent.order.condition.response.OrderInfoResp;
import com.hellobike.rent.order.iface.TmallOrderIface;
import com.hellobike.rent.order.req.QueryTmallOrderReq;
import com.hellobike.soa.rpc.RpcClientHelper;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @Description 订单信息查询helper
 */
@Component
public class OrderHelper {

    public List<OrderInfoResp> getOrderInfo(String tid, String oid){
        ServiceResp<List<OrderInfoResp>> serviceResp = RpcClientHelper.getClient(TmallOrderIface.class).queryTmallOrder(QueryTmallOrderReq.builder().tid(tid).oid(oid).build());
        if (serviceResp != null && serviceResp.isSuccess()){
            return serviceResp.getData();
        }
        return null;
    }

}
