package com.hellobike.rent.order.sync.web.config.mybatis.handler;

import org.apache.ibatis.type.MappedTypes;
import org.postgis.LineString;

/**
 * @author wt
 * @since 1.0.0
 */
@MappedTypes(LineString.class)
public class LineStringTypeHandler extends AbstractGeometryTypeHandler<LineString> {

}
