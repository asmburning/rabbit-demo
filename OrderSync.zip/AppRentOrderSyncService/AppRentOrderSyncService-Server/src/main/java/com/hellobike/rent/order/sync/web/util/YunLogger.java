package com.hellobike.rent.order.sync.web.util;

import com.carkey.base.util.LogUtils;
import com.carkey.spark.yukon.logger.LoggerFactory;
import com.carkey.spark.yukon.logger.iface.LoggerTrack;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Map;

@Component
public class YunLogger {

    private LoggerTrack loggerTrack;

    @Value("${yun.logger.name}")
    private String loggerName;
    @Value("${yun.logger.path}")
    private String loggerPath;
    @Value("${yun.logger.server}")
    private String loggerServer;
    @Value("${yun.logger.topic}")
    private String loggerTopic;

    @PostConstruct
    public void init() {
        LoggerFactory yukonLoggerFactory = LoggerFactory.initialize(loggerName).serviceName("AppRentOrderSyncService");
        yukonLoggerFactory.localFile(loggerPath).kafka(loggerServer, loggerTopic);

        loggerTrack = yukonLoggerFactory.build();
    }

    public void metric(String key, Map<String, Object> logMap) {
        metric(key, 0.0, logMap);
    }

    public void metric(String key, double value, Map<String, Object> logMap) {
        try {
            ThreadPools.getInstance().submitLoggerTask(() -> loggerTrack.metric(key, value, logMap));
        } catch (Exception e) {
            LogUtils.ERROR.error("metric", e);
        }
    }
}
