package com.hellobike.rent.order.sync.web;

import com.hellobike.helloboot.common.context.ApplicationContextUtil;
import com.hellobike.rent.order.sync.web.message.TmallMessageListener;
import com.hellobike.soa.starter.spring.annotation.SoaComponentScan;
import lombok.extern.slf4j.Slf4j;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author zhuyunhui
 * @date 2019-06-05 16:02
 */
@Slf4j
@SpringBootApplication
@MapperScan("com.hellobike.rent.order.sync.web.mapper")
@SoaComponentScan("com.hellobike.rent.order.sync.web")
@Import(ApplicationContextUtil.class)
@RestController
@EnableAsync
@EnableScheduling
public class AppRentOrderSyncServiceApplication implements ApplicationRunner {
    public static void main(String[] args) {
        try {
            SpringApplication.run(AppRentOrderSyncServiceApplication.class, args);
            log.info("---------------------------------------------------------");
            log.info("--AppRentOrderSyncServiceApplication Started Success-----");
            log.info("---------------------------------------------------------");
        } catch (Exception e) {
            log.error("AppRentOrderSyncServiceApplication Start failed", e);
            System.exit(0);
        }
    }

    @Override
    public void run(ApplicationArguments args) throws Exception {
        ApplicationContextUtil.getBean(TmallMessageListener.class).onMessage();
    }

    // 为了SLB检查可以正常返回，WEB项目默认访问/
    @RequestMapping("/")
    public String index() {
        return "SUCCESS";
    }

}
