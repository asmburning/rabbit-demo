package com.hellobike.rent.order.sync.web.config.security;

import com.alibaba.fastjson.JSONArray;
import com.ctrip.framework.apollo.Config;
import com.ctrip.framework.apollo.spring.annotation.ApolloConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * @author liuxinyi
 * @date 2019/11/1
 */
@Component
@Order(3)
@Slf4j
public class WebIpFilter extends OncePerRequestFilter {

    @ApolloConfig
    private Config config;

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {
        String remoteAddr = request.getRemoteAddr();
        String requestURI = request.getRequestURI();
        if (requestURI.startsWith("/reconciliation/") ||
                requestURI.startsWith("/rentMessage/") ||
                requestURI.startsWith("/tmallMessage/")) {
            log.info("---------------ip:{} ----requestURI:{}---------------", remoteAddr, requestURI);
            if (!isInnerNetworkSegment(remoteAddr)) {
                // 非内网网段，根据ip过滤
                String ips = config.getProperty("reconciliation.ips", "[\"127.0.0.1\"]");
                List<String> ipList = JSONArray.parseArray(ips, String.class);
                if (!ipList.contains(remoteAddr)) {
                    return;
                }
            }
        }
        filterChain.doFilter(request, response);
    }

    private boolean isInnerNetworkSegment(String remoteAddr) {
        String ips = config.getProperty("inner.net.segments", "[\"100.120.\"]");
        List<String> innerSegments = JSONArray.parseArray(ips, String.class);
        for (String innerSegment : innerSegments) {
            if (remoteAddr.startsWith(innerSegment)) {
                return true;
            }
        }
        return false;
    }
}
