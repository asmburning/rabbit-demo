package com.hellobike.rent.order.sync.web.util;

import com.alibaba.fastjson.JSON;
import com.hellobike.rent.common.iface.resp.ServiceResp;
import com.taobao.api.domain.Trade;
import io.netty.handler.codec.http.DefaultHttpHeaders;
import io.netty.handler.codec.http.HttpHeaderNames;
import io.netty.handler.codec.http.HttpHeaderValues;
import io.netty.handler.codec.http.HttpHeaders;
import lombok.extern.slf4j.Slf4j;
import org.asynchttpclient.AsyncHttpClient;
import org.asynchttpclient.DefaultAsyncHttpClientConfig;
import org.asynchttpclient.Dsl;
import org.asynchttpclient.Response;
import org.asynchttpclient.request.body.generator.InputStreamBodyGenerator;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import static java.util.concurrent.TimeUnit.SECONDS;

/**
 * @author liuxinyi
 * @date 2019/11/1
 */
@Slf4j
public class AsyncHttpUtils {

    static DefaultAsyncHttpClientConfig.Builder clientBuilder = Dsl.config()
            .setConnectTimeout(3000)
            .setReadTimeout(5000)
            .setRequestTimeout(5000)
            .setMaxRequestRetry(2)
            .setMaxConnectionsPerHost(100)
            .setMaxConnections(200);
    static AsyncHttpClient client = Dsl.asyncHttpClient(clientBuilder);


    public static void main(String[] args) throws Exception {
        String url = "http://39.98.106.169:50000/api";
        Map<String, Object> reqMap = new HashMap<>();
        reqMap.put("tid", 670171619444324724L);
        Map<String, String> heads = new HashMap<>();
        heads.put("rent-sign", "xxx");
        ServiceResp<Trade> tradeServiceResp = postJson(url, heads, JSON.toJSONString(reqMap), Trade.class);
        log.info(JSON.toJSONString(tradeServiceResp));
    }


    public static ServiceResp<String> postJson(String url, Map<String, String> headers, String content) {
        try {
            Response response = doPostJson(url, headers, content);
            return ServiceResp.success(response.getResponseBody());
        } catch (Exception e) {
            log.error("postJsonError url:{} content:{}", url, content, e);
            return ServiceResp.fail("postJsonError" + e.getMessage());
        }
    }

    public static <T> ServiceResp<T> postJson(String url, Map<String, String> headers, String content, Class<T> clazz) {
        try {
            Response response = doPostJson(url, headers, content);
            int statusCode = response.getStatusCode();
            T t = JSON.parseObject(response.getResponseBody(), clazz);
            return ServiceResp.success(t);
        } catch (Exception e) {
            log.error("postJsonError url:{} content:{}", url, content, e);
            return ServiceResp.fail("postJsonError" + e.getMessage());
        }
    }

    private static Response doPostJson(String url, Map<String, String> headers, String content) throws Exception {
        HttpHeaders h = new DefaultHttpHeaders();
        headers.entrySet().forEach(entry -> h.add(entry.getKey(), entry.getValue()));
        h.add(HttpHeaderNames.CONTENT_TYPE, HttpHeaderValues.APPLICATION_JSON);

        byte[] bodyBytes = content.getBytes(StandardCharsets.UTF_8);
        InputStream bodyStream = new ByteArrayInputStream(bodyBytes);

        return client.preparePost(url)
                .setHeaders(h)
                .setBody(new InputStreamBodyGenerator(bodyStream, bodyBytes.length))
                .execute()
                .get(5, SECONDS);
    }
}
