package com.hellobike.rent.order.sync.web.model;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDateTime;

/**
 * @author liuxinyi
 * @date 2019/9/2
 */
@TableName("t_rent_tmall_sub_order")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TmallSubOrderEntity {
    @TableId
    private Long oid;
    private Long tid;
    private String itemMealName;
    private String picPath;
    private String refundStatus;
    private String outerIid;
    private LocalDateTime timeoutActionTime;
    private String sellerType;
    private Long cid;
    private String estimateConTime;
    private String status;
    private String title;
    private Long itemOid;
    private String type;
    private String price;
    private Long numIid;
    private Long serviceId;
    private Long itemMealId;
    private String skuId;
    private Long num;
    private String outerSkuId;
    private String orderFrom;
    private String totalFee;
    private String serviceDetailUrl;
    private String payment;
    private String discountFee;
    private String adjustFee;
    private LocalDateTime modified;
    private String skuPropertiesName;
    private String refundId;
    private Boolean isOversold;
    private Boolean isServiceOrder;
    private LocalDateTime endTime;
    private String consignTime;
    private JSONObject orderAttr;
    private String shippingType;
    private Long bindOid;
    private String logisticsCompany;
    private String invoiceNo;
    private String divideOrderFee;
    private String partMjzDiscount;
    private String storeCode;
    private String bindOids;
    private String customization;
    private String invType;
    private Boolean isShShip;
    private String shipper;
    private Integer fqgNum;
    private Boolean isFqgSFee;
    private String rechargeFee;
    private String modifyAddress;
    private String tiModifyAddressTime;
    private String deliveryTime;
    private String collectTime;
    private String dispatchTime;
    private String signTime;
    private String rtOmniOuterScId;
    private String rtOmniScId;
    private LocalDateTime created;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;

    private String goodsType;

    public String calculateSubPayment() {
        return StringUtils.isNotBlank(divideOrderFee) ?
                divideOrderFee : payment;
    }
}
