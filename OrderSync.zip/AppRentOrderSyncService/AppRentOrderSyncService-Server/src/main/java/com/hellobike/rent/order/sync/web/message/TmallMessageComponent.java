package com.hellobike.rent.order.sync.web.message;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.hellobike.rent.order.sync.web.innerservice.TmallMainOrderService;
import com.hellobike.rent.order.sync.web.innerservice.TmallSendMqService;
import com.hellobike.rent.order.sync.web.innerservice.TmallSubOrderService;
import com.hellobike.rent.order.sync.web.reconciliation.ReconciliationMessageComponent;
import com.hellobike.rent.order.sync.web.reconciliation.TmallReconciliationComponent;
import com.hellobike.rent.order.sync.web.util.YunLogger;
import com.hellobike.rent.user.common.enums.ordersync.EnumTmallBosDeliveryOrderMessageType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author liuxinyi
 * @date 2019/9/30
 */
@Service
@Slf4j
public class TmallMessageComponent {
    @Autowired
    private TmallReconciliationComponent reconciliationComponent;
    @Autowired
    private YunLogger yunLogger;
    @Autowired
    private TmallMessageForwardComponent messageForwardComponent;
    @Autowired
    private ReconciliationMessageComponent reconciliationMessageComponent;
    @Autowired
    private TmallSendMqService sendMqService;
    @Autowired
    private TmallMainOrderService mainOrderService;
    @Autowired
    private TmallSubOrderService subOrderService;


    public void updateRefundId(TmallMessage tmallMessage) {
        try {
            JSONObject jsonObject = JSON.parseObject(tmallMessage.getContent());
            Long oid = jsonObject.getLong("oid");
            Long refund_id = jsonObject.getLong("refund_id");
            if (null != oid && null != refund_id) {
                subOrderService.updateOidRefundId(oid, String.valueOf(refund_id));
            }
        } catch (Exception e) {
            log.error("updateOidRefundIdError message:{}", tmallMessage);
        }
    }

    public void handleTradeClosedMessage(TmallMessage tmallMessage) {
        updateRefundId(tmallMessage);
        reconciliationMessageComponent.reconOidRefundSuccessMessage(tmallMessage.getTid(), tmallMessage.getOid());
    }


    public void handleTmallPayMessage(TmallMessage tmallMessage) {
        reconciliationMessageComponent.reconciliationTidPayMessage(tmallMessage.getTid());
    }

    public void handleTradeFinishedMessage(TmallMessage tmallMessage) {
        reconciliationMessageComponent.reconciliationTidFinishMessage(tmallMessage.getTid());
    }

    /**
     * 处理天猫申请退货消息
     *
     * @param tmallMessage
     */
    public void handleCancelDeliveryApplyMessage(TmallMessage tmallMessage) {
        reconciliationMessageComponent.reconciliationBosDeliveryOrderMessageMessage(tmallMessage.getTid(),
                tmallMessage.getOid(), EnumTmallBosDeliveryOrderMessageType.CANCEL_APPLY.getMessageType());
    }

    /**
     * 处理天猫同意退货消息
     *
     * @param tmallMessage
     */
    public void handleCancelDeliveryAgreeMessage(TmallMessage tmallMessage) {
        reconciliationMessageComponent.reconciliationBosDeliveryOrderMessageMessage(tmallMessage.getTid(),
                tmallMessage.getOid(), EnumTmallBosDeliveryOrderMessageType.CANCEL_AGREE.getMessageType());
    }

    /**
     * 处理天猫退款取消消息
     *
     * @param tmallMessage
     */
    public void handleRefundClosedMessage(TmallMessage tmallMessage) {
        reconciliationMessageComponent.reconRefundCloseMessage(
                tmallMessage.getTid(), tmallMessage.getOid());
    }


}
