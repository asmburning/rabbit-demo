package com.hellobike.rent.order.sync.web.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author liuxinyi
 * @date 2019/9/29
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TmallOrderPreVo {
    private Long tid;
    private Long oid;
    private String title;
    private String orderStatus;
    private String orderEnv;
    private String goodsType;
    private boolean needHandle;
}
