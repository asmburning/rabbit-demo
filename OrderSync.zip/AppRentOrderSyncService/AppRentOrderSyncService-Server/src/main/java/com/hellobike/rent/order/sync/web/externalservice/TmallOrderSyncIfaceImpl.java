package com.hellobike.rent.order.sync.web.externalservice;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.hellobike.rent.order.sync.iface.TmallOrderSyncIface;
import com.hellobike.rent.order.sync.web.config.TmallConfig;
import com.hellobike.soa.starter.spring.annotation.SoaService;
import com.taobao.api.ApiException;
import com.taobao.api.request.LogisticsOfflineSendRequest;
import com.taobao.api.response.LogisticsOfflineSendResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;

@Slf4j
@SoaService
public class TmallOrderSyncIfaceImpl implements TmallOrderSyncIface {
    @Autowired
    TmallConfig tmallConfig;

    public boolean OnlineSend(long tid, String oid, String deliveryNo, long is_split ) throws Exception {
        try {
            LogisticsOfflineSendRequest req = new LogisticsOfflineSendRequest();
            req.setTid(tid);
            req.setSubTid(oid);
            req.setIsSplit(1L);//默认都拆单
            req.setOutSid(deliveryNo);
            req.setCompanyCode("DISTRIBUTOR_30145884");
            LogisticsOfflineSendResponse rsp = tmallConfig.getTaobaoClient().execute(req, tmallConfig.getSessionKey());
            log.info("online send resp tid:{} ,message:{}", tid, JSON.toJSONString(rsp));
            if(! rsp.isSuccess()){
                throw new ApiException(rsp.getErrorCode(),rsp.getMessage());
            }
            return true;
        }catch (Exception e){
            throw  e;
        }
    }
}
