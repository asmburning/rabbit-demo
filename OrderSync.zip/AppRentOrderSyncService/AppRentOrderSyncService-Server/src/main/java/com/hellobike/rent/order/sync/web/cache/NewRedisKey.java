package com.hellobike.rent.order.sync.web.cache;

import com.hellobike.base.redis.core.model.key.Key;
import com.hellobike.rent.order.sync.enums.EnumTmallReconMessageType;

public abstract class NewRedisKey {

    public static Key canHandleTidMessage(long tid, String messageType) {
        return Key.convertByFormat("rent:canHandleTidMessage:%s:%s", String.valueOf(tid), messageType);
    }

    public static Key needUpdateTid(long tid) {
        return Key.convertByFormat("rent:needUpdateTid:%s", String.valueOf(tid));
    }

    public static Key tidEnv(long tid) {
        return Key.convertByFormat("rent:tidEnv:%s", String.valueOf(tid));
    }

    public static Key reconciliationQueryTime(String status) {
        return Key.convertByFormat("rent:reconciliationQueryTime:%s", status);
    }

    public static Key canHandleMessage(long tid, EnumTmallReconMessageType messageType) {
        return Key.convertByFormat("rent:canHandleMessage:%s:%s",
                String.valueOf(tid), messageType.getReconType());
    }

    public static Key canHandleMessage(long tid, long oid, EnumTmallReconMessageType messageType) {
        return Key.convertByFormat("rent:canHandleMessage:%s:%s:%s",
                String.valueOf(tid), String.valueOf(oid), messageType.getReconType());
    }

    public static Key canHandleMessage(long tid, long oid, String messageType) {
        return Key.convertByFormat("rent:canHandleMessage:%s:%s:%s",
                String.valueOf(tid), String.valueOf(oid), messageType);
    }

    public static Key messageHandledMark(long tid, EnumTmallReconMessageType messageType) {
        return Key.convertByFormat("rent:messageHandledMark:%s:%s",
                String.valueOf(tid), messageType.getReconType());
    }

    public static Key messageHandledMark(long tid, String messageType) {
        return Key.convertByFormat("rent:messageHandledMark:%s:%s",
                String.valueOf(tid), messageType);
    }

    public static Key messageHandledMark(long tid, long oid, String messageType) {
        return Key.convertByFormat("rent:messageHandledMark:%s:%s:%s",
                String.valueOf(tid), String.valueOf(oid), messageType);
    }

    public static Key messageHandledMark(long tid, long oid, EnumTmallReconMessageType messageType) {
        return Key.convertByFormat("rent:messageHandledMark:%s:%s:%s",
                String.valueOf(tid), String.valueOf(oid), messageType.getReconType());
    }

    public static Key sumNumByTid(Long tid) {
        return Key.convertByFormat("rent:sumNumByTid:%s", String.valueOf(tid));
    }


}
