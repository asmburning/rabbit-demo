package com.hellobike.rent.order.sync.web.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author liuxinyi
 * @date 2019/10/15
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ReconVo {

    private Long tid;
    private Long oid;
    private String tradeStatus;
    private String orderStatus;
}
