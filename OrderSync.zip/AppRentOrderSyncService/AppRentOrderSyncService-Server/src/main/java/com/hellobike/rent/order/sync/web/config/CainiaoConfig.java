package com.hellobike.rent.order.sync.web.config;

import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;
import com.taobao.pac.sdk.cp.PacClient;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@Getter
public class CainiaoConfig {

    @Value("${cainiao.appKey}")
    private String appKey;
    @Value("${cainiao.secret}")
    private String secret;
    @Value("${cainiao.linkUrl}")
    private String linkUrl;
    @Value("${cainiao.logisticProviderId}")
    private String logisticProviderId;

    @Bean
    public PacClient getPacClient() {
          return new PacClient(appKey, secret, linkUrl);
    }

}
