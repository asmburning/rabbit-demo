package com.hellobike.rent.order.sync.web;

public interface Constants {
    interface Cainiao{
        String CAINIAO_NOTIFY_EXCHANGE = "TMS_CREATE_ORDER_OFFLINE_NOTIFY_EXCHANGE";
        String CAINIAO_NOTIFY_ROUTING_KEY ="tms.create.order.offline.notify.key";
        String SUCCESS_JSON = "{\"success\":\"true\"}";
    }
}
