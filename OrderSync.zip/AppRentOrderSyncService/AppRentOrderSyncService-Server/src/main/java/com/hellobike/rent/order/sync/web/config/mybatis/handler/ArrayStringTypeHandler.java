package com.hellobike.rent.order.sync.web.config.mybatis.handler;

import org.apache.ibatis.type.MappedTypes;

import java.sql.Array;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * @author wt
 * @since 1.0.0
 */
@MappedTypes(String[].class)
public class ArrayStringTypeHandler extends AbstractArrayTypeHandler<String> {

    @Override
    protected Array createArray(Connection conn, String[] strings) throws SQLException {
        return conn.createArrayOf("varchar", strings);
    }
}
