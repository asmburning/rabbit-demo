package com.hellobike.rent.order.sync.web.job;

import com.hellobike.base.flexjob.common.participant.ParticipantParams;
import com.hellobike.base.flexjob.participant.starter.spring.JobHandle;
import com.hellobike.rent.order.sync.enums.EnumTmallOrderStatus;
import com.hellobike.rent.order.sync.web.innerservice.TmallOrderErrorService;
import com.hellobike.rent.order.sync.web.reconciliation.ReconciliationOrderComponent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author liuxinyi
 * @date 2019/9/25
 */
@Service
@JobHandle
public class TmallReconciliationJob {
    @Autowired
    private ReconciliationOrderComponent reconciliationOrderComponent;
    @Autowired
    private TmallOrderErrorService errorService;

    /**
     * 天猫订单对账，支付
     */
    public void reconciliationTmallPaidOrder(ParticipantParams participantParams) {
        // 无需物流交互的
        reconciliationOrderComponent.reconciliationTidTmallOrder(EnumTmallOrderStatus.WAIT_SELLER_SEND_GOODS);
        // 需要物流交互的
        reconciliationOrderComponent.reconciliationTidTmallOrder(EnumTmallOrderStatus.WAIT_BUYER_CONFIRM_GOODS);
    }

    /**
     * 天猫订单对账，完成
     */
    public void reconciliationTmallFinishedOrder(ParticipantParams participantParams) {
        reconciliationOrderComponent.reconciliationOidTmallOrder(EnumTmallOrderStatus.TRADE_FINISHED);
    }

    /**
     * 天猫订单对账，关闭
     */
    public void reconciliationTmallClosedOrder(ParticipantParams participantParams) {
        reconciliationOrderComponent.reconciliationOidTmallOrder(
                EnumTmallOrderStatus.TRADE_CLOSED
        );
    }

    /**
     * 批量查询退款
     * @param participantParams
     */
    public void reconciliationRefund(ParticipantParams participantParams) {
        reconciliationOrderComponent.reconciliationRefund();
    }

}
