package com.hellobike.rent.order.sync.web.util;

import com.hellobike.rent.common.iface.resp.ServiceResp;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.MapUtils;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.impl.cookie.BasicClientCookie;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.util.Map;

/**
 * @author liuxinyi
 * @date 2019/9/27
 */
@Slf4j
public class XHttpUtils {

    private static final CloseableHttpClient defaultHttpClient;
    private static final int SOCKET_TIMEOUT = 15000;
    private static final String UTF_8 = "UTF-8";
    private static final int CONNECTION_TIMEOUT = 3000;
    private static final int CONNECTION_REQUEST_TIMEOUT = 1000;
    private static final int MAX_TOTAL = 400;
    private static final int DEFAULT_MAX_PER_ROUTE = 200;

    private static RequestConfig defaultRequestConfig = RequestConfig.custom()
            .setSocketTimeout(SOCKET_TIMEOUT)
            .setConnectionRequestTimeout(
                    CONNECTION_REQUEST_TIMEOUT)
            .setConnectTimeout(CONNECTION_TIMEOUT).build();

    static {
        BasicCookieStore cookieStore = new BasicCookieStore();
        BasicClientCookie cookie = new BasicClientCookie("JSESSIONID", "1234");
        cookie.setDomain(".github.com");
        cookie.setPath("/");
        cookieStore.addCookie(cookie);

        PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager();
        cm.setMaxTotal(MAX_TOTAL);
        cm.setDefaultMaxPerRoute(DEFAULT_MAX_PER_ROUTE);
        defaultHttpClient = HttpClients.custom()
                .setConnectionManager(cm)
                .setDefaultCookieStore(cookieStore)
                .build();
    }

    private XHttpUtils() {

    }


    /**
     * 发送post请求  专门用于使用最频繁的Content-Type 为json的请求
     *
     * @param url     请求行
     * @param headers 请求头 Content-Type 已经设置为json
     * @param content 请求体 json string 格式
     * @return map
     */
    public static ServiceResp<String> postJson(String url, Map<String, String> headers, String content) {
        return postJson(url, headers, content, defaultHttpClient, defaultRequestConfig);
    }

    /**
     * @param url           请求行
     * @param headers       请求头
     * @param content       请求体
     * @param httpClient    httpClient
     * @param requestConfig requestConfig
     * @return
     */
    public static ServiceResp<String> postJson(String url, Map<String, String> headers, String content,
                                               CloseableHttpClient httpClient, RequestConfig requestConfig) {
        CloseableHttpResponse response = null;
        try {
            HttpPost post = new HttpPost(url);
            post.setConfig(requestConfig);
            post.setHeader("Content-Type", "application/json;charset=UTF-8");
            post.setHeader("Accept-Charset", UTF_8);
            if (MapUtils.isNotEmpty(headers)) {
                for (Map.Entry<String, String> entry : headers.entrySet()) {
                    post.setHeader(entry.getKey(), entry.getValue());
                }
            }
            post.setEntity(buildJsonStringEntity(content));
            response = httpClient.execute(post);
            Header[] responseHeaders = response.getAllHeaders();
            HttpEntity httpResponseEntity = response.getEntity();
            String responseBody = EntityUtils.toString(httpResponseEntity, UTF_8);

            return ServiceResp.success(responseBody);
        } catch (IOException e) {
            log.error("postJson , url : {}  , content : {}", url, content, e);
            return ServiceResp.fail(500,
                    "网络错误" + e.getMessage());
        } finally {
            try {
                response.close();
            } catch (Exception e) {
            }
        }


    }

    public static HttpEntity buildJsonStringEntity(String string) {
        StringEntity entity = new StringEntity(string, UTF_8);
        entity.setContentType(ContentType.APPLICATION_JSON.getMimeType());
        entity.setContentEncoding(UTF_8);
        return entity;
    }

    public static ServiceResp<String> get(String url, Map<String, String> headers) {
        CloseableHttpResponse response = null;
        try {
            HttpGet get = new HttpGet(url);
            get.setConfig(defaultRequestConfig);
            get.setHeader("Accept-Charset", UTF_8);
            if (MapUtils.isNotEmpty(headers)) {
                for (Map.Entry<String, String> entry : headers.entrySet()) {
                    get.setHeader(entry.getKey(), entry.getValue());
                }
            }
            response = defaultHttpClient.execute(get);
            HttpEntity httpResponseEntity = response.getEntity();
            String responseBody = EntityUtils.toString(httpResponseEntity, UTF_8);

            return ServiceResp.success(responseBody);
        } catch (IOException e) {
            log.error("getError , url : {} ", url, e);
            return ServiceResp.fail(500,
                    "网络错误" + e.getMessage());
        } finally {
            try {
                response.close();
            } catch (Exception e) {
            }
        }
    }
}
