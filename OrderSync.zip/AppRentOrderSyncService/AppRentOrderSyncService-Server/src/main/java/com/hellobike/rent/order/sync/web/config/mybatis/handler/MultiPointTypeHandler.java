package com.hellobike.rent.order.sync.web.config.mybatis.handler;

import org.apache.ibatis.type.MappedTypes;
import org.postgis.MultiPoint;

/**
 * @author wt
 * @since 1.0.0
 */
@MappedTypes(MultiPoint.class)
public class MultiPointTypeHandler extends AbstractGeometryTypeHandler<MultiPoint>{

}
