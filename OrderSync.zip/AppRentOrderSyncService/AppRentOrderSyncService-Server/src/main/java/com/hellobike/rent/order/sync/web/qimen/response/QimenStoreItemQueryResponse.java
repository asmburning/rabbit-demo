package com.hellobike.rent.order.sync.web.qimen.response;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public  class QimenStoreItemQueryResponse<T extends QimenResponse> extends QimenResponse {

    private Long totalLines;

    private List<Long> itemIds;



}
