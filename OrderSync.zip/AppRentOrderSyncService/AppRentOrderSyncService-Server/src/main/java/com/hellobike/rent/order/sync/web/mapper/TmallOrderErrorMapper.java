package com.hellobike.rent.order.sync.web.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hellobike.rent.order.sync.web.model.TmallOrderErrorEntity;

/**
 * @author liuxinyi
 * @date 2019/9/25
 */
public interface TmallOrderErrorMapper extends BaseMapper<TmallOrderErrorEntity> {
}
