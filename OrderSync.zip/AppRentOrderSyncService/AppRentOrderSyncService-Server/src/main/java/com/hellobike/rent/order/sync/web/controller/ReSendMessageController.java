package com.hellobike.rent.order.sync.web.controller;

import com.hellobike.rent.order.sync.web.innerservice.TmallMainOrderService;
import com.hellobike.rent.order.sync.web.innerservice.TmallSendMqService;
import com.hellobike.rent.order.sync.web.mapper.TmallMainOrderMapper;
import com.hellobike.rent.order.sync.web.mapper.TmallSubOrderMapper;
import com.hellobike.rent.order.sync.web.model.TmallMainOrderEntity;
import com.hellobike.rent.order.sync.web.model.TmallSubOrderEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author liuxinyi
 * @date 2019/10/15
 */
@RestController
@Slf4j
@RequestMapping("/rentMessage")
public class ReSendMessageController {
    @Autowired
    private TmallMainOrderService mainOrderService;
    @Autowired
    private TmallMainOrderMapper mainOrderMapper;
    @Autowired
    private TmallSubOrderMapper subOrderMapper;
    @Autowired
    private TmallSendMqService sendMqService;

    @RequestMapping("/resend")
    public Object resend(@RequestBody ResendMessageVo resendMessageVo) throws Exception {
        mainOrderService.updateByTid(resendMessageVo.getTid());
        TmallMainOrderEntity mainOrderEntity = mainOrderMapper.selectById(resendMessageVo.getTid());
        TmallSubOrderEntity subOrderEntity = subOrderMapper.selectById(resendMessageVo.getOid());
        switch (resendMessageVo.getResendType()) {
            case "sellPay":
                sendMqService.sendSellInitPaidDeliveryMessage(mainOrderEntity, subOrderEntity);
                return "sellPay";
            case "rentPay":
                sendMqService.sendRentPaidMessage(mainOrderEntity, subOrderEntity);
                return "rentPay";
            case "sellDelivery":
                sendMqService.sendSellDeliveryMessage(resendMessageVo.getTid());
                return "sellDelivery";
            case "refundSuccess":
                sendMqService.sendOrderRefundMessage(mainOrderEntity, subOrderEntity);
                return "refundSuccess";
            case "orderFinish":
                sendMqService.sendOrderFinishedMessage(mainOrderEntity, subOrderEntity);
                return "orderFinish";
            case "deliveryOrder":
                sendMqService.sendBosDeliveryOrderMessage(mainOrderEntity, subOrderEntity, resendMessageVo.getMessageType());
                return "deliveryOrder";
        }
        return "OK";
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    static class ResendMessageVo {
        private Long tid;
        private Long oid;
        private String resendType;
        private String messageType;
    }
}
