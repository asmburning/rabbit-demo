package com.hellobike.rent.order.sync.web.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @author liuxinyi
 * @date 2019/9/25
 * 以oid为维度进行
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("t_rent_tmall_reconciliation")
public class TmallReconciliationEntity {
    @TableId
    private String guid;

    private Long tid;
    /**
     * 数据库关键字
     */
    @TableField("t_oid")
    private Long oid;

    private String orderStatus;

    private String goodsType;

    /**
     * goodsType 为 POWER_RENT 的时候需要核销使用兑换码之后发送配送信息
     */
    private Integer ticketUsed;
    private LocalDateTime ticketUseTime;
    private LocalDateTime ticketUseHandleTime;

    private Integer orderPaidHandled;
    private LocalDateTime orderPaidTime;
    private LocalDateTime orderPaidHandleTime;

    private Integer tradeCloseHandled;
    private LocalDateTime tradeCloseTime;
    private LocalDateTime tradeCloseHandleTime;

    private Integer completed;
    private LocalDateTime completeTime;

    private LocalDateTime createTime;
    private LocalDateTime updateTime;

    private String title;

    public boolean wasTicketUsed(){
        return Integer.valueOf(1).equals(this.ticketUsed);
    }

    public boolean wasOrderPaidHandled(){
        return Integer.valueOf(1).equals(this.orderPaidHandled);
    }

    public boolean wasTradeCloseHandled(){
        return Integer.valueOf(1).equals(this.tradeCloseHandled);
    }

    public boolean wasCompleted(){
        return Integer.valueOf(1).equals(this.completed);
    }
}
