package com.hellobike.rent.order.sync.web.qimen;

import com.hellobike.rent.order.sync.web.qimen.request.QimenRequest;
import com.hellobike.rent.order.sync.web.qimen.response.QimenResponse;
import com.taobao.api.internal.util.HttpResponseData;
import com.taobao.api.internal.util.TaobaoHashMap;
import com.taobao.api.internal.util.WebV2Utils;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

public class QimenClient {
    private String qimenUrl;
    private String appKey;
    private String secret;
    private String customerId;
    private String format = "xml";
    private String signMethod = "md5";
    private int connectTimeout = 15000;
    private int readTimeout = 30000;

    public QimenClient(){
        this.qimenUrl = "http://qimen.api.taobao.com/router/qimen/service?";
        this.appKey = "27810288";
        this.secret = "aa1a9f83e158ae548b53542d2d9bdd9c";
        this.customerId = "2206456792674";
    }

    public <T extends QimenResponse> T execute(QimenRequest<T> request) throws IOException {
        HttpResponseData data = this._execute(request.getApiMethodName(), request.getBody());

        return null;
    }


    private HttpResponseData _execute(String method, String body) throws IOException {
        LinkedHashMap<String, String> params = requestParams(method);
        String sign = generateSign(params, body);
        String requestUrl = buildRequestUrl(params,sign);
        TaobaoHashMap headerMap = new TaobaoHashMap();
        headerMap.put("Accept-Encoding", "gzip");
        HttpResponseData data = WebV2Utils.doPost(requestUrl, "text/xml;charset=utf-8", body.getBytes("UTF-8"), this.connectTimeout, this.readTimeout, headerMap, null);
        return data;
    }

    private  LinkedHashMap<String, String> requestParams (String method){
        LinkedHashMap<String, String> map = new LinkedHashMap();
        map.put("app_key",appKey);
        map.put("customerId",customerId);
        map.put("format",format);
        map.put("method",method);
        map.put("sign_method",signMethod);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        map.put("timestamp",sdf.format(new Date()));
        map.put("v","2.0");
        return map;
    }

    private  String md5(String source) {
        StringBuffer sb = new StringBuffer(32);
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] array = md.digest(source.getBytes("utf-8"));
            for (int i = 0; i < array.length; i++) {
                sb.append(Integer.toHexString((array[i] & 0xFF) | 0x100).toUpperCase(), 1, 3);
            }
        } catch (Exception e) {
            throw new RuntimeException("md5 error");
        }
        return sb.toString();
    }

    private  String generateSign(LinkedHashMap<String, String> map,String body)  {
        StringBuffer sb = new StringBuffer();
        sb.append(secret);
        for (Map.Entry<String, String> entry : map.entrySet()) {
            sb.append(entry.getKey()).append(entry.getValue());
        }
        sb.append(body).append(secret);
        String relust = md5(sb.toString());
        System.out.println("md5 origin:" + sb.toString());
        System.out.println("sign:" + relust);
        return relust;
    }

    private  String buildRequestUrl(LinkedHashMap<String, String> map,String sign) throws UnsupportedEncodingException {
        StringBuffer sb = new StringBuffer();
        sb.append(qimenUrl);
        for (Map.Entry<String, String> entry : map.entrySet()) {
            sb.append(entry.getKey()).append("=").append(URLEncoder.encode(entry.getValue(),"utf-8")).append("&");
        }
        sb.append("sign=").append(sign);
        System.out.println("request str:" + sb.toString());
        return sb.toString();
    }

    public static void main(String[] args) throws IOException {
//        String method = "taobao.qimen.storeitem.query";
//        String body = "<request> \n" +
//                "  <storeId>237864434</storeId>  \n" +
//                "  <page>1</page> \n" +
//                "</request>";
//        QimenClient qimenClient = new QimenClient();
//        HttpResponseData httpResponseData = qimenClient.execute(method,body);
//        System.out.println(JSON.toJSONString(httpResponseData));
    }








}
