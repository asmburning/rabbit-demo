package com.hellobike.rent.order.sync.web.innerservice;

import com.hellobike.rent.order.sync.resp.TmallOidQueryResp;
import com.hellobike.rent.order.sync.resp.TmallSubOrderResp;
import com.hellobike.rent.order.sync.web.model.TmallSubOrderEntity;

import java.util.List;

/**
 * @author gaohu08299
 * @create $ ID: TmallSubOrderService, 2019-09-29 17:45 gaohueric Exp $
 * @since 1.0.0
 */
public interface TmallSubOrderService {

    /**
     * 查询子订单信息
     *
     * @param oid
     * @return
     */
    TmallSubOrderResp querySubOrderInfo(Long oid);

    /**
     * @author liuxinyi
     * @date 2019/9/30
     */
    int sumNumByTid(Long tid);

    /**
     * 根据子订单oid查询主、子天猫订单信息
     * @param oid
     * @return
     */
    TmallOidQueryResp queryTmallMainSubInfoByOid(Long oid);

    /**
     * 过滤没有outerSkuId的周边商品
     * @param tid
     * @return
     */
    List<TmallSubOrderEntity> querySkuNotNoneListByTid(Long tid);

    TmallSubOrderEntity queryByOid(Long oid);

    void updateOidRefundId(Long oid, String refundId);

}
