package com.hellobike.rent.order.sync.web.reconciliation;

import com.hellobike.rent.order.sync.web.innerservice.TmallOrderInnerService;
import com.hellobike.rent.order.sync.web.util.ExceptionUtils;
import com.hellobike.rent.order.sync.web.util.YunLogger;
import com.taobao.api.domain.Trade;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;

/**
 * @author liuxinyi
 * @date 2019/9/29
 */
@Component
@Slf4j
public class TmallReconciliationComponent {
    @Autowired
    private TmallOrderInnerService orderInnerService;
    @Autowired
    private YunLogger yunLogger;

    public Trade getMaskFullInfo(Long tid) {
        try {
            return orderInnerService.getOrderFullInfoByTid(tid);
        } catch (Exception e) {
            log.error("getMaskFullInfoError tid:{}", tid, e);
            yunLogger.metric("RentTmallApi.apiError", new HashMap<String, Object>() {{
                put("tid", tid);
                put("errorMsg", ExceptionUtils.shortMessage(e, 4));
                put("method", "getFullInfo");
            }});
            throw new RuntimeException("getMaskFullInfoError" + e.getMessage(), e);
        }
    }
}
