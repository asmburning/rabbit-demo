package com.hellobike.rent.order.sync.web.controller;

import com.alibaba.fastjson.JSON;
import com.hellobike.rent.order.sync.iface.TmsTracePushToCainiaoService;
import com.hellobike.rent.order.sync.req.CainiaoTmsTraceReq;
import com.hellobike.rent.order.sync.web.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

import static com.hellobike.rent.order.sync.web.Constants.Cainiao.SUCCESS_JSON;


@RestController
@Slf4j
public class CainiaoController {

    @Autowired
    TmsTracePushToCainiaoService tracePushToCainiaoService;

    @Autowired
    AmqpTemplate amqpTemplate;

    @RequestMapping("/receiveCainiaoMessage" )
    public Object receiveCainiaoMessage(@RequestParam Map<String, String> params) {
        log.info("receiveCainiaoMessage ,params:{}", JSON.toJSONString(params));
        amqpTemplate.convertAndSend(Constants.Cainiao.CAINIAO_NOTIFY_EXCHANGE, Constants.Cainiao.CAINIAO_NOTIFY_ROUTING_KEY, JSON.toJSONString(params));
        log.info("send to queue success,message:{}", JSON.toJSONString(params));
        return SUCCESS_JSON;
    }

    @RequestMapping("/mockTmsTracePush" )
    public Object mockTmsAccept(@RequestBody CainiaoTmsTraceReq req) throws Exception {
        log.info("mockTmsAccept ,params:{}", JSON.toJSONString(req));
        return tracePushToCainiaoService.TmsTracePush(req);
    }




}





