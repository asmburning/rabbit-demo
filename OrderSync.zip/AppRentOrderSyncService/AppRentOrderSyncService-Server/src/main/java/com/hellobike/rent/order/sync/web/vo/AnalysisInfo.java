package com.hellobike.rent.order.sync.web.vo;

import com.hellobike.rent.merchant.model.common.StoreVO;
import com.hellobike.rent.order.sync.vo.SkuInfo;
import com.hellobike.rent.user.common.enums.ordersync.EnumTmallDeliveryType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author liuxinyi
 * @date 2019/9/30
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AnalysisInfo {
    private String cityCode;
    private SkuInfo skuInfo;
    private String storeId;
    private StoreVO storeVO;
    private EnumTmallDeliveryType deliveryType;
    private Integer carryType;
}
