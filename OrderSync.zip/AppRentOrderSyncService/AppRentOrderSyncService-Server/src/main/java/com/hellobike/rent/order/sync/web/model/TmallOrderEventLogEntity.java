package com.hellobike.rent.order.sync.web.model;

import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.core.toolkit.IdWorker;
import com.hellobike.rent.order.sync.enums.EnumTmallEventType;
import com.hellobike.rent.order.sync.web.message.TmallMessage;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @author liuxinyi
 * @date 2019/8/30
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@TableName("t_rent_tmall_order_event_log")
public class TmallOrderEventLogEntity {
    @TableId
    private String guid;
    private Long tid;
    private Long oid;
    private JSONObject message;
    private Boolean handled;
    /**
     * tmall2hello, hello2tmall
     */
    @TableField("eventtype")
    private String eventType;
    private String event;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;

    public static TmallOrderEventLogEntity buildInsert(TmallMessage eventMessage) {
        return TmallOrderEventLogEntity
                .builder()
                .guid(IdWorker.getIdStr())
                .tid(eventMessage.getTid())
                .oid(eventMessage.getOid())
                .createTime(LocalDateTime.now())
                .updateTime(LocalDateTime.now())
                .handled(false)
                .eventType(EnumTmallEventType.TMALL2HELLO.getEventType())
                .event(eventMessage.getTopic())
                .message(JSONObject.parseObject(eventMessage.getContent()))
                .build();
    }

}
