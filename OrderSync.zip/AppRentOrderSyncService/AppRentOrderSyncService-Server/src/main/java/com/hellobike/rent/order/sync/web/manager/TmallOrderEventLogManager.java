package com.hellobike.rent.order.sync.web.manager;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.hellobike.rent.order.sync.web.mapper.TmallOrderEventLogMapper;
import com.hellobike.rent.order.sync.web.model.TmallOrderEventLogEntity;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

/**
 * @author liuxinyi
 * @date 2019/9/3
 */
@Component
public class TmallOrderEventLogManager {

    @Autowired
    private TmallOrderEventLogMapper eventLogMapper;

    public boolean eventLogged(TmallOrderEventLogEntity eventLogEntity) {
        List<TmallOrderEventLogEntity> logs = eventLogMapper.selectList(new QueryWrapper<TmallOrderEventLogEntity>()
                .eq("tid", eventLogEntity.getTid())
                .eq("oid", eventLogEntity.getOid())
                .eq("event", eventLogEntity.getEvent()));
        return CollectionUtils.isNotEmpty(logs);
    }

    public boolean insert(TmallOrderEventLogEntity eventLogEntity) {
        int insert = eventLogMapper.insert(eventLogEntity);
        if (insert > 0) {
            return true;
        }
        return false;
    }

    public void updateHandled(String guid) {
        if (StringUtils.isBlank(guid)) {
            return;
        }
        eventLogMapper.updateById(TmallOrderEventLogEntity.builder()
                .guid(guid)
                .handled(true)
                .updateTime(LocalDateTime.now())
                .build());
    }

}
