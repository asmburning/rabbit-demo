package com.hellobike.rent.order.sync.web.innerservice;

import com.hellobike.rent.common.iface.resp.ServiceResp;
import com.hellobike.rent.order.sync.resp.TmallMainOrderResp;
import com.hellobike.rent.order.sync.web.model.TmallMainOrderEntity;

/**
 * @author liuxinyi
 * @date 2019/9/5
 */
public interface TmallMainOrderService {

    TmallMainOrderEntity selectByTid(Long tid);

    ServiceResp<String> updateByTid(Long tid);


    /**
     * 查询天猫主订单信息
     * @param tid
     * @return
     */
    TmallMainOrderResp queryMainOrderInfo(Long tid);
}
