package com.hellobike.rent.order.sync.web.innerservice;

import com.hellobike.rent.order.sync.enums.EnumTmallReconMessageType;

/**
 * @author liuxinyi
 * @date 2019/9/26
 */
public interface TmallOrderErrorService {


    void logError(Long tid, Long oid, EnumTmallReconMessageType reconMessageType, String errorMessage);

    void logError(Long tid, Long oid, String bosDeliveryOrder, String errorMessage);

    int updateErrorHandled(Long tid, Long oid, EnumTmallReconMessageType errorType);


    void dealTidPayUpdateError();

    void dealTidFinishUpdateError();

    void dealOidRefundSuccessUpdateError();
}
