package com.hellobike.rent.order.sync.web.innerservice;

import com.taobao.api.ApiException;
import com.taobao.api.domain.Refund;
import com.taobao.api.domain.Trade;

import java.util.Date;
import java.util.List;

public interface TmallOrderInnerService {


    /**
     * 查询订单详情, 不需要订单敏感信息 推荐使用该接口
     * @param tid
     * @return
     */
     Trade getOrderFullInfoByTid(long tid) throws ApiException;

    /**
     * 从聚石塔查询订单详情包含 手机号 配送地址等用户敏感信息 该接口性能不高
     * @param tid
     * @throws ApiException
     */
     Trade getOrderFullInfoByTidFromJushita(long tid) throws ApiException;

    /**
     * 核销订单
     * @param tid
     * @param code
     * @throws ApiException
     */
     void consumeOrderByCode(long tid, String code) throws ApiException;


    /**
     * 根据创建时间 订单状态查询所有订单
     * @param start
     * @param end
     * @param status 参见 https://open.taobao.com/doc.htm?docId=102856&docType=1
     * @return
     * @throws ApiException
     */
     List<Trade> getAllOrderByCreateTime(Date start,Date end,String status) throws ApiException;

    /**
     * 根据更新时间查所有订单
     * @param start
     * @param end
     * @param status
     * @return
     * @throws ApiException
     */
     List<Trade> getAllOrderByUpdateTime(Date start,Date end,String status) throws ApiException;


    /**
     * 根据退款单号查退款信息
     * @param refundId
     * @return
     * @throws ApiException
     */
     Refund getRefundOrderByRefundId(long refundId) throws ApiException;

    /**
     * 根据更新时间查退款订单
     * @param start
     * @param end
     * @return
     * @throws ApiException
     */
     List<Refund> getRefunds(Date start,Date end) throws ApiException;


}
