package com.hellobike.rent.order.sync.web.message;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TmallMessage {
    private String userNick;
    private Long id;
    /**
     * 兼容旧版消息
     */
    private String topic;
    private Long tid;
    private Long oid;
    private String content;
    private long createTime;
    private String tmallTopic;
    private String status;
}
