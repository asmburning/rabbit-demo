package com.hellobike.rent.order.sync.web.reconciliation;

import com.ctrip.framework.apollo.Config;
import com.ctrip.framework.apollo.spring.annotation.ApolloConfig;
import com.hellobike.base.redis.core.client.RedisClientManagement;
import com.hellobike.base.redis.core.model.key.Key;
import com.hellobike.rent.order.sync.enums.EnumTmallOrderStatus;
import com.hellobike.rent.order.sync.web.cache.NewRedisKey;
import com.hellobike.rent.order.sync.web.innerservice.*;
import com.hellobike.rent.order.sync.web.message.TmallMessage;
import com.hellobike.rent.order.sync.web.message.TmallMessageComponent;
import com.hellobike.rent.order.sync.web.util.ExceptionUtils;
import com.hellobike.rent.order.sync.web.util.ThreadPools;
import com.hellobike.rent.order.sync.web.util.YunLogger;
import com.hellobike.rent.order.sync.web.vo.ReconVo;
import com.taobao.api.domain.Refund;
import com.taobao.api.domain.Trade;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Collectors;

/**
 * @author liuxinyi
 * @date 2019/9/25
 */
@Service
@Slf4j
public class ReconciliationOrderComponent {

    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
    @ApolloConfig
    private Config config;
    @Autowired
    private TmallOrderInnerService orderInnerService;
    @Autowired
    private TmallMainOrderService mainOrderService;
    @Autowired
    private YunLogger yunLogger;
    @Autowired
    private OrderEnvService orderEnvService;
    @Autowired
    private TmallReconciliationComponent reconciliationComponent;
    @Autowired
    private ReconciliationMessageComponent reconciliationMessageComponent;
    @Autowired
    private TmallOrderAnalysisService analysisService;
    @Autowired
    private TmallMessageComponent messageComponent;
    @Autowired
    private TmallSubOrderService subOrderService;

    private LocalDateTime formatDate(String s) {
        try {
            return LocalDateTime.parse(s, formatter);
        } catch (Exception e) {
            return null;
        }
    }

    private int queryRangeMinutes() {
        return config.getIntProperty("tamll.queryRange.minutes", 90);
    }

    public LocalDateTime calculateQueryStartTime(String status) {
        Key key = NewRedisKey.reconciliationQueryTime(status);
        String s = RedisClientManagement.getInstance().get(key);
        if (StringUtils.isNotBlank(s)) {
            LocalDateTime cacheTime = formatDate(s);
            if (null != cacheTime) {
                LocalDateTime rangeAge = LocalDateTime.now().minusMinutes(queryRangeMinutes());
                if (rangeAge.isBefore(cacheTime)) {
                    return rangeAge;
                }
                return cacheTime;
            }
        }
        LocalDateTime start = LocalDateTime.now().minusMinutes(queryRangeMinutes()).minusMinutes(1);
        s = formatter.format(start);
        RedisClientManagement.getInstance().set(key, s);
        return start;
    }

    public String updateQueryStartTime(String status) {
        Key key = NewRedisKey.reconciliationQueryTime(status);
        String s = RedisClientManagement.getInstance().get(key);
        if (StringUtils.isNotBlank(s)) {
            LocalDateTime redisStartTime = formatDate(s);
            LocalDateTime halfAgo = LocalDateTime.now().minusMinutes(queryRangeMinutes() / 2);
            if (null != redisStartTime) {
                if (redisStartTime.isAfter(LocalDateTime.now())) {
                    RedisClientManagement.getInstance().del(key);
                    return "--";
                }
                redisStartTime = redisStartTime.plusMinutes(queryRangeMinutes() / 2);
                if (redisStartTime.isAfter(halfAgo)) {
                    redisStartTime = halfAgo;
                }
                s = formatter.format(redisStartTime);
                RedisClientManagement.getInstance().set(key, s);
            }
        }
        return s;
    }

    public List<Trade> queryOrderList(String status) {
        try {
            LocalDateTime start = calculateQueryStartTime(status);
            ZoneOffset offset = OffsetDateTime.now().getOffset();
            Instant instant = start.toInstant(offset);
            Date startDate = Date.from(instant);
            LocalDateTime end = start.plusMinutes(queryRangeMinutes());
            Instant endInstant = end.toInstant(offset);
            Date endDate = Date.from(endInstant);
            log.info("getAllOrderByUpdateTime{} start:{}, end:{}", status, startDate, endDate);
            List<Trade> allOrderByUpdateTime = orderInnerService.getAllOrderByUpdateTime(startDate, endDate, status);
            if (null == allOrderByUpdateTime) {
                allOrderByUpdateTime = new ArrayList<>();
            }
            return allOrderByUpdateTime;
        } catch (Exception e) {
            log.error("getAllOrderByTimeError status:{}", status, e);
            String shortMessage = ExceptionUtils.shortMessage(e, 4);
            yunLogger.metric("RentTmallApi.apiError", new HashMap<String, Object>() {
                {
                    put("errorMsg", shortMessage);
                    put("status", status);
                    put("method", "getAllOrderByUpdateTime");
                }
            });
            throw new RuntimeException("getAllOrderByTimeError" + e.getMessage());
        }
    }

    public void reconciliationTidTmallOrder(EnumTmallOrderStatus tmallOrderStatus) {
        List<Trade> tradeList = queryOrderList(tmallOrderStatus.getStatus());
        if (CollectionUtils.isEmpty(tradeList)) {
            updateQueryStartTime(tmallOrderStatus.getStatus());
            return;
        }

        List<Trade> needHandleTradeList = filterCurrentEnvTradeCollect(tmallOrderStatus, tradeList);
        log.info("reconciliationTidTmallOrder status:{}, needHandleSize:{}", tmallOrderStatus, needHandleTradeList.size());

        Consumer<Trade> tradeConsumer = null;
        if (tmallOrderStatus == EnumTmallOrderStatus.WAIT_SELLER_SEND_GOODS ||
                tmallOrderStatus == EnumTmallOrderStatus.WAIT_BUYER_CONFIRM_GOODS) {
            needHandleTradeList = filterStepRefundTrade(tmallOrderStatus, tradeList);

            tradeConsumer = trade -> messageComponent.handleTmallPayMessage(
                    TmallMessage.builder()
                            .tid(trade.getTid())
                            .oid(trade.getTid())
                            .build());
        }
        // 天猫支付消息 按tid维度进行处理
        if (null != tradeConsumer) {
            needHandleTradeList.stream().forEach(tradeConsumer);
        }
        updateQueryStartTime(tmallOrderStatus.getStatus());

    }

    /**
     * 批量校验以oid为维度的订单
     *
     * @param tmallOrderStatus
     */
    public void reconciliationOidTmallOrder(EnumTmallOrderStatus tmallOrderStatus) {
        List<Trade> tradeList = queryOrderList(tmallOrderStatus.getStatus());
        if (CollectionUtils.isEmpty(tradeList)) {
            updateQueryStartTime(tmallOrderStatus.getStatus());
            return;
        }

        List<Trade> needHandleTradeList = filterCurrentEnvTradeCollect(tmallOrderStatus, tradeList);
        log.info("reconciliationOidTmallOrder status:{}, needHandleSize:{}", tmallOrderStatus, needHandleTradeList.size());

        // filter oid status
        List<ReconVo> reconVoList = needHandleTradeList.stream().flatMap(trade -> trade.getOrders().stream()
                .filter(order -> order.getStatus().equalsIgnoreCase(tmallOrderStatus.getStatus()))
                .map(order -> ReconVo.builder()
                        .tid(trade.getTid())
                        .oid(order.getOid())
                        .tradeStatus(trade.getStatus())
                        .orderStatus(order.getStatus())
                        .build())
        ).collect(Collectors.toList());

        // 订单关闭或者完成 按oid维度发送消息
        if (tmallOrderStatus == EnumTmallOrderStatus.TRADE_CLOSED) {
            for (ReconVo reconVo : reconVoList) {
                ThreadPools.submitDealRefundSuccessTask(
                        () -> reconciliationMessageComponent.reconOidRefundSuccessMessage(
                                reconVo.getTid(), reconVo.getOid()));
            }
        } else if (tmallOrderStatus == EnumTmallOrderStatus.TRADE_FINISHED) {
            Set<Long> tidSet = reconVoList.stream().map(ReconVo::getTid).collect(Collectors.toSet());
            for (Long tid : tidSet) {
                ThreadPools.submitDealRefundSuccessTask(
                        () -> reconciliationMessageComponent.reconciliationTidFinishMessage(tid));
            }
        }
        updateQueryStartTime(tmallOrderStatus.getStatus());

    }

    @NotNull
    private List<Trade> filterCurrentEnvTradeCollect(EnumTmallOrderStatus tmallOrderStatus, List<Trade> tradeList) {
        return tradeList.stream().filter(trade -> {
            String orderEnv = analysisService.analysisEnvByTid(trade.getTid());
            log.info("filterCurrentEnvTradeCollect tid:{}, orderEnv:{} , orderStatus:{}", trade.getTid(), orderEnv, tmallOrderStatus);
            return !analysisService.shouldForward(orderEnv);
        }).collect(Collectors.toList());
    }

    /**
     * 预售订单退款过滤
     *
     * @param tmallOrderStatus
     * @param tradeList
     * @return
     */
    @NotNull
    public List<Trade> filterStepRefundTrade(EnumTmallOrderStatus tmallOrderStatus, List<Trade> tradeList) {
        return tradeList.stream().filter(trade -> {
            String type = trade.getType();
            boolean step = StringUtils.equals("step", type);
            String refundId = trade.getOrders().get(0).getRefundId();
            boolean hasRefund = StringUtils.isNotBlank(refundId);
            log.info("filterCurrentEnvTradeCollect tid:{}, orderEnv:{} , type:{},hasRefund:{}",
                    trade.getTid(), type, tmallOrderStatus, hasRefund);
            return !(step && hasRefund);
        }).collect(Collectors.toList());
    }

    @NotNull
    private List<Refund> filterCurrentEnvSuccessRefund(List<Refund> refundList) {
        return refundList.stream()
                .filter(refund -> refund.getStatus().equals("SUCCESS"))
                .filter(refund -> {
                    String orderEnv = analysisService.analysisEnvByTid(refund.getTid());
                    log.info("filterCurrentEnvRefund tid:{}, orderEnv:{}", refund.getTid(), orderEnv);
                    return !analysisService.shouldForward(orderEnv);
                }).collect(Collectors.toList());
    }

    /**
     * 批量查询退款并校验
     */
    public void reconciliationRefund() {
        String status = "refunds";
        LocalDateTime start = calculateQueryStartTime(status);
        ZoneOffset offset = OffsetDateTime.now().getOffset();
        Instant instant = start.toInstant(offset);
        Date startDate = Date.from(instant);
        LocalDateTime end = start.plusMinutes(queryRangeMinutes());
        Instant endInstant = end.toInstant(offset);
        Date endDate = Date.from(endInstant);
        List<Refund> refunds = null;
        try {
            log.info("reconciliationRefund queryRefunds startDate:{}, endDate:{}", startDate, endDate);
            refunds = orderInnerService.getRefunds(startDate, endDate);
        } catch (Exception e) {
            log.error("reconciliationRefundError", e);
            return;
        }
        if (CollectionUtils.isEmpty(refunds)) {
            updateQueryStartTime(status);
        }
        List<Refund> currentEnvRefunds = filterCurrentEnvSuccessRefund(refunds);
        if (CollectionUtils.isEmpty(currentEnvRefunds)) {
            updateQueryStartTime(status);
            return;
        }
        log.info("reconciliationRefund startDate:{},endDate:{},needReconSize:{}",
                startDate, endDate, currentEnvRefunds.size());
        for (Refund refund : currentEnvRefunds) {
            subOrderService.updateOidRefundId(refund.getOid(), refund.getRefundId());
            Runnable runnable = () -> reconciliationMessageComponent
                    .reconOidRefundSuccessMessage(refund.getTid(), refund.getOid());
            ThreadPools.submitDealRefundSuccessTask(runnable);
        }
        updateQueryStartTime(status);
    }

}
