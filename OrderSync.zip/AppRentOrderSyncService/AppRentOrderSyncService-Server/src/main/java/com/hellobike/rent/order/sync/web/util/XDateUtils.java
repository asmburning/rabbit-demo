package com.hellobike.rent.order.sync.web.util;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Date;

/**
 * @author liuxinyi
 * @date 2019/10/16
 */
public class XDateUtils {

    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public static String toString(LocalDateTime localDateTime) {
        return toString(localDateTime, DATE_TIME_FORMATTER);
    }

    public static String toString(LocalDateTime localDateTime, DateTimeFormatter dateTimeFormatter) {
        return dateTimeFormatter.format(localDateTime);
    }

    public static String currentDateString() {
        return DATE_TIME_FORMATTER.format(LocalDateTime.now());
    }

    public static Date toDate(LocalDateTime localDateTime) {
        if (null == localDateTime) {
            return null;
        }
        ZoneOffset offset = OffsetDateTime.now().getOffset();
        Instant instant = localDateTime.toInstant(offset);
        return Date.from(instant);
    }

    public static void main(String[] args) {
        System.out.println(currentDateString());
    }
}
