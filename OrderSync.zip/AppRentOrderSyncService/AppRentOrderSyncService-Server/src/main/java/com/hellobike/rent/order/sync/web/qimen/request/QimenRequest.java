package com.hellobike.rent.order.sync.web.qimen.request;


import com.hellobike.rent.order.sync.web.qimen.response.QimenResponse;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public abstract class QimenRequest<T extends QimenResponse> implements Serializable {

    private String body;

    public abstract String getApiMethodName();

    public abstract Class<T> getResponseClass();
}
