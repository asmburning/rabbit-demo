# 帮助文档

# setup before start
1 vm options:
-Dowl.metrics.kafka.servers=newdev-kafka1.ttbike.com.cn:9092,newdev-kafka2.ttbike.com.cn:9092,newdev-kafka3.ttbike.com.cn:9092 -DAPPID=AppRentOrderSyncService
2 Environment variables:
spring.profiles.active=dev
3 connect to aliyun vpn
4 start spring boot application

# 日志打印说明 
1直接在类上加注解 @SLFJ  2 直接使用 log.info()和log.error()

解压日志
gzip -cd common-logback.log.2019-09-19.0.gz >0919.log


https://hellobike.yuque.com/vl1gd8/sr4wh0/zpztge

# 中间件需要配置

ES客户端配置文件；
resources/middlerware/es.json

Habbitmq配置文件：
resources/middlerware/mq.json

数据库：
需要初始化DataSource

天猫订单同步
1 天猫支付
以tid为维度发送售车配送消息
以oid为维度发送同步消息（可能会有售车和租车子订单的情况）





