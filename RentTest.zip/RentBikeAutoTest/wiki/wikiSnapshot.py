#!/usr/bin/env python
# encoding: utf-8
# Created by liuxinyi at 2019-04-24

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from pyquery import PyQuery

import datetime
import pdfkit
from PyPDF4 import PdfFileMerger, PdfFileReader
import os


def getCookie():
    driver = webdriver.Chrome()
    driver.maximize_window()
    driver.get("http://wiki.cheyaoshicorp.com/")
    WebDriverWait(driver, 5).until(
        EC.presence_of_element_located((By.ID, "os_username"))
    )
    driver.find_element_by_id("os_username").send_keys("liuxinyi05972")
    driver.find_element_by_id("os_password").send_keys("Hellobike@2018")
    driver.find_element_by_id("loginButton").click()

    cookie = driver.get_cookie("JSESSIONID")
    cookie_value = cookie['value']
    driver.close()
    return cookie_value


def crawlerUrls(startUrl, token):
    my_cookies = {'JSESSIONID': token}
    page = PyQuery(url=startUrl, encoding="utf-8", cookies=my_cookies)

    urlSet = set()
    urlSet.add(startUrl)

    links = page('#content .confluenceTd a').items()
    for link in links:
        href = link.attr("href")
        if not href.startswith('http://wiki.cheyaoshicorp.com'):
            href = 'http://wiki.cheyaoshicorp.com' + href
        urlSet.add(href)
        print(link.text())
    return urlSet


def getPageTitle(token, pageUrl):
    my_cookies = {'JSESSIONID': token}
    page = PyQuery(url=pageUrl, encoding="utf-8", cookies=my_cookies)
    page_title = page('title').text()
    page_title = page_title.replace('- 研发中心 - wiki内网', '')
    return page_title.strip()


def savePagesToPdf(token, urls):
    my_options = {
        'page-size': 'A2',
        'margin-top': '0.75in',
        'margin-right': '0.75in',
        'margin-bottom': '0.75in',
        'margin-left': '0.75in',
        'encoding': "UTF-8",
        'custom-header': [
            ('Accept-Encoding', 'UTF-8')
        ],
        'cookie': [
            ('JSESSIONID', token),
            ('cookie-name2', 'cookie-value2'),
        ],
        'no-outline': None
    }
    for url in urls:
        print(url)
        briefTitle = getPageTitle(token, url)
        pageSnapshot = datetime.datetime.now().strftime('%Y%m%d%H%M%S') + ' - ' + briefTitle
        pdfkit.from_url(url, pageSnapshot + ".pdf", options=my_options)


if __name__ == '__main__':
    startUrl = "http://wiki.cheyaoshicorp.com/pages/viewpage.action?pageId=62720360"
    token = getCookie()
    urlSet = crawlerUrls(startUrl, token)
    savePagesToPdf(token, urlSet)
