from service.http import ApiHttpClient
from service.http import AuthHttpClient
import base64
import io
import pytesseract
from PIL import Image
from common.util import jsonutil

mobile = '17602107310'
env = 'fat'
newMobile = '17602107310'
# login
commonDict = ApiHttpClient.one_step_get_token(mobile, env)

# checkNeedVerify
checkNeedDict = ApiHttpClient.check_need_verify(commonDict, env)
if not checkNeedDict['data']['needVerify']:
    print("don't needVerify exit")
    print(jsonutil.dumps_pretty(checkNeedDict))
    exit()

# send smsCode
send_code_res = ApiHttpClient.send_sms_verify_code(commonDict, env)

# showCapText
imageBase64 = send_code_res['data']['imageCaptcha']
capImageData = base64.b64decode(imageBase64.split(",")[1])
image = Image.open(io.BytesIO(capImageData))
image.show()

# ocr
optCode = pytesseract.image_to_string(image)
print("验证码：", optCode)

# receive CapText
cap_text = input('please input cap_text:')
image.close()

# setVerifyCode
AuthHttpClient.send_sms_code(newMobile, env)
commonDict['capText'] = cap_text
commonDict['newMobile'] = newMobile
commonDict['verifyCode'] = '1234'

# doVerifyMobile
verifyRes = ApiHttpClient.verifyMobile(commonDict, env)
print(jsonutil.dumps_pretty(verifyRes))
