import random
import string
from common.db import DbUtil
from common.cache import RedisUtil
from uuid import uuid4
from common.util import jsonutil

modelInfo = dict()
modelInfo['guid'] = 'b8ec299dc4834c0ba573ff69c03e87e7'
modelInfo['modelId'] = '1030391482648797185'
modelInfo['spec_w_guid'] = 'c29528e30c274f70949e0eb43c8cb1bb'
modelInfo['spec_w_id'] = '1030391483814813698'
modelInfo['spec_b_guid'] = '957f99968dcc481aa2ce82bac7b5f2d4'
modelInfo['spec_b_id'] = '1030391483600904194'


def randBikeNo():
    return '20220' + str(random.randint(10000, 90000))


def randUuid():
    return uuid4().hex


def randomword(length):
    letters = string.ascii_lowercase
    return ''.join(random.choice(letters) for i in range(length))


def getCityInfo():
    return ['1054969017398648833', '021', '上海市']


def createBike(env, spec='spec_w_guid'):
    cityInfo = getCityInfo()
    bikeInfo = [randUuid(), randBikeNo(), '2022110801', randomword(8), randomword(9), randomword(7),
                cityInfo[0], cityInfo[1], cityInfo[2], modelInfo['guid'], modelInfo[spec]]
    DbUtil.createBike(env, bikeInfo)
    return bikeInfo


def increaseStock(env, spec_id):
    RedisUtil.increaseStock(env, spec_id)


if __name__ == '__main__':
    env = 'dev'
    bikeInfo = createBike(env, 'spec_b_guid')
    # increaseStock(env, modelInfo['spec_b_id'])
    print(jsonutil.dumps_pretty(bikeInfo))
