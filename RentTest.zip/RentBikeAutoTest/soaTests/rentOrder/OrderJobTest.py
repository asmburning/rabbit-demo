from service.soa.rentOrder import OrderJobIface as P
from common.util import jsonutil

timeout = 20


def executeInsurePostProcess():
    res = P.executeInsurePostProcess(timeout)
    print("method:{}. success:{} data:\n{}.".format('executeInsurePostProcess', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


if __name__ == '__main__':
    executeInsurePostProcess()
