from service.soa.rentOrder import OrderInsuranceIface as P
from common.util import jsonutil

orderGuid2 = 1156181020366413826
orderId = '20190712115557184120000153294'


def manualInsure():
    res = P.manualInsure(orderGuid2)
    print("method:{}. success:{} data:\n{}.".format('manualInsure', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


def reInsure():
    res = P.reInsure(orderId)
    print("method:{}. success:{} data:\n{}.".format('reInsure', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


if __name__ == '__main__':
    reInsure()
