from service.soa.rentOrder import OrderRefundIface as P
from common.util import jsonutil

timeout = 20


def queryRefundReason():
    res = P.queryRefundReason()
    print("method:{}. success:{} data:\n{}.".format('queryRefundReason', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


def queryRefundInfo(orderId):
    res = P.queryRefundInfo(orderId)
    print("method:{}. success:{} data:\n{}.".format('queryRefundInfo', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


def orderRefund():
    orderId = "20190822125123834120000162496"
    queryRefundInfo(orderId)
    arg0 = dict()
    arg0['orderId'] = orderId
    arg0['refundType'] = 1
    arg0['amount'] = "0.01"
    arg0['refundReason'] = "a"
    arg0['refundReasonDetail'] = "b"
    res = P.billRefund(arg0)
    print("method:{}. success:{} data:\n{}.".format('billRefund', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


def billRefund():
    orderId = "20190301141608252120000122601"
    queryRefundInfo(orderId)
    arg0 = dict()
    arg0['orderId'] = orderId
    arg0['refundType'] = 2
    arg0['amount'] = "0.01"
    arg0['refundReason'] = "a"
    arg0['refundReasonDetail'] = "b"
    res = P.billRefund(arg0)
    print("method:{}. success:{} data:\n{}.".format('billRefund', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


def preAuthRefund():
    arg0 = dict()
    arg0['orderId'] = ""
    arg0['refundType'] = 3
    arg0['amount'] = "0.1"
    arg0['refundReason'] = "a"
    arg0['refundReasonDetail'] = "b"
    res = P.billRefund(arg0)
    print("method:{}. success:{} data:\n{}.".format('billRefund', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


if __name__ == '__main__':
    orderRefund()
