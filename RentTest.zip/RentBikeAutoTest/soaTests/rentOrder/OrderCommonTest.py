from service.soa.rentOrder import OrderCommonIface as P
from common.util import jsonutil

orderId = '20181108163909503120000080630'


def getOrderInfo():
    res = P.getOrderInfo(orderId)
    print("method:{}. success:{} data:\n{}.".format('getOrderInfo', res.success, jsonutil.dumps_pretty(res.data)))


if __name__ == '__main__':
    getOrderInfo()
