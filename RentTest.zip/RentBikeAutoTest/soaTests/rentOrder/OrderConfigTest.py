from service.soa.rentOrder import OrderConfigIface as P
from common.util import jsonutil

guid = '4d9dc6f4b4c240ae8f019ef95c6d625c'
ad_code = '310112'
city_code = '021'

position1 = '121.375231,31.151427'
lnglat1 = position1.split(',')
position2 = '121.677355,31.147314'
lnglat2 = position2.split(',')

lnglat = lnglat2
lng = lnglat[0]
lat = lnglat[1]


def query_cert_info_unmask_res():
    res = P.query_cert_info_unmask(guid)
    print("method:{}. success:{} data:\n{}.".format('query_cert_info_unmask', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


def testDelivery():
    deliveryData = dict()
    deliveryData['adCode'] = ad_code
    deliveryData['cityCode'] = city_code
    deliveryData['lng'] = lng
    deliveryData['lat'] = lat
    res = P.calculateDeliveryPrice(deliveryData)
    print("method:{}. success:{} data:\n{}.".format('calculateDeliveryPrice', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


def testCollect():
    collectData = dict()
    collectData['adCode'] = '442000'
    collectData['cityCode'] = city_code
    collectData['lng'] = lng
    collectData['lat'] = lat
    collectData['orderId'] = '20181119112212033120000084468'
    res = P.calculateCollectPrice(collectData)
    print("method:{}. success:{} data:\n{}.".format('calculateCollectPrice', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


def viewCanRent():
    collectData = dict()
    collectData['adCode'] = ad_code
    collectData['cityCode'] = city_code
    collectData['apiVersion'] = '1.5.0'
    collectData['bikeNo'] = '2022073271'
    collectData['_uuid'] = '0425fed249834a43be9db8567c1c90d3'
    collectData['userNewId'] = '1200000945'
    res = P.viewCanRent(collectData)
    print("method:{}. success:{} data:\n{}.".format('viewCanRent', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


if __name__ == '__main__':
    viewCanRent()
