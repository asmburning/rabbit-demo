from service.soa.userData import BosOrderSupportIface as face
from common.util import jsonutil

user_new_id = '1200000748'
guid = '044e398d0bbb46c7978731ddbd982785'
mobile = '17602107305'


def queryCityOrderIncomeAndExpenditure():
    res = face.queryCityOrderIncomeAndExpenditure('021', None)
    print("method:{}. success:{} data:\n{}.".format('queryCityOrderIncomeAndExpenditure', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


def queryCityOrderInfo():
    res = face.queryCityOrderInfo('021')
    print("method:{}. success:{} data:\n{}.".format('queryCityOrderInfo', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


if __name__ == '__main__':
    queryCityOrderInfo()
