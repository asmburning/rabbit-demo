from service.soa.rentUser import RentVerifyIface as VF
from common.util import jsonutil

user_new_id = '1200000748'
guid = '044e398d0bbb46c7978731ddbd982785'
mobile = '17602107305'


def change_verify_cap_text():
    res = VF.change_verify_cap_text(mobile)
    print("method:{}. success:{} data:\n{}.".format('change_verify_cap_text', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


def check_need_verify():
    res = VF.check_need_verify(user_new_id, guid)
    print("method:{}. success:{} data:\n{}.".format('check_need_verify', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


def send_sms_verify_code():
    res = VF.send_sms_verify_code(user_new_id, mobile)
    print("method:{}. success:{} data:\n{}.".format('send_sms_verify_code', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


if __name__ == '__main__':
    check_need_verify()
