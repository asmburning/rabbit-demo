from service.soa.rentUser import UserRemindIface as F
from common.util import jsonutil

MAIN_BATTERY_LOW_POWER = "MAIN_BATTERY_LOW_POWER"
LOW_POWER = "LOW_POWER"
FORGOT_CLOSE_LOCK = "FORGOT_CLOSE_LOCK"

userNewId = '1200000748'
mobile = '17602107305'


def queryUserRemind():
    res = F.queryUserRemind(userNewId)
    print("method:{}. success:{} data:\n{}.".format('queryUserRemind', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


def updateUserRemind(remindType, needRemind=True):
    res = F.updateUserRemind(userNewId, remindType, needRemind)
    print("method:{}. success:{} data:\n{}.".format('updateUserRemind', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


if __name__ == '__main__':
    queryUserRemind()
    # updateUserRemind(MAIN_BATTERY_LOW_POWER, False)
