from service.soa.rentActivity import RentVoucherAppendIface as P
from common.util import jsonutil

cityCode = '021'
cityCodeWithAdCode = '021310101'


def testMq():
    params = dict()
    params['voucherGuid'] = '1080391899859578882'
    params['sellOrderId'] = '1080391899972825090'
    res = P.testMq(params)
    print("method:{}. success:{} data:\n{}.".format('buyVoucherCallBack', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


if __name__ == '__main__':
    testMq()
