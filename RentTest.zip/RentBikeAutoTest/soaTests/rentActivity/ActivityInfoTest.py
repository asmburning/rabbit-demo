from service.soa.rentActivity import ActivityInfoIface as P
from common.util import jsonutil

cityCode = '021'
cityCodeWithAdCode = '021310101'


def buyVoucherCallBack():
    params = dict()
    params['voucherGuid'] = '1080726349625634817'
    params['sellOrderId'] = '1080726350573486081'
    params['userNewId'] = '1200000571'
    res = P.buyVoucherCallBack(params)
    print("method:{}. success:{} data:\n{}.".format('buyVoucherCallBack', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


if __name__ == '__main__':
    buyVoucherCallBack()
