from service.soa.rentFinance import FinanceTestIface as P
from common.util import jsonutil

chargeGuid = 1156911119667654657


def sendWeChatMq():
    res = P.sendWeChatMq(chargeGuid)
    print("method:{}. success:{} data:\n{}.".format('sendWeChatMq', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


def sendWeChatMessage():
    res = P.sendWeChatMessage(chargeGuid)
    print("method:{}. success:{} data:\n{}.".format('sendWeChatMessage', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


if __name__ == '__main__':
    sendWeChatMq()
