from service.soa.bikeManager import BosSupportIface as P
from common.util import jsonutil

cityCode = '021'
cityCodeWithAdCode = '021310101'


def queryRentRecoverBikeTaskForCondition():
    res = P.queryRentRecoverBikeTaskForCondition()
    print("method:{}. success:{} data:\n{}.".format('queryRentRecoverBikeTaskForCondition', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


if __name__ == '__main__':
    queryRentRecoverBikeTaskForCondition()
