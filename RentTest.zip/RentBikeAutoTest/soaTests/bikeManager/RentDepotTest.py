from service.soa.bikeManager import RentDepotIface as P
from common.util import jsonutil

guid = '12345'


def queryDepotByGuid():
    res = P.queryDepotByGuid(guid)
    print("method:{}. success:{} data:\n{}.".format('queryDepotByGuid', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


if __name__ == '__main__':
    queryDepotByGuid()
