from service.soa.bikeManager import PartnerManageIface as P
from common.util import jsonutil

user_new_id = '1200000748'
guid = '044e398d0bbb46c7978731ddbd982785'
mobile = '17602107305'


def query_partner_list():
    res = P.query_partner_list('', '')
    print("method:{}. success:{} data:\n{}.".format('query_partner_list', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


def query_partner_page():
    res = P.query_partner_page('', '')
    print("method:{}. success:{} data:\n{}.".format('query_partner_page', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


def partner_name_available():
    res = P.partner_name_available(None, 'abc')
    print("method:{}. success:{} data:\n{}.".format('partner_name_available', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


def query_partner():
    res = P.query_partner("", 'abc')
    print("method:{}. success:{} data:\n{}.".format('query_partner', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


def add_partner():
    res = P.add_partner('java11')
    print("method:{}. success:{} data:\n{}.".format('add_partner', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


def edit_partner():
    res = P.edit_partner('1067340537166753794', 'Python3.7')
    print("method:{}. success:{} data:\n{}.".format('edit_partner', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


if __name__ == '__main__':
    partner_name_available()
