from service.soa.baseData import cityManage as VF
from common.util import jsonutil


def getCityConfig(cityCode):
    res = VF.getCityConfig(cityCode)
    print("method:{}. success:{} data:\n{}.".format('getCityConfig', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


def setCityConfig():
    res = VF.setCityConfig()
    print("method:{}. success:{} data:\n{}.".format('setCityConfig', res.success,
                                                    jsonutil.dumps_pretty(res.data)))


if __name__ == '__main__':
    setCityConfig()
    # getCityConfig("021")
