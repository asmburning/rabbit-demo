from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
from autoCheck import CheckUrls

driver = webdriver.Chrome()

driver.get(CheckUrls.es_url)
driver.get(CheckUrls.slow_sql_url)
driver.get(CheckUrls.job_screens_url)
driver.get(CheckUrls.job_latestData_url)
# WebDriverWait(driver, 5).until(
#     EC.presence_of_element_located((By.ID, "kw"))
# )
