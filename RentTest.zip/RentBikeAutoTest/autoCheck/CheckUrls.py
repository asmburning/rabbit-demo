es_url = "http://es.hellobike.cn/app/kibana#/discover?_g=(refreshInterval:(display:Off,pause:!f,value:0),time:(from:now-24h,mode:quick,to:now))&_a=(columns:!(_source),index:AWNo0Bm48rzfYIoq2XAR,interval:auto,query:(query_string:(query:'logLevel:ERROR%20AND%20appid:%20(com.hellobike.rent*%20com.easybike.rent.*)')),sort:!(logTime,desc))"

slow_sql_url = ""

job_screens_url = ""

job_latestData_url = ""
