#!/usr/bin/env python
# encoding: utf-8
# Created by liuxinyi at 2019-02-27

from common.cache import RedisUtil


def scanVoucherAppendMaxSms(env):
    RedisUtil.scan(env, "power_rent:voucher_append_max:*")


if __name__ == '__main__':
    scanVoucherAppendMaxSms('fat')
