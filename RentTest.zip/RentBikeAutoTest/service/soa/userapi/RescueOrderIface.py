from common.soa.clients import AppRentUserApiClient as client
import json
from common.util import jsonutil

iface = "com.hellobike.rent.user.api.iface.RescueOrderApiIface"


def queryRescuePageInfo():
    data = dict()
    data['orderId'] = '22233'
    request_data = dict()
    print(json.dumps(data))
    request_data['arg0'] = json.dumps(data)
    request_json = json.dumps(request_data)
    return client.run(iface, 'queryRescuePageInfo', request_json)


def createRescueOrder():
    data = dict()
    data['cityCode'] = '021'
    data['adCode'] = '310112'
    data['userNewId'] = '1200001571'
    data['rescueLng'] = '121.375231'
    data['rescueLat'] = '31.151427'

    data['orderId'] = '20191011101226171120000157176'
    data['bikeNo'] = '7600000021'
    data['phone'] = '10000000014'
    data['rescueType'] = 3
    data['rescueAddress'] = 'abc'
    data['rescueImages'] = ['physics', 'chemistry', "abc"]
    request_data = dict()
    print(json.dumps(data))
    request_data['arg0'] = json.dumps(data)
    request_json = json.dumps(request_data)
    return client.run(iface, 'createRescueOrder', request_json)


def queryRescueOrderList():
    data = dict()
    data['userNewId'] = '1200001571'
    data['pageIndex'] = 1
    data['pageSize'] = 10
    request_data = dict()
    print(json.dumps(data))
    request_data['arg0'] = json.dumps(data)
    request_json = json.dumps(request_data)
    return client.run(iface, 'queryRescueOrderList', request_json)


def cancelRescueOrder():
    data = dict()
    data['rescueOrderId'] = 1189467377910013954
    request_data = dict()
    print(json.dumps(data))
    request_data['arg0'] = json.dumps(data)
    request_json = json.dumps(request_data)
    return client.run(iface, 'cancelRescueOrder', request_json)


if __name__ == '__main__':
    res = createRescueOrder()
    print(jsonutil.dumps_pretty(res.data))
