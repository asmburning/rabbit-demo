from common.soa.clients import AppRentUserClient as uc
import json

iface = "com.hellobike.rent.user.iface.UserRemindIface"


def queryUserRemind(user_new_id):
    data = dict()
    data['userNewId'] = user_new_id
    request_data = dict()
    request_data['arg0'] = json.dumps(data)
    request_json = json.dumps(request_data)
    return uc.run(iface, "queryUserRemind", request_json)


def updateUserRemind(user_new_id, remindType, needRemind=True):
    data = dict()
    data['userNewId'] = user_new_id
    data['remindType'] = remindType
    data['needRemind'] = needRemind
    request_data = dict()
    request_data['arg0'] = json.dumps(data)
    request_json = json.dumps(request_data)
    return uc.run(iface, "updateUserRemind", request_json)
