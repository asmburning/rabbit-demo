from common.soa.clients import AppRentUserClient as uc
import json

iface = "com.hellobike.rent.user.iface.RentVerifyIface"

m_checkNeedVerify = "checkNeedVerify"
m_sendSmsVerifyCode = "sendSmsVerifyCode"
m_changeVerifyCapText = "changeVerifyCapText"
m_sendVoiceVerifyCode = "sendVoiceVerifyCode"
m_verifyMobile = "verifyMobile"
m_queryVerifiedMobile = "verifyMobile"
m_verifyMobile = "queryUserVerifyMobileEntity"


def check_need_verify(user_new_id, guid):
    data = dict()
    data['userNewId'] = user_new_id
    data['_uuid'] = guid
    request_data = dict()
    request_data['arg0'] = json.dumps(data)
    request_json = json.dumps(request_data)
    return uc.run(iface, m_checkNeedVerify, request_json)


def send_sms_verify_code(user_new_id, mobile):
    data = dict()
    data['userNewId'] = user_new_id
    data['mobile'] = mobile
    data['versionFlag'] = 'new'
    request_data = dict()
    request_data['arg0'] = json.dumps(data)
    request_json = json.dumps(request_data)
    return uc.run(iface, m_sendSmsVerifyCode, request_json)


def change_verify_cap_text(mobile):
    data = dict()
    data['mobile'] = mobile
    request_data = dict()
    request_data['arg0'] = json.dumps(data)
    request_json = json.dumps(request_data)
    return uc.run(iface, m_changeVerifyCapText, request_json)
