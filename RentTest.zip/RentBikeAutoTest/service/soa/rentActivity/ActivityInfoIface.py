from common.soa.clients import AppRentActivityClient as client
import json

iface = "com.hellobike.rent.ifaces.ActivityInfoIface"


def buyVoucherCallBack(params):
    data = dict()
    data['sellOrderId'] = params['sellOrderId']
    data['userNewId'] = params['userNewId']
    data['guid'] = params['voucherGuid']
    request_data = dict()
    request_data['arg0'] = json.dumps(data)
    request_json = json.dumps(request_data)
    return client.run(iface, 'buyVoucherCallBack', request_json)
