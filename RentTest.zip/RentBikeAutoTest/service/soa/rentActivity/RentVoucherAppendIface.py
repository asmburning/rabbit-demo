from common.soa.clients import AppRentActivityClient as client
import json

iface = "com.hellobike.rent.ifaces.RentVoucherAppendIface"


def testMq(params):
    data = dict()
    data['sellOrderId'] = params['sellOrderId']
    data['voucherGuid'] = params['voucherGuid']
    request_data = dict()
    print(json.dumps(data))
    request_data['arg0'] = json.dumps(data)
    request_json = json.dumps(request_data)
    return client.run(iface, 'testMq', request_json)
