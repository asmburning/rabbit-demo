from common.soa.clients import AppRentUserDataClient as client
import json

iface = "com.hellobike.rent.user.data.iface.BosOrderSupportIface"


def queryCityOrderIncomeAndExpenditure(cityCode, shopGuidList):
    request_data = dict()
    request_data['arg0'] = cityCode
    if shopGuidList is not None:
        request_data['arg1'] = json.dumps(shopGuidList)
    request_json = json.dumps(request_data)
    print("request_json", request_json)
    return client.run(iface, 'queryCityOrderIncomeAndExpenditure', request_json)


def queryCityOrderInfo(cityCode):
    arg0 = dict()
    arg0['cityCode'] = cityCode
    arg0['isContinue'] = 0
    request_data = dict()
    request_data['arg0'] = json.dumps(arg0)
    request_json = json.dumps(request_data)
    print("request_json", request_json)
    return client.run(iface, 'queryCityOrderInfo', request_json)
