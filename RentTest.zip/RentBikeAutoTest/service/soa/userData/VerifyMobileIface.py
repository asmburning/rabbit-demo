from common.soa.clients import AppRentUserDataClient as client
import json

iface = "com.hellobike.rent.user.data.iface.VerifyMobileIface"


def check_need_verify(user_new_id, mobile):
    arg0 = dict()
    arg0['userNewId'] = user_new_id
    arg1 = dict()
    arg1['mobile'] = mobile
    request_data = dict()
    request_data['arg0'] = json.dumps(arg0)
    request_data['arg1'] = json.dumps(arg1)
    request_json = json.dumps(request_data)
    return client.run(iface, 'checkNeedVerify', request_json)

