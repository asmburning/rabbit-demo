from common.soa.clients import AppRentBikeManagerClient as client
import json

iface = "com.hellobike.rentbike.manager.iface.RentDepotIface"

m_queryDepotByGuid = "queryDepotByGuid"

user = dict()
user['guid'] = '1234567'
user['userName'] = 'userName'
user['realName'] = 'realName'
user['email'] = '1234@bh.com'


def queryDepotByGuid(guid):

    data = dict()
    data['guid'] = guid
    request_data = dict()
    print(json.dumps(data))
    request_data['arg0'] = json.dumps(data)
    request_json = json.dumps(request_data)
    return client.run(iface, m_queryDepotByGuid, request_json)


queryDepotByGuid('12345')