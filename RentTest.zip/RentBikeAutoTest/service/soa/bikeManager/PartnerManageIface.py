from common.soa.clients import AppRentBikeManagerClient as client
import json

iface = "com.hellobike.rentbike.manager.iface.PartnerManageIface"

m_addPartner = "addPartner"
m_editPartner = "editPartner"
m_queryPartner = "queryPartner"
m_queryPartnerList = "queryPartnerList"
m_queryPartnerPage = "queryPartnerPage"
m_partnerNameAvailable = "partnerNameAvailable"

user = dict()
user['guid'] = '1234567'
user['userName'] = 'userName'
user['realName'] = 'realName'
user['email'] = '1234@bh.com'


def add_partner(partner_name):

    data = dict()
    data['_user'] = user
    data['cityCode'] = '021'
    data['cityName'] = 'ShangHai'
    data['partnerStatus'] = '1'
    data['partnerName'] = partner_name
    data['partnerAddress'] = "address"
    data['contactName'] = '联系人名称'
    data['contactIdNo'] = '22222222'
    data['mobileList'] = '17602107305,9702107408'
    data['contractStartTime'] = '2018-11-20'
    data['contractEndTime'] = '2018-11-30'
    data['operatorName'] = 'operatorName'
    data['remark'] = 'remark'
    request_data = dict()
    print(json.dumps(data))
    request_data['arg0'] = json.dumps(data)
    request_json = json.dumps(request_data)
    return client.run(iface, m_addPartner, request_json)


def edit_partner(guid, partner_name):
    data = dict()
    data['_user'] = user
    data['guid'] = guid
    data['cityCode'] = '021'
    data['cityName'] = 'ShangHai'
    data['partnerStatus'] = 1
    data['partnerName'] = partner_name
    data['partnerAddress'] = "address"
    data['contactName'] = '联系人名称'
    data['contactIdNo'] = '22222222'
    data['mobileList'] = '17602107305,19702107408'
    data['contractStartTime'] = '2018-11-20'
    # data['contractEndTime'] = '2018-11-30'
    data['operatorName'] = 'operatorName'
    data['remark'] = 'remark'
    request_data = dict()
    request_data['arg0'] = json.dumps(data)
    request_json = json.dumps(request_data)
    return client.run(iface, m_editPartner, request_json)


def query_partner(guid, partnerName):
    data = dict()
    data['guid'] = guid
    data['partnerName'] = partnerName
    request_data = dict()
    request_data['arg0'] = json.dumps(data)
    request_json = json.dumps(request_data)
    return client.run(iface, m_queryPartner, request_json)


def query_partner_list(cityCode, partnerName):
    data = dict()
    data['cityCode'] = cityCode
    data['partnerName'] = partnerName
    request_data = dict()
    request_data['arg0'] = json.dumps(data)
    request_json = json.dumps(request_data)
    return client.run(iface, m_queryPartnerList, request_json)


def partner_name_available(guid, partnerName):
    data = dict()
    data['guid'] = guid
    data['partnerName'] = partnerName
    request_data = dict()
    request_data['arg0'] = json.dumps(data)
    request_json = json.dumps(request_data)
    return client.run(iface, m_partnerNameAvailable, request_json)


def query_partner_page(cityCode, partnerName):
    data = dict()
    data['pageIndex'] = '1'
    data['pageSize'] = '2'
    data['cityCode'] = cityCode
    data['partnerName'] = partnerName
    request_data = dict()
    request_data['arg0'] = json.dumps(data)
    request_json = json.dumps(request_data)
    return client.run(iface, m_queryPartnerPage, request_json)
