from common.soa.clients import AppRentBikeManagerClient as client
import json

iface = "com.hellobike.rentbike.manager.iface.CityManagerIface"

m_queryCityCollectCost = "queryCityCollectCost"

user = dict()
user['guid'] = '1234567'
user['userName'] = 'userName'
user['realName'] = 'realName'
user['email'] = '1234@bh.com'


def queryCityCollectCost(cityCode, cityCodeWithAdCode):
    data = dict()
    data['cityCode'] = cityCode
    data['cityCodeWithAdCode'] = cityCodeWithAdCode
    request_data = dict()
    print(json.dumps(data))
    request_data['arg0'] = json.dumps(data)
    request_json = json.dumps(request_data)
    return client.run(iface, m_queryCityCollectCost, request_json)

