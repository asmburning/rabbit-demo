from common.soa.clients import UpoClient as client
import json
from common.util import jsonutil

iface = "com.hellobike.rent.upo.iface.HomePageIface"


def nearSpot():
    data = dict()
    data['cityCode'] = '021'
    data['adCode'] = '310112'
    data['lng'] = '121.369400'
    data['lat'] = '31.130550'
    data['apiVersion'] = '1.30.0'
    data['modelId'] = '1030391482648797185'
    request_data = dict()
    print(json.dumps(data))
    request_data['arg0'] = json.dumps(data)
    request_json = json.dumps(request_data)
    return client.run(iface, 'nearSpot', request_json)


def queryNearSpotInfo():
    data = dict()
    data['cityCode'] = '021'
    data['adCode'] = '310112'
    data['apiVersion'] = '1.30.0'

    data['pointType'] = 0
    data['spotId'] = "1062595621325000705"

    request_data = dict()
    print(json.dumps(data))
    request_data['arg0'] = json.dumps(data)
    request_json = json.dumps(request_data)
    return client.run(iface, 'queryNearSpotInfo', request_json)


if __name__ == '__main__':
    res = queryNearSpotInfo()
    print(jsonutil.dumps_pretty(res.data))
