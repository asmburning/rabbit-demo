from common.soa.clients import AppRentOrderClient as client
import json

iface = "com.hellobike.rent.order.iface.OrderJobIface"


def executeInsurePostProcess(timeout):
    request_data = dict()
    request_data['arg0'] = timeout
    request_json = json.dumps(request_data)
    return client.run(iface, 'executeInsurePostProcess', request_json)

