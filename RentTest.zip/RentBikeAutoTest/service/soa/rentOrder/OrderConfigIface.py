from common.soa.clients import AppRentOrderClient as client
import json

iface = "com.hellobike.rent.order.iface.OrderConfigIface"


def query_cert_info_unmask(_uuid):
    data = dict()
    data['_uuid'] = _uuid
    request_data = dict()
    request_data['arg0'] = json.dumps(data)
    request_json = json.dumps(request_data)
    return client.run(iface, 'queryCertInfoUnmask', request_json)


def calculateDeliveryPrice(params):
    request_data = dict()
    request_data['arg0'] = json.dumps(params)
    request_json = json.dumps(request_data)
    return client.run(iface, 'calculateDeliveryPrice', request_json)


def calculateCollectPrice(params):
    request_data = dict()
    request_data['arg0'] = json.dumps(params)
    request_json = json.dumps(request_data)
    return client.run(iface, 'calculateCollectPrice', request_json)


def viewCanRent(params):
    request_data = dict()
    request_data['arg0'] = json.dumps(params)
    request_json = json.dumps(request_data)
    return client.run(iface, 'viewCanRent', request_json)
