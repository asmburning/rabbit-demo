from common.soa.clients import AppRentOrderClient as client
import json

iface = "com.hellobike.rent.order.iface.OrderCommonIface"


def update_verify_mobile(user_new_id, mobile):
    data = dict()
    data['userNewId'] = user_new_id
    data['mobile'] = mobile
    request_data = dict()
    request_data['arg0'] = json.dumps(data)
    request_json = json.dumps(request_data)
    return client.run(iface, 'updateVerifyMobile', request_json)


def getOrderInfo(orderId):
    data = dict()
    data['orderId'] = orderId
    request_data = dict()
    request_data['arg0'] = json.dumps(data)
    request_json = json.dumps(request_data)
    return client.run(iface, 'getOrderInfo', request_json)
