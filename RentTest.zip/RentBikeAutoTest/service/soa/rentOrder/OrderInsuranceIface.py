from common.soa.clients import AppRentOrderClient as client
import json

iface = "com.hellobike.rent.order.iface.OrderInsuranceIface"


def manualInsure(orderGuid):
    data = dict()
    data['orderGuid'] = orderGuid
    request_data = dict()
    request_data['arg0'] = json.dumps(data)
    request_json = json.dumps(request_data)
    return client.run(iface, 'manualInsure', request_json)


def reInsure(orderId):
    data = dict()
    data['orderId'] = orderId
    request_data = dict()
    request_data['arg0'] = json.dumps(data)
    request_json = json.dumps(request_data)
    return client.run(iface, 'reInsure', request_json)
