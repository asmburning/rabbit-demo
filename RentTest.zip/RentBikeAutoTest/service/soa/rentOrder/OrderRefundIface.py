from common.soa.clients import AppRentOrderClient as client
import json

iface = "com.hellobike.rent.order.iface.OrderRefundIface"


def queryRefundReason():
    request_data = dict()
    request_json = json.dumps(request_data)
    return client.run(iface, 'queryRefundReason', request_json)


def queryRefundInfo(orderId):
    request_data = dict()
    arg0 = dict()
    arg0['orderId'] = orderId
    request_data['arg0'] = json.dumps(arg0)
    request_json = json.dumps(request_data)
    return client.run(iface, 'queryRefundInfo', request_json)


def billRefund(arg0):
    request_data = dict()
    request_data['arg0'] = json.dumps(arg0)
    request_json = json.dumps(request_data)
    return client.run(iface, 'billRefund', request_json)
