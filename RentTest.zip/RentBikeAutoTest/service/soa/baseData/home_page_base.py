from common.soa.clients import AppRentBaseDataClient as client
import json
from common.util import jsonutil

iface = "com.hellobike.rent.base.data.iface.HomepageConfigureIface"


def queryUserHomepageModelList():
    arg0 = dict()
    arg0['cityCode'] = "021"
    request_data = dict()
    request_data['arg0'] = json.dumps(arg0)
    request_json = json.dumps(request_data)
    result = client.run(iface, 'queryUserHomepageModelList', request_json)
    print(jsonutil.dumps_pretty(result['data']['model']['annualModelList']))


if __name__ == '__main__':
    queryUserHomepageModelList()
