from common.soa.clients import AppRentBaseDataClient as client
import json

iface = "com.hellobike.rent.base.data.iface.StoreIface"

user = dict()
user['guid'] = '1234567'
user['userName'] = 'userName'
user['realName'] = 'realName'
user['email'] = '1234@bh.com'


def nearStorePositionInfoByStoreId():
    data = dict()
    data['storeId'] = 20181227
    request_data = dict()
    print(json.dumps(data))
    request_data['arg0'] = json.dumps(data)
    request_json = json.dumps(request_data)
    return client.run(iface, 'nearStorePositionInfoByStoreId', request_json)


if __name__ == '__main__':
    nearStorePositionInfoByStoreId()
