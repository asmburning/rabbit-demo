from common.soa.clients import AppRentBaseDataClient as client
import json
from common.util import jsonutil

iface = "com.hellobike.rent.base.data.iface.manager.CityManagerIface"


def getCityConfig(cityCode):
    arg0 = dict()
    arg0['cityCode'] = cityCode
    request_data = dict()
    request_data['arg0'] = json.dumps(arg0)
    request_json = json.dumps(request_data)
    return client.run(iface, 'getCityConfigureDetail', request_json)


def setCityConfig():
    data = '''{"businessTypes": [1, 0], "openCityTime": "2019-09-04T00:00:00", "cityCode": "021", "cityType": 1, "riskMode": 1,
     "huabeiFront": true, "displayMode": "CITY", "deductModeZmScore": 350, "cityName": "上海市", "configureDatas": [
        {"businessType": 0, "serviceTypes": [0, 1], "models": [
            {"modelId": "1064444756925825026", "switchPower": 0, "modelName": "非换电-123213213", "specs": [
                {"specName": "4324", "specId": "1064444757001322497", "productionCost": 234324, "unifiedPrice": 324324,
                 "actualPrice": 2, "downPayment": 6, "lowDownPayment": 1,
                 "instalmentInfo": [{"monthlyPay": 6, "terms": 6}, {"monthlyPay": 6, "terms": 12}],
                 "highRatioInstalmentInfo": [{"monthlyPay": 1, "terms": 6}, {"monthlyPay": 1, "terms": 12}],
                 "fullPayTag": "2", "monthlyPay12": 6, "monthlyPay6": 6, "lowMonthlyPay12": 1, "lowMonthlyPay6": 1,
                 "modelName": "123213213", "modelId": "1064444756925825026", "businessType": 0, "rowSpan": 1,
                 "prices": []}]}, {"modelId": "1143459358994857985", "switchPower": 0, "modelName": "非换电-造数据测试车型",
                                   "specs": [
                                       {"specName": "造数据测试规格", "specId": "1143459359015829506", "productionCost": 123,
                                        "unifiedPrice": 0.1, "actualPrice": 10000, "downPayment": 10,
                                        "instalmentInfo": [{"monthlyPay": 100, "terms": 6},
                                                           {"monthlyPay": 10, "terms": 12}],
                                        "highRatioInstalmentInfo": [{"monthlyPay": "", "terms": 6},
                                                                    {"monthlyPay": "", "terms": 12}], "fullPayTag": "",
                                        "lowDownPayment": "", "monthlyPay12": 10, "monthlyPay6": 100,
                                        "lowMonthlyPay12": "", "lowMonthlyPay6": "", "modelName": "造数据测试车型",
                                        "modelId": "1143459358994857985", "businessType": 0, "rowSpan": 1,
                                        "prices": []}]}]}, {"businessType": 1, "serviceTypes": [1, 0], "models": [
            {"modelId": "1030391482648797185", "switchPower": 0, "modelName": "非换电-非换电欧尚电动车", "specs": [
                {"specName": "黑白色", "specId": "1049978425084125185", "productionCost": 2800, "unifiedPrice": 3000,
                 "prices": [{"tenancy": "2", "rental": 0.1, "isActivity": 1, "activityLabel": "",
                             "continueActivityLabel": ""}], "instalmentInfo": [], "highRatioInstalmentInfo": [],
                 "modelName": "非换电欧尚电动车", "modelId": "1030391482648797185", "businessType": 1, "rowSpan": 3},
                {"specName": "天蓝色", "specId": "1055011631278714881", "productionCost": 22, "unifiedPrice": 22,
                 "prices": [{"tenancy": "2", "rental": 0.1, "isActivity": 1, "activityLabel": "",
                             "continueActivityLabel": ""}], "instalmentInfo": [], "highRatioInstalmentInfo": [],
                 "modelName": "非换电欧尚电动车", "modelId": "1030391482648797185", "businessType": 1, "rowSpan": 0},
                {"specName": "白色", "specId": "1030391483814813698", "productionCost": 3000, "unifiedPrice": 3000,
                 "prices": [{"tenancy": "2", "rental": 0.1, "isActivity": 1, "activityLabel": "",
                             "continueActivityLabel": ""}], "instalmentInfo": [], "highRatioInstalmentInfo": [],
                 "modelName": "非换电欧尚电动车", "modelId": "1030391482648797185", "businessType": 1, "rowSpan": 0}]},
            {"modelId": "1143459358994857985", "switchPower": 0, "modelName": "非换电-造数据测试车型", "specs": [
                {"specName": "造数据测试规格2", "specId": "1171669602766012417", "productionCost": 123, "unifiedPrice": 0.1,
                 "prices": [
                     {"tenancy": "3", "rental": 8, "isActivity": 1, "activityLabel": "", "continueActivityLabel": ""},
                     {"tenancy": "4", "rental": 6, "isActivity": 0, "giftDays": 1, "activityLabel": "1111",
                      "continueActivityLabel": ""}], "instalmentInfo": [], "highRatioInstalmentInfo": [],
                 "modelName": "造数据测试车型", "modelId": "1143459358994857985", "businessType": 1, "rowSpan": 2},
                {"specName": "造数据测试规格", "specId": "1143459359015829506", "productionCost": 123, "unifiedPrice": 0.1,
                 "prices": [{"tenancy": "3", "rental": 0.02, "isActivity": 1, "activityLabel": "",
                             "continueActivityLabel": ""},
                            {"tenancy": "4", "rental": 6, "isActivity": 1, "activityLabel": "333",
                             "continueActivityLabel": ""},
                            {"tenancy": "2", "rental": 0.01, "isActivity": 1, "activityLabel": "",
                             "continueActivityLabel": ""}], "instalmentInfo": [], "highRatioInstalmentInfo": [],
                 "modelName": "造数据测试车型", "modelId": "1143459358994857985", "businessType": 1, "rowSpan": 0}]},
            {"modelId": "1045550519626989570", "switchPower": 1, "modelName": "换电-测试车型1", "specs": [
                {"specName": "黑色", "specId": "1045550519685709825", "productionCost": 3000, "unifiedPrice": 3000,
                 "prices": [
                     {"tenancy": "3", "rental": 8, "isActivity": 1, "activityLabel": "", "continueActivityLabel": ""},
                     {"tenancy": "2", "rental": 12, "isActivity": 1, "activityLabel": "", "continueActivityLabel": ""}],
                 "instalmentInfo": [], "highRatioInstalmentInfo": [], "modelName": "测试车型1",
                 "modelId": "1045550519626989570", "businessType": 1, "rowSpan": 2},
                {"specName": "白色", "specId": "1045550519673126913", "productionCost": 3000, "unifiedPrice": 3000,
                 "prices": [
                     {"tenancy": "2", "rental": 12, "isActivity": 1, "activityLabel": "", "continueActivityLabel": ""},
                     {"tenancy": "3", "rental": 8, "isActivity": 1, "activityLabel": "", "continueActivityLabel": ""}],
                 "instalmentInfo": [], "highRatioInstalmentInfo": [], "modelName": "测试车型1",
                 "modelId": "1045550519626989570", "businessType": 1, "rowSpan": 0}]}]}], "depositAmount": 1,
     "collectCostPerKm": 1, "switchPowerPlanList": [
        {"planList": [{"id": "34e72a7f126b49268576bde35a2f220f", "times": 12, "price": 0.1, "effectiveDays": 365}],
         "modelId": "1030391482648797107", "specId": "1129340029552222210", "orderType": 0, "tenacy": 1,
         "guid": "1149506144016629761"},
        {"planList": [{"id": "34e72a7f126b49268576bde35a2f220f", "times": 12, "price": 0.1, "effectiveDays": 365}],
         "modelId": "1030391482648797107", "specId": "1129340029552222210", "orderType": 0, "tenacy": 6,
         "guid": "1149506144016629762"},
        {"planList": [{"id": "34e72a7f126b49268576bde35a2f220f", "times": 12, "price": 0.1, "effectiveDays": 365}],
         "modelId": "1030391482648797107", "specId": "1129340029552222210", "orderType": 0, "tenacy": 12,
         "guid": "1149506144016629763"},
        {"planList": [{"id": "34e72a7f126b49268576bde35a2f220f", "times": 12, "price": 0.1, "effectiveDays": 365}],
         "modelId": "1030391482648797185", "modelName": "非换电欧尚电动车", "specId": "1030391483814813698", "specName": "白色",
         "orderType": 0, "tenacy": 12, "guid": "1139371082377945096"},
        {"planList": [{"id": "34e72a7f126b49268576bde35a2f220f", "times": 12, "price": 0.1, "effectiveDays": 365}],
         "modelId": "1030391482648797185", "modelName": "非换电欧尚电动车", "specId": "1030391483814813698", "specName": "白色",
         "orderType": 0, "tenacy": 6, "guid": "1139371082377945095"},
        {"planList": [{"id": "92a9626ee5e64ef882a18ed162aa6ae4", "times": -1, "price": 2}],
         "modelId": "1030391482648797185", "modelName": "非换电欧尚电动车", "specId": "1030391483600904194", "orderType": 2,
         "tenacy": 7, "guid": "1154625829120409602"}, {
            "planList": [{"id": "92a9626ee5e64ef882a18ed162aa6ae4", "times": -1, "price": 2},
                         {"id": "29524e03e36c47258aaa9343f584b3f7", "times": 222, "price": 3}],
            "modelId": "1030391482648797185", "modelName": "非换电欧尚电动车", "specId": "1030391483814813698",
            "specName": "白色", "orderType": 2, "tenacy": 7, "guid": "1154625829120409603"},
        {"planList": [{"id": "34e72a7f126b49268576bde35a2f220f", "times": 12, "price": 0.1, "effectiveDays": 365}],
         "modelId": "6785468c8d3b47fe9da3d787b7af4bb2", "specId": "1030391483600904194", "orderType": 0, "tenacy": 6,
         "guid": "1165891152486690818"},
        {"planList": [{"id": "34e72a7f126b49268576bde35a2f220f", "times": 12, "price": 0.1, "effectiveDays": 365}],
         "modelId": "6785468c8d3b47fe9da3d787b7af4bb2", "specId": "1030391483600904194", "orderType": 0, "tenacy": 12,
         "guid": "1165891152486690819"},
        {"planList": [{"id": "58036c42796c4d0fb283b20cb014bd34", "times": -1, "price": 0.1, "effectiveDays": 60}],
         "modelId": "1030391482648797185", "modelName": "非换电欧尚电动车", "specId": "1030391483600904194", "orderType": 1,
         "tenacy": 2, "guid": "1139371082377945090"},
        {"planList": [{"id": "d63e62162de34b8b8d1f6cea4a24bada", "times": 20, "price": 0.1, "effectiveDays": 30}],
         "modelId": "1143459358994857985", "modelName": "造数据测试车型", "specId": "1143459359015829506",
         "specName": "造数据测试规格", "orderType": 1, "tenacy": 1, "guid": "1143481058063114242"},
        {"planList": [{"id": "d63e62162de34b8b8d1f6cea4a24bada", "times": 20, "price": 0.1, "effectiveDays": 30}],
         "modelId": "1030391482648797185", "modelName": "非换电欧尚电动车", "specId": "1030391483600904194", "orderType": 1,
         "tenacy": 1, "guid": "1139371082377945091"},
        {"planList": [{"id": "d63e62162de34b8b8d1f6cea4a24bada", "times": 20, "price": 0.1, "effectiveDays": 30}],
         "modelId": "1045550519626989570", "modelName": "测试车型1", "specId": "1045550519673126913", "specName": "白色",
         "orderType": 1, "tenacy": 1, "guid": "1139371082377945093"},
        {"planList": [{"id": "34e72a7f126b49268576bde35a2f220f", "times": 12, "price": 0.1, "effectiveDays": 365}],
         "modelId": "6785468c8d3b47fe9da3d787b7af4bb2", "specId": "1030391483600904194", "orderType": 0, "tenacy": 1,
         "guid": "1165891152486690817"},
        {"planList": [{"id": "a577d8ebff624194a18cf3b74d6176e9", "times": 12, "price": 0.1, "effectiveDays": 90}],
         "modelId": "1045550519626989570", "modelName": "测试车型1", "specId": "1045550519685709825", "specName": "黑色",
         "orderType": 1, "tenacy": 3, "guid": "1171249267356741637"},
        {"planList": [{"id": "34e72a7f126b49268576bde35a2f220f", "times": 12, "price": 0.1, "effectiveDays": 365}],
         "modelId": "1030391482648797185", "modelName": "非换电欧尚电动车", "specId": "1030391483814813698", "specName": "白色",
         "orderType": 0, "tenacy": 1, "guid": "1139371082377945094"},
        {"planList": [{"id": "d63e62162de34b8b8d1f6cea4a24bada", "times": 20, "price": 0.1, "effectiveDays": 30}],
         "modelId": "1030391482648797185", "modelName": "非换电欧尚电动车", "specId": "1030391483814813698", "specName": "白色",
         "orderType": 1, "tenacy": 1, "guid": "1139371082377945092"},
        {"planList": [{"id": "d63e62162de34b8b8d1f6cea4a24bada", "times": 20, "price": 0.1, "effectiveDays": 30}],
         "modelId": "1030391482648797107", "specId": "1129340029552222210", "orderType": 1, "tenacy": 1,
         "guid": "1159706863323312130"},
        {"planList": [{"id": "58036c42796c4d0fb283b20cb014bd34", "times": -1, "price": 0.1, "effectiveDays": 60}],
         "modelId": "1045550519626989570", "modelName": "测试车型1", "specId": "1045550519673126913", "specName": "白色",
         "orderType": 1, "tenacy": 2, "guid": "1171249267356741634"},
        {"planList": [{"id": "a577d8ebff624194a18cf3b74d6176e9", "times": 12, "price": 0.1, "effectiveDays": 90}],
         "modelId": "1045550519626989570", "modelName": "测试车型1", "specId": "1045550519673126913", "specName": "白色",
         "orderType": 1, "tenacy": 3, "guid": "1171249267356741635"},
        {"planList": [{"id": "58036c42796c4d0fb283b20cb014bd34", "times": -1, "price": 0.1, "effectiveDays": 60}],
         "modelId": "1045550519626989570", "modelName": "测试车型1", "specId": "1045550519685709825", "specName": "黑色",
         "orderType": 1, "tenacy": 2, "guid": "1171249267356741636"}], "citySpotReturnOpen": false,
     "lowDownPaymentOpened": false, "lowDownPaymentZmScore": 600, "nationalStandardSoundOpened": true,
     "__sysTag": "dev"}'''
    dataDic = json.loads(data, encoding="utf-8")

    request_data = dict()
    request_data['arg0'] = dataDic
    request_json = json.dumps(request_data, ensure_ascii=False)
    print(jsonutil.dumps_pretty(request_data, True))
    # return client.run(iface, 'setCityConfigureDetail', request_json)


if __name__ == '__main__':
    setCityConfig()
