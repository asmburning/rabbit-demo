from common.soa.clients import AppRentFinanceClient as client
import json

iface = "com.easybike.rent.finance.iface.TestIface"


def sendWeChatMessage(chargeGuid):
    request_data = dict()
    request_data['arg0'] = chargeGuid
    request_json = json.dumps(request_data)
    return client.run(iface, 'sendWeChatMessage', request_json)


def sendWeChatMq(chargeGuid):
    request_data = dict()
    request_data['arg0'] = chargeGuid
    request_json = json.dumps(request_data)
    return client.run(iface, 'sendWeChatMq', request_json)
