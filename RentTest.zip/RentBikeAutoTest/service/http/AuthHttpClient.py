import requests
import json
from common import GlobalDomain

smsType = 'loginCode'
sendCode = '1234'


def send_sms_code(mobile, env):
    r = requests.post('http://47.98.110.181:8099/tool/sendSms',
                      data={
                          'env': env,
                          'smsType': smsType,
                          'mobilePhone': mobile,
                          'sendCode': sendCode
                      })
    # print(str(r.status_code))


def one_step_login(mobile, env):
    send_sms_code(mobile, env)
    data = {
        "action": "user.account.login",
        "version": "4.24.0",
        "hasForce": False,
        "token": '',
        "adCode": "310112",
        "city": "上海市",
        "cityCode": "021",
        "clientId": "01201620009171428860",
        "code": sendCode,
        "mobile": mobile,
        "systemCode": "62"
    }
    res = requests.post(GlobalDomain.getAuthDomain(env), json=data)
    # print(200 == res.status_code)
    return res.text


def one_step_get_token(mobile, env):
    loginRes = one_step_login(mobile, env)
    loginJosn = json.loads(loginRes)
    return loginJosn['data']['token']
