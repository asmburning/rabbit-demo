import requests
import json
from common import GlobalDomain
from service.http import AuthHttpClient


def one_step_get_token(mobile, env):
    loginRes = AuthHttpClient.one_step_login(mobile, env)
    loginJosn = json.loads(loginRes)
    token = loginJosn['data']['token']
    common_dict = dict()
    common_dict['mobile'] = mobile
    common_dict['token'] = token
    return common_dict


def do_request_api(data, env):
    res = requests.post(GlobalDomain.getApiDomain(env), json=data)
    # print(200 == res.status_code)
    return json.loads(res.text)


def check_need_verify(param, env):
    data = {
        "token": param['token'],
        "action": "rent.user.checkNeedVerify"
    }
    return do_request_api(data, env)


def send_sms_verify_code(param, env):
    data = {
        "token": param['token'],
        "action": "rent.user.sendSmsVerifyCode",
        "mobile": param['mobile'],
        "versionFlag": "new"
    }
    return do_request_api(data, env)


def verifyMobile(param, env):
    data = {
        "token": param['token'],
        "action": "rent.user.verifyMobile",
        "newMobile": param['newMobile'],
        "capText": param['capText'],
        "code": param['verifyCode']
    }
    return do_request_api(data, env)
