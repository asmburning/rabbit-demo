#!/usr/bin/env python
# encoding: utf-8
# Created by liuxinyi at 2019-05-29

from elasticsearch import Elasticsearch

if __name__ == '__main__':
    esclient = Elasticsearch(['localhost:9200'])
    response = esclient.search(
        index='social-*',
        body={
            "query": {
                "match": {
                    "message": "myProduct"
                }
            },
            "aggs": {
                "top_10_states": {
                    "terms": {
                        "field": "state",
                        "size": 10
                    }
                }
            }
        }
    )
    print(response)
