devDomains = ['https://easybike.cheyaoshi.com/auth',
              'https://test-rapi.hellobike.com/api',
              'http://test.radmin.ttbike.com.cn/']
fatDomains = ['https://fat.api.ttbike.com.cn/auth',
              'https://fat-rapi.hellobike.com/api',
              'http://fat.radmin.ttbike.com.cn/']
uatDomains = ['https://uat.api.ttbike.com.cn/auth',
              'https://uat-rapi.hellobike.com/api',
              'http://uat.radmin.ttbike.com.cn/']


def getAuthDomain(evn):
    if evn == 'dev':
        return devDomains[0]
    elif evn == 'fat':
        return fatDomains[0]
    elif evn == 'uat':
        return uatDomains[0]
    return ''


def getApiDomain(evn):
    if evn == 'dev':
        return devDomains[1]
    elif evn == 'fat':
        return fatDomains[1]
    elif evn == 'uat':
        return uatDomains[1]
    return ''


def getAdminDomain(evn):
    if evn == 'dev':
        return devDomains[2]
    elif evn == 'fat':
        return fatDomains[2]
    elif evn == 'uat':
        return uatDomains[2]
    return ''


# print(getAuthDomain('dev'))
# print(getApiDomain('fat'))
# print(getAdminDomain('uat'))
