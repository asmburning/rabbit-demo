from rediscluster import StrictRedisCluster

dev_nodes = [
    {'host': '10.111.70.51', 'port': 8461},
    {'host': '10.111.70.52', 'port': 8461},
    {'host': '10.111.70.53', 'port': 8461}
]

fat_nodes = [
    {'host': '47.99.121.190', 'port': 8525}
]

uat_nodes = [
    {'host': '10.111.40.141', 'port': 8525},
    {'host': '10.111.40.142', 'port': 8525},
    {'host': '10.111.40.140', 'port': 8525}
]


def init_client(env):
    try:
        client = None
        if 'dev' == env:
            client = StrictRedisCluster(startup_nodes=dev_nodes, max_connections=10, socket_connect_timeout=3,
                                        socket_timeout=3)
        if 'fat' == env:
            client = StrictRedisCluster(startup_nodes=fat_nodes, max_connections=10, socket_connect_timeout=3,
                                        socket_timeout=3)
        if 'uat' == env:
            client = StrictRedisCluster(startup_nodes=uat_nodes, max_connections=10, socket_connect_timeout=3,
                                        socket_timeout=3)
        if client is not None:
            return client
        print('connect redis failed', env)
        exit(0)
    except Exception as e:
        print(e)


if __name__ == '__main__':
    redisClient = init_client('fat')
    if redisClient is None:
        exit(0)
    redisClient.set("test", "test")
    print(redisClient.get("test"))
