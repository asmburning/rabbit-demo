from common.cache import RedisConnection


def increaseStock(env, spec_id):
    conn = RedisConnection.init_client(env)
    key = 'rent:console:stock_count:spec_id:' + spec_id
    conn.incr(key, 10)
    print(conn.get(key))


def scan(env, pattern, count=1000):
    print('scan', env, pattern)
    conn = RedisConnection.init_client(env)
    print('connect success')
    scan = conn.scan(match=pattern, count=count)
    print(scan)
