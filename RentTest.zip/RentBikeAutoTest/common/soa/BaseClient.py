from __future__ import print_function
from common.soa.SoaResult import *
import grpc
from common.soa import soa_invoke_pb2_grpc
from common.soa import soa_invoke_pb2
from common.util import jsonutil


def run(host, iface, method, requestJson):
    try:
        channel = grpc.insecure_channel(host)
        stub = soa_invoke_pb2_grpc.SoaInvokerServiceStub(channel)

        soa_params = dict()
        soa_params['reqId'] = '1'
        soa_params['rpcId'] = '1'
        soa_params['iface'] = iface
        soa_params['method'] = method
        soa_params['requestJson'] = requestJson
        request = soa_invoke_pb2.SoaInvokerRequest(**soa_params)

        response = stub.call(request)
        print(response)
        if 200 == response.code:
            return jsonutil.loads(response.resultJson)
        else:
            # print("Exception", str(response))
            return SoaResult(False, "CODE IS NOT 200", "{}")
    except IOError:
        print("IOError", IOError)
        return SoaResult(False, "IO ERROR", "{}")
