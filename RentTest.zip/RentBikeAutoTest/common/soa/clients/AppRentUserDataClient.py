from common.soa import BaseClient

host = "127.0.0.1:40078"
host = "10.111.75.230:40078"


def run(iface, method, requestJson):
    return BaseClient.run(host, iface, method, requestJson)
