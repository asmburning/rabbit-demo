from common.soa import BaseClient

host = "127.0.0.1:40090"


def run(iface, method, requestJson):
    return BaseClient.run(host, iface, method, requestJson)
