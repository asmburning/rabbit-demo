#!/usr/bin/env python3

# -*- encoding: utf-8 -*-

'''
soa结果
@Author : lxy

'''

import json


class SoaResult:
    def __init__(self, success, message, data):
        self.success = success
        self.message = message
        self.data = json.loads(data)

