#!/usr/bin/python
import psycopg2

dev = ['47.98.106.34', '3560', 'power_rent', 'power_rent', 'power_rent']
fat = ['10.111.10.63', '3560', 'power_rent', 'power_rent_rw', 'power_rent_rw']
uat = ['10.111.50.54', '3560', 'power_rent', 'power_rent_rw', 'power_rent_rw']

dbInfos = dict()
dbInfos['dev'] = dev
dbInfos['fat'] = fat
dbInfos['uat'] = uat


def getConnection(env):
    dbInfo = dbInfos[env]
    # psycopg2.connect("dbname=test user=postgres password=secret")
    return psycopg2.connect(host=dbInfo[0], port=dbInfo[1], database=dbInfo[2], user=dbInfo[3], password=dbInfo[4])


if __name__ == '__main__':
    print(getConnection('dev'))
