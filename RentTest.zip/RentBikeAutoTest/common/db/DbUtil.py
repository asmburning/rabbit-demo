from common.db import DbConnection


def createBike(env, bikeInfo):
    conn = DbConnection.getConnection(env)
    cur = conn.cursor()
    sql = ''' INSERT INTO t_rent_bike
            ("guid", "bike_no", "batch_no", "frame_no", "plate_no", "battery_no", 
            "city_guid", "city_code", "city_name", "model_guid", "spec_guid", "is_new_bike", 
            "physical_status", "position_status", "rent_status", "create_time" , "update_time" ) 
            VALUES 
            (%s, %s, %s, %s, %s, %s, 
            %s, %s, %s, %s, %s, 0, 
            0, 2, 1, now() , now() ) '''
    cur.execute(sql, bikeInfo)
    conn.commit()
    conn.close()

