import json


def dumps_pretty(obj, sort_keys=False):
    return json.dumps(obj, indent=4, separators=(',', ':'), ensure_ascii=False, sort_keys=sort_keys)


def loads(data):
    return json.loads(data, encoding="utf-8")


def dumps(obj):
    return json.dumps(obj, indent=4, separators=(',', ':'), ensure_ascii=False)
