#!/usr/bin/env python
# encoding: utf-8
# Created by liuxinyi at 2019-03-15
import os

if __name__ == '__main__':
    # for parent, dirnames, filenames in os.walk("/Users/liuxinyi/Documents/code/spaceX"):
    #     for dir in dirnames:
    #         print(dir)
    for dir in os.listdir("/Users/liuxinyi/Documents/code/spaceX"):
        print(dir)
