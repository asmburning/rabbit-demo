#!/usr/bin/env python
# encoding: utf-8
# Created by liuxinyi at 2019-03-15
import sys

baseDir = '/Users/liuxinyi/Documents/code/spaceX/'

ifaces = ['<rentUserApiIface.version>', '<rentUserDataIface.version>', '<rentAdminApiIface.version>',
          '<rentBaseDataIface.version>', '<rentUserServiceIface.version>', '<rentOrderServiceIface.version>',
          '<rentBikeManagerIface.version>', '<rentFinanceIface.version>', '<rentActivityIface.version>'
          ]


def updateIfacePom(file, fromVersion, toVersion):
    print(file)
    file_data = ""
    oldVersion = "<version>" + fromVersion
    newVersion = "<version>" + toVersion
    changed = False
    with open(file, "r", encoding="utf-8") as f:
        i = 0
        for line in f:
            i = i + 1
            if i < 20 and oldVersion in line:
                print(i)
                changed = True
                line = line.replace(oldVersion, newVersion)
            file_data += line
    if changed:
        with open(file, "w", encoding="utf-8") as f:
            f.write(file_data)
    print()
    print()


def updateServicePom(file, fromVersion, toVersion):
    print(file)
    file_data = ""
    changed = False
    with open(file, "r", encoding="utf-8") as f:
        i = 0
        for line in f:
            i = i + 1
            if i < 100:
                for iface in ifaces:
                    oldVersion = iface + fromVersion
                    if oldVersion in line:
                        print(i)
                        newVersion = iface + toVersion
                        changed = True
                        line = line.replace(oldVersion, newVersion)
            file_data += line
    if changed:
        with open(file, "w", encoding="utf-8") as f:
            f.write(file_data)
    print()
    print()


def updateUserApi(fromVersion, toVersion):
    ifacePom = baseDir + "AppRentUserApi/RentUserApiIface/" + "pom.xml"
    updateIfacePom(ifacePom, fromVersion, toVersion)
    servicePom = baseDir + "AppRentUserApi/RentUserApiService/" + "pom.xml"
    updateServicePom(servicePom, fromVersion, toVersion)


def updateUserData(fromVersion, toVersion):
    ifacePom = baseDir + "AppRentUserDataService/RentUserDataServiceIface/" + "pom.xml"
    updateIfacePom(ifacePom, fromVersion, toVersion)
    servicePom = baseDir + "AppRentUserDataService/RentUserDataService/" + "pom.xml"
    updateServicePom(servicePom, fromVersion, toVersion)


def updateAdminApi(fromVersion, toVersion):
    ifacePom = baseDir + "AppRentAdminApi/RentAdminApiIface/" + "pom.xml"
    updateIfacePom(ifacePom, fromVersion, toVersion)
    servicePom = baseDir + "AppRentAdminApi/RentAdminApiService/" + "pom.xml"
    updateServicePom(servicePom, fromVersion, toVersion)


def updateBaseData(fromVersion, toVersion):
    ifacePom = baseDir + "AppRentBaseDataService/RentBaseDataServiceIface/" + "pom.xml"
    updateIfacePom(ifacePom, fromVersion, toVersion)
    servicePom = baseDir + "AppRentBaseDataService/RentBaseDataService/" + "pom.xml"
    updateServicePom(servicePom, fromVersion, toVersion)


def updateUserService(fromVersion, toVersion):
    ifacePom = baseDir + "AppRentUserService/RentUserServiceIface/" + "pom.xml"
    updateIfacePom(ifacePom, fromVersion, toVersion)
    servicePom = baseDir + "AppRentUserService/RentUserService/" + "pom.xml"
    updateServicePom(servicePom, fromVersion, toVersion)


def updateOrderService(fromVersion, toVersion):
    ifacePom = baseDir + "AppRentOrderService/RentOrderServiceIface/" + "pom.xml"
    updateIfacePom(ifacePom, fromVersion, toVersion)
    servicePom = baseDir + "AppRentOrderService/RentOrderService/" + "pom.xml"
    updateServicePom(servicePom, fromVersion, toVersion)


def updateBikeManager(fromVersion, toVersion):
    ifacePom = baseDir + "AppRentBikeManagerService/RentBikeManagerServiceIface/" + "pom.xml"
    updateIfacePom(ifacePom, fromVersion, toVersion)
    servicePom = baseDir + "AppRentBikeManagerService/RentBikeManagerService/" + "pom.xml"
    updateServicePom(servicePom, fromVersion, toVersion)


def updateActivityService(fromVersion, toVersion):
    ifacePom = baseDir + "AppRentActivityService/RentBikeManagerServiceIface/" + "pom.xml"
    updateIfacePom(ifacePom, fromVersion, toVersion)
    servicePom = baseDir + "AppRentActivityService/ActivityService/" + "pom.xml"
    updateServicePom(servicePom, fromVersion, toVersion)


def updateFinanceService(fromVersion, toVersion):
    ifacePom = baseDir + "AppRentFinanceService/ActivityServiceIface/" + "pom.xml"
    updateIfacePom(ifacePom, fromVersion, toVersion)
    servicePom = baseDir + "AppRentFinanceService/RentFinanceService/" + "pom.xml"
    updateServicePom(servicePom, fromVersion, toVersion)


if __name__ == '__main__':
    length = sys.argv.__len__()
    if length > 2:
        mode = sys.argv[1]
        ver = sys.argv[2]
        fromVersion = ver
        toVersion = ver
        if mode == 'toR':
            fromVersion = fromVersion + '-SNAPSHOT'
            toVersion = toVersion + '-RELEASE'
        else:
            fromVersion = fromVersion + '-RELEASE'
            toVersion = sys.argv[3] + '-SNAPSHOT'

        c = input(fromVersion + " ---> " + toVersion + " input y to modify, else abort ")

        if c == 'y':
            updateUserApi(fromVersion, toVersion)
            updateUserData(fromVersion, toVersion)
            updateAdminApi(fromVersion, toVersion)
            updateBaseData(fromVersion, toVersion)
            updateUserService(fromVersion, toVersion)
            updateBikeManager(fromVersion, toVersion)
            updateOrderService(fromVersion, toVersion)
            updateActivityService(fromVersion, toVersion)
            updateFinanceService(fromVersion, toVersion)
        else:
            print("abort")
    else:
        print('invalid params')
