from PIL import Image
from service.http import ApiHttpClient
import base64
import io
import time
import pytesseract

mobile = '17602107308'
env = 'fat'

commonDict = ApiHttpClient.one_step_get_token(mobile, env)
send_code_res = ApiHttpClient.send_sms_verify_code(commonDict, env)

imageBase64 = send_code_res['data']['imageCaptcha']

capImageData = base64.b64decode(imageBase64.split(",")[1])

image = Image.open(io.BytesIO(capImageData))
image.show()

# 识别验证码
optCode = pytesseract.image_to_string(image)
# 打印出验证码
print(optCode)

time.sleep(5)

local = open('/Users/liuxinyi/Documents/capImg2.png', 'wb')
local.write(capImageData)
local.close()

image.save('/Users/liuxinyi/Documents/capImg.png')

# im = Image.open(filename)
# im.show()
