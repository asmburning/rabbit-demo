from selenium import webdriver
import time

chrome_options = webdriver.ChromeOptions()

driver = webdriver.Chrome(chrome_options=chrome_options)

driver.get('http://crp.hellobike.cn')


time.sleep(0.5)
# 模拟键盘点击ctrl+v

# ele.send_keys(send_code_res['data']['imageCaptcha'])


cap_text = input('please input cap_text:')

driver.close()
