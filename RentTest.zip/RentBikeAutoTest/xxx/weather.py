from pyquery import PyQuery
import sys
import requests
from urllib import parse
import time
import json


class Weather:
    def __init__(self, day, weekday, temperature, weather):
        self.day = day
        self.weekday = weekday
        self.temperature = temperature
        self.weather = weather

    def __str__(self):
        return self.day + '\t' + self.weekday + '\t\t' + self.temperature + '\t' + self.weather


def get_7_day_weather(url):
    page = PyQuery(url=url, encoding="utf-8")
    day7 = page('#7d .t li').items()
    weathers = []
    for day in day7:
        tem = day('.tem').text()
        dayinfo = day('h1').text()
        # print(dayinfo)
        w = Weather(dayinfo.split('（')[0], dayinfo.split('（')[1].strip('）'), tem, day('.wea').text())
        weathers.append(w)
    return weathers


def get_15_day_weather(url):
    page = PyQuery(url=url, encoding="utf-8")
    day15 = page('#15d ul.t li').items()
    weathers = []
    for day in day15:
        tem = day('.tem').text()
        dayinfo = day('.time').text()
        w = Weather(dayinfo.split('（')[1].strip('）'), dayinfo.split('（')[0], tem, day('.wea').text())
        weathers.append(w)
    return weathers


def getCityWeather(cityCode):
    weathers = get_7_day_weather('http://www.weather.com.cn/weather/' + cityCode + '.shtml')
    weathers.extend(get_15_day_weather('http://www.weather.com.cn/weather15d/' + cityCode + '.shtml'))
    return weathers


def queryCityCode(cityName):
    cityNameEncode = parse.quote(cityName)
    url = 'http://toy1.weather.com.cn/search?cityname=' + cityNameEncode + '&callback=success_jsonpCallback&_=' + millts()
    citiestext = requests.get(url).text[22:-1]
    cities = json.loads(citiestext)
    for city in cities:
        infos = city['ref'].split('~', 1)
        print(infos[0] + '\t' + infos[1])
    cityCode = input('please input cityCode(eg:101020100):')
    return cityCode


def millts():
    st = str(time.time())
    sts = st.split('.')
    return sts[0] + sts[1][0:3]


if __name__ == '__main__':
    length = len(sys.argv)
    cityCode = '101020100'
    if length > 1:
        qcityCode = queryCityCode(sys.argv[1])
        if len(qcityCode) > 7:
            cityCode = qcityCode
        else:
            print('invalidCityCode use default shanghai : 101020100 ')

    weathers = getCityWeather(cityCode)
    for i in range(weathers.__len__()):
        if i % 7 == 0:
            print()
        print(weathers[i])
