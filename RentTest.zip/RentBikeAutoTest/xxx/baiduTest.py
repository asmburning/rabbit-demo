from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from pykeyboard import PyKeyboard

import pyperclip
import time

driver = webdriver.Chrome()

driver.get('https://www.baidu.com')
WebDriverWait(driver, 5).until(
    EC.presence_of_element_located((By.ID, "kw"))
)

pyperclip.copy('java12')

driver.find_element_by_id('kw').click()  # 点击一下百度的输入框
time.sleep(0.5)
k = PyKeyboard()
# 模拟键盘点击ctrl+v
k.press_key('command')
k.tap_key('v')
k.release_key('command')

# ele.send_keys(send_code_res['data']['imageCaptcha'])

driver.find_element_by_id("su").send_keys(Keys.ENTER)  # 回车

cap_text = input('please input cap_text:')

driver.close()
